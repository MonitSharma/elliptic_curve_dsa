mod io;
use quantum_ecc::circuit::{Op, OperationType as K, QubitId, BitId};
use std::collections::{HashMap, HashSet};
use sha3::{Digest,Sha3_256};

// Exact XOR expressions. Atom 0 means one; all other atoms denote Boolean
// functions. HashMap hashes are only indices: full keys are compared on lookup.
type E = Vec<u32>;
type Triple = [E;3];
struct Algebra { next:u32, products:HashMap<Triple,u32>, cap:usize, truncations:u64 }
impl Algebra {
 fn fresh(&mut self)->E { let n=self.next; self.next+=1; vec![n] }
 fn xor_raw(a:&E,b:&E)->E {
  let (mut i,mut j)=(0,0); let mut r=Vec::with_capacity(a.len()+b.len());
  while i<a.len() || j<b.len() {
   if j==b.len() || (i<a.len()&&a[i]<b[j]) { r.push(a[i]);i+=1; }
   else if i==a.len() || b[j]<a[i] { r.push(b[j]);j+=1; }
   else {i+=1;j+=1;}
  } r
 }
 fn limit(&mut self,e:E)->E {if e.len()>self.cap {self.truncations+=1;self.fresh()} else {e}}
 fn xor(&mut self,a:&E,b:&E)->E {self.limit(Self::xor_raw(a,b))}
 fn triple(a:&E,b:&E)->Triple {
  let z=Self::xor_raw(&vec![0],&Self::xor_raw(a,b));
  let mut t=[a.clone(),b.clone(),z];t.sort();t
 }
 fn and(&mut self,a:&E,b:&E)->E {
  if a.is_empty()||b.is_empty(){return vec![];}
  if a==&vec![0]{return b.clone();} if b==&vec![0]||a==b{return a.clone();}
  let t=Self::triple(a,b); if t.iter().any(|v|v.is_empty()){return vec![];}
  if let Some(&v)=self.products.get(&t){return vec![v];}
  let v=self.next;self.next+=1;self.products.insert(t,v);vec![v]
 }
 fn select(&mut self,old:&E,new:&E,cond:&E)->E {
  if cond==&vec![0]{return new.clone();} if cond.is_empty(){return old.clone();}
  let d=self.xor(old,new);let v=self.and(cond,&d);self.xor(old,&v)
 }
}
fn hash(ops:&[Op])->String {
 let mut h=Sha3_256::new();for o in ops {h.update((o.kind as u64).to_le_bytes());
 for v in [o.q_control2.0,o.q_control1.0,o.q_target.0,o.c_target.0,o.c_condition.0,o.r_target.0]{h.update(v.to_le_bytes());}}
 format!("{:x}",h.finalize())
}
fn make(k:K,c2:u64,c1:u64,t:u64,ct:u64,cc:u64)->Op {
 let mut o=Op::empty();o.kind=k;o.q_control2=QubitId(c2);o.q_control1=QubitId(c1);o.q_target=QubitId(t);o.c_target=BitId(ct);o.c_condition=BitId(cc);o.validate();o
}
fn initial_inputs(ops:&[Op],nq:usize,nb:usize,alg:&mut Algebra)->(Vec<E>,Vec<E>){
 // Register annotations are metadata: inputs are loaded before op zero.
 let no=u64::MAX;let mut q=vec![E::new();nq];let mut c=vec![E::new();nb];
 let mut qs=HashSet::new();let mut cs=HashSet::new();
 for o in ops {if o.kind==K::AppendToRegister {
  if o.q_target.0!=no&&qs.insert(o.q_target.0){q[o.q_target.0 as usize]=alg.fresh();}
  if o.c_target.0!=no&&cs.insert(o.c_target.0){c[o.c_target.0 as usize]=alg.fresh();}
 }}(q,c)
}

fn audit(ops:&[Op],leases:&[[u64;9]],zeros:&[usize],cap:usize){
 let no=u64::MAX;
 let nq=ops.iter().flat_map(|o|[o.q_target.0,o.q_control1.0,o.q_control2.0]).filter(|x|*x!=no).max().unwrap()as usize+1;
 let nb=ops.iter().flat_map(|o|[o.c_target.0,o.c_condition.0]).filter(|x|*x!=no).max().unwrap()as usize+1;
 let mut alg=Algebra{next:1,products:HashMap::new(),cap,truncations:0};
 let(mut q,mut c)=initial_inputs(ops,nq,nb,&mut alg);let mut base=vec![0];let mut stack=vec![];
 let starts:HashMap<_,_>=leases.iter().map(|s|(s[0]as usize,s)).collect();
 let ends:HashMap<_,_>=leases.iter().map(|s|(s[1]as usize,s)).collect();
 assert_eq!(starts.len(),leases.len());assert_eq!(ends.len(),leases.len());
 assert!(starts.keys().all(|i|!ends.contains_key(i)));
 let mut boundaries:HashMap<usize,(Vec<E>,Vec<E>,E,Vec<E>,u32)>=HashMap::new();let mut expected:HashMap<usize,E>=HashMap::new();let mut active:HashMap<u64,usize>=HashMap::new();
 let zeros:HashSet<_>=zeros.iter().copied().collect();let mut checked_zero=0;let mut checked_end=0;
 for(i,o)in ops.iter().enumerate(){
  if o.kind==K::AppendToRegister||o.kind==K::Register{continue;}
  if o.kind==K::PushCondition{stack.push(base.clone());base=alg.and(&base,&c[o.c_condition.0 as usize]);continue;}
  if o.kind==K::PopCondition{base=stack.pop().unwrap();continue;}
  let eff=if o.c_condition.0==no{base.clone()}else{alg.and(&base,&c[o.c_condition.0 as usize])};
  let t=o.q_target.0 as usize;let a=o.q_control1.0 as usize;let b=o.q_control2.0 as usize;let ct=o.c_target.0 as usize;
  let product=if o.kind==K::CCX{Some(alg.and(&q[a],&q[b]))}else{None};
  if zeros.contains(&i){assert_eq!(o.kind,K::CCX);let v=alg.and(product.as_ref().unwrap(),&eff);assert!(v.is_empty(),"unproved zero row {i}");checked_zero+=1;}
  if let Some(s)=starts.get(&i){
   assert_eq!(eff,vec![0],"unknown start guard {i}");assert_eq!(o.kind,K::CCX);
   assert_eq!([o.q_control2.0,o.q_control1.0,o.q_target.0],[s[3],s[4],s[5]]);
   assert!(q[s[2]as usize].is_empty(),"unclean donor at {i}");
   assert!(!active.contains_key(&s[2]));assert!(s[0]<s[1]);
   active.insert(s[2],i);expected.insert(i,product.clone().unwrap());boundaries.insert(i,(q.clone(),c.clone(),base.clone(),stack.clone(),alg.next));
  }
  if let Some(s)=ends.get(&i){
   assert_eq!(eff,vec![0],"unknown end guard {i}");assert_eq!(o.kind,K::CCX);
   assert_eq!([o.q_control2.0,o.q_control1.0,o.q_target.0],[s[6],s[7],s[8]]);
   assert!(product.as_ref().unwrap()==&expected[&(s[0]as usize)] || seeded_proof(ops,s[0]as usize,i,&boundaries[&(s[0]as usize)]),"neither global nor arbitrary-cut local proof established product equality at {i}");
   assert_eq!(active.get(&s[2]),Some(&(s[0]as usize)));checked_end+=1;
  }
  if !eff.is_empty(){for w in [o.q_control2.0,o.q_control1.0,o.q_target.0]{assert!(!active.contains_key(&w),"donor touched at {i}");}}
  if let Some(s)=ends.get(&i){active.remove(&s[2]);}
    match o.kind {
   K::X=>{q[t]=alg.xor(&q[t],&eff);},
   K::CX=>{let v=alg.and(&q[a],&eff);q[t]=alg.xor(&q[t],&v);},
   K::CCX=>{let v=alg.and(product.as_ref().unwrap(),&eff);q[t]=alg.xor(&q[t],&v);},
   K::Swap=>{let v=alg.xor(&q[a],&q[t]);let v=alg.and(&v,&eff);q[a]=alg.xor(&q[a],&v);q[t]=alg.xor(&q[t],&v);},
   K::R|K::Hmr=>{
    q[t]=alg.select(&q[t],&vec![],&eff);
    if o.kind==K::Hmr{let v=alg.fresh();c[ct]=alg.select(&c[ct],&v,&eff);}
   },
   K::BitInvert=>{c[ct]=alg.xor(&c[ct],&eff);},
   K::BitStore0=>{c[ct]=alg.select(&c[ct],&vec![],&eff);},
   K::BitStore1=>{c[ct]=alg.select(&c[ct],&vec![0],&eff);},
   K::Neg|K::Z|K::CZ|K::CCZ|K::Register|K::DebugPrint=>{},
   _=>panic!("unhandled {:?}",o.kind)
  }

  if i%2000000==0{eprintln!("audited {i} end_proofs={checked_end} zero_proofs={checked_zero}");}
 }
 assert!(stack.is_empty()&&active.is_empty());assert_eq!(checked_end,leases.len());assert_eq!(checked_zero,zeros.len());
}
fn main(){
 let args:Vec<_>=std::env::args().collect();assert_eq!(args.len(),5,"baseline public_parent leases_json receipt");
 let base=io::load_ops(&args[1]);let parent=io::load_ops(&args[2]);
 assert_eq!(base.len(),17891821);assert_eq!(parent.len(),17891901);
 assert_eq!(hash(&base[..base.len()-96]),"c143e90580bb0c6f6a12996a50147c179c4fdfe3a50d8af85350bf9e6d755e04");
 assert_eq!(hash(&parent),"429af1c31b54064e17e7602be516b519c066c241e218d56f002287ea02b16842");
 let leases:Vec<[u64;9]>=serde_json::from_str(&std::fs::read_to_string(&args[3]).unwrap()).unwrap();assert_eq!(leases.len(),27);
 audit(&base,&leases,&[],1024);
 let no=u64::MAX;let nb=base.iter().flat_map(|o|[o.c_target.0,o.c_condition.0]).filter(|x|*x!=no).max().unwrap()+1;assert_eq!(nb,54995);
 let starts:HashMap<_,_>=leases.iter().map(|s|(s[0]as usize,s)).collect();let ends:HashMap<_,_>=leases.iter().map(|s|(s[1]as usize,s)).collect();
 let mut generated=Vec::with_capacity(parent.len()+1);
 for(i,o)in base[..base.len()-96].iter().enumerate(){
  if let Some(s)=starts.get(&i){let mut fill=*o;fill.q_target=QubitId(s[2]);generated.push(fill);generated.push(make(K::CX,no,s[2],s[5],no,no));}
  else if let Some(s)=ends.get(&i){generated.push(make(K::CX,no,s[2],s[8],no,no));generated.push(make(K::Hmr,no,no,s[2],nb,no));generated.push(make(K::CZ,no,s[6],s[7],no,nb));}
  else{generated.push(*o);}
 }
 assert_eq!(hash(&generated),"468e86dd1628976643d42b4bb50bdb8c43211f4d29bfbc3df60b11f7342ac619");
 generated.extend_from_slice(&parent[parent.len()-96..]);
 audit(&generated,&[],&[17876252],1024);
 generated.remove(17876252);assert_eq!(generated,parent);
 for s in [&base[base.len()-96..],&parent[parent.len()-96..]]{for pair in s.chunks_exact(2){assert_eq!(pair[0],pair[1]);assert_eq!(pair[0].kind,K::X);assert!(pair[0].q_target.0<=1);}}
 let result=serde_json::json!({"status":"PUBLIC_PARENT_EXTENSION_UNIVERSAL_AUDIT_PASS","base_pre_tail_sha3_256":hash(&base[..base.len()-96]),"parent_sha3_256":hash(&parent),"retained_products":leases.len(),"zero_rows":1,"no_sampled_inputs":true,"statement":"The 27 unconditional products have exact equal Boolean expressions, clean untouched donors and fresh private measurement/phase correction. The removed CCX has zero effective product for every input and measurement assignment. Reconstructed output equals the exact public parent bytes."});
 std::fs::write(&args[4],serde_json::to_string_pretty(&result).unwrap()).unwrap();println!("PUBLIC_PARENT_EXTENSION_UNIVERSAL_AUDIT_PASS");
}

fn local_proof(ops:&[Op],first:usize,last:usize,nq:usize,nb:usize)->bool{
 let no=u64::MAX;let mut alg=Algebra{next:1,products:HashMap::new(),cap:65536,truncations:0};
 let mut q:Vec<E>=(0..nq).map(|_|alg.fresh()).collect();let mut c:Vec<E>=(0..nb).map(|_|alg.fresh()).collect();
 let f=ops[first];let expected=alg.and(&q[f.q_control1.0 as usize],&q[f.q_control2.0 as usize]);
 let mut base=vec![0];let mut stack=vec![];
 for o in &ops[first..last]{
  let t=o.q_target.0 as usize;let a=o.q_control1.0 as usize;let b=o.q_control2.0 as usize;let ct=o.c_target.0 as usize;
  if o.kind==K::PushCondition{stack.push(base.clone());base=alg.and(&base,&c[o.c_condition.0 as usize]);continue;}
  if o.kind==K::PopCondition{base=match stack.pop(){Some(x)=>x,None=>return false};continue;}
  let eff=if o.c_condition.0==no{base.clone()}else{alg.and(&base,&c[o.c_condition.0 as usize])};if eff.is_empty(){continue;}
  match o.kind{
   K::X=>q[t]=alg.xor(&q[t],&eff),
   K::CX=>{let v=alg.and(&q[a],&eff);q[t]=alg.xor(&q[t],&v);},
   K::CCX=>{let v=alg.and(&q[a],&q[b]);let v=alg.and(&v,&eff);q[t]=alg.xor(&q[t],&v);},
   K::Swap=>{let v=alg.xor(&q[a],&q[t]);let v=alg.and(&v,&eff);q[a]=alg.xor(&q[a],&v);q[t]=alg.xor(&q[t],&v);},
   K::R|K::Hmr=>{q[t]=alg.select(&q[t],&vec![],&eff);if o.kind==K::Hmr{let v=alg.fresh();c[ct]=alg.select(&c[ct],&v,&eff);}},
   K::BitInvert=>c[ct]=alg.xor(&c[ct],&eff),
   K::BitStore0=>c[ct]=alg.select(&c[ct],&vec![],&eff),
   K::BitStore1=>c[ct]=alg.select(&c[ct],&vec![0],&eff),
   K::Neg|K::Z|K::CZ|K::CCZ|K::Register|K::AppendToRegister|K::DebugPrint=>{},
   _=>return false,
  }
 }
 let o=ops[last];stack.is_empty()&&base==vec![0]&&alg.and(&q[o.q_control1.0 as usize],&q[o.q_control2.0 as usize])==expected
}

#[cfg(test)] mod proof_tests {
 use super::*;
 #[test] fn local_identity_and_nonidentity(){
  let n=u64::MAX;
  let good=vec![make(K::CCX,0,1,2,n,n),make(K::CX,n,0,1,n,n),make(K::X,n,n,1,n,n),make(K::CCX,0,1,3,n,n)];
  assert!(local_proof(&good,0,3,4,0));
  let mut bad=good;bad.remove(2);assert!(!local_proof(&bad,0,2,4,0));
 }
 #[test] fn unknown_conditional_change_is_not_skipped(){
  let n=u64::MAX;
  let ops=vec![make(K::CCX,0,1,2,n,n),make(K::X,n,n,1,n,0),make(K::CCX,0,1,3,n,n)];
  assert!(!local_proof(&ops,0,2,4,1));
 }
}

fn seeded_proof(ops:&[Op],first:usize,last:usize,boundary:&(Vec<E>,Vec<E>,E,Vec<E>,u32))->bool{
 let no=u64::MAX;let mut alg=Algebra{next:boundary.4,products:HashMap::new(),cap:65536,truncations:0};
 let mut q=boundary.0.clone();let mut c=boundary.1.clone();
 let f=ops[first];let expected=alg.and(&q[f.q_control1.0 as usize],&q[f.q_control2.0 as usize]);
 let mut base=boundary.2.clone();let mut stack=boundary.3.clone();
 for o in &ops[first..last]{
  let t=o.q_target.0 as usize;let a=o.q_control1.0 as usize;let b=o.q_control2.0 as usize;let ct=o.c_target.0 as usize;
  if o.kind==K::PushCondition{stack.push(base.clone());base=alg.and(&base,&c[o.c_condition.0 as usize]);continue;}
  if o.kind==K::PopCondition{base=match stack.pop(){Some(x)=>x,None=>return false};continue;}
  let eff=if o.c_condition.0==no{base.clone()}else{alg.and(&base,&c[o.c_condition.0 as usize])};if eff.is_empty(){continue;}
  match o.kind{
   K::X=>q[t]=alg.xor(&q[t],&eff),
   K::CX=>{let v=alg.and(&q[a],&eff);q[t]=alg.xor(&q[t],&v);},
   K::CCX=>{let v=alg.and(&q[a],&q[b]);let v=alg.and(&v,&eff);q[t]=alg.xor(&q[t],&v);},
   K::Swap=>{let v=alg.xor(&q[a],&q[t]);let v=alg.and(&v,&eff);q[a]=alg.xor(&q[a],&v);q[t]=alg.xor(&q[t],&v);},
   K::R|K::Hmr=>{q[t]=alg.select(&q[t],&vec![],&eff);if o.kind==K::Hmr{let v=alg.fresh();c[ct]=alg.select(&c[ct],&v,&eff);}},
   K::BitInvert=>c[ct]=alg.xor(&c[ct],&eff),
   K::BitStore0=>c[ct]=alg.select(&c[ct],&vec![],&eff),
   K::BitStore1=>c[ct]=alg.select(&c[ct],&vec![0],&eff),
   K::Neg|K::Z|K::CZ|K::CCZ|K::Register|K::AppendToRegister|K::DebugPrint=>{},
   _=>return false,
  }
 }
 let o=ops[last];alg.and(&q[o.q_control1.0 as usize],&q[o.q_control2.0 as usize])==expected
}

#[cfg(test)]mod boundary_tests{
 use super::*;
 #[test]fn known_flag_is_used_but_unknown_flag_is_not_assumed(){
  let n=u64::MAX;
  let ops=vec![make(K::CCX,0,1,2,n,n),make(K::X,n,n,0,n,0),make(K::CCX,0,1,3,n,n)];
  let q=vec![vec![1],vec![2],vec![3],vec![4]];
  assert!(seeded_proof(&ops,0,2,&(q.clone(),vec![vec![]],vec![0],vec![],6)));
  assert!(!seeded_proof(&ops,0,2,&(q,vec![vec![5]],vec![0],vec![],6)));
 }
}
