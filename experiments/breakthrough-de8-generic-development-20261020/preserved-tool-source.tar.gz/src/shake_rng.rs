// Exact protected scalar SHAKE readers, interleaved into eight independent rows.
fn shake_backend(){}
fn rng8(_label:&str,batches:&[Batch],words:usize,out:&mut[u64]){assert_eq!(batches.len(),8);assert_eq!(out.len(),words*8);for j in 0..8{let mut reader=batches[j].xof.clone();let mut bytes=vec![0u8;words*8];XofReader::read(&mut reader,&mut bytes);for(i,v)in bytes.chunks_exact(8).enumerate(){out[i*8+j]=u64::from_le_bytes(v.try_into().unwrap());}}}
