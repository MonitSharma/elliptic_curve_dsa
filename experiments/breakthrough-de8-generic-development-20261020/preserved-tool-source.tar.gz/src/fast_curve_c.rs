// Portable verification backend: exact protected reference, no external library.
struct FastCurveC;
impl FastCurveC{fn new(_window:usize)->Self{Self}fn points_with_sums(&self,scalars:&[U256])->Vec<((U256,U256),(U256,U256),(U256,U256))>{assert!(scalars.len()%2==0);let c=secp256k1();scalars.chunks_exact(2).map(|pair|{let a=c.mul(c.gx,c.gy,pair[0]);let b=c.mul(c.gx,c.gy,pair[1]);let e=c.add(a.0,a.1,b.0,b.1);(a,b,e)}).collect()}}
