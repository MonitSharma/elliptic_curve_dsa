#include <immintrin.h>
#include <stdint.h>
#include <stddef.h>
typedef struct {uint32_t kind,a,b,aux;} MaskNode;
static inline uint64_t load1(const uint64_t*p){return *(p);}
static inline void store1(uint64_t*p,uint64_t x){*(p)=x;}
static int eval1(const MaskNode*nodes,size_t n,const uint64_t*ports,uint64_t*values,const uint32_t*roots,uint64_t*out){
 for(size_t i=0;i<n;i++){MaskNode o=nodes[i];if(o.aux)return 2;uint64_t x;
 switch(o.kind){case 0:x=0;break;case 1:x=UINT64_MAX;break;
 case 2:if(o.a>=1024)return 3;x=load1(ports+o.a*8);break;
 case 3:case 4:case 5:{if(o.a>=i||o.b>=i)return 4;uint64_t a=load1(values+o.a*1),b=load1(values+o.b*1);
 x=o.kind==3?(a^b):o.kind==4?(a&b):(a|b);break;}default:return 5;}store1(values+i*1,x);}
 for(size_t i=0;i<512;i++){if(roots[i]>=n)return 6;store1(out+i*8,load1(values+roots[i]*1));}return 0;}
static inline __m128i load2(const uint64_t*p){return _mm_loadu_si128((const __m128i*)p);}
static inline void store2(uint64_t*p,__m128i x){_mm_storeu_si128((__m128i*)p,x);}
static int eval2(const MaskNode*nodes,size_t n,const uint64_t*ports,uint64_t*values,const uint32_t*roots,uint64_t*out){
 for(size_t i=0;i<n;i++){MaskNode o=nodes[i];if(o.aux)return 2;__m128i x;
 switch(o.kind){case 0:x=_mm_setzero_si128();break;case 1:x=_mm_set1_epi64x(-1);break;
 case 2:if(o.a>=1024)return 3;x=load2(ports+o.a*8);break;
 case 3:case 4:case 5:{if(o.a>=i||o.b>=i)return 4;__m128i a=load2(values+o.a*2),b=load2(values+o.b*2);
 x=o.kind==3?_mm_xor_si128(a,b):o.kind==4?_mm_and_si128(a,b):_mm_or_si128(a,b);break;}default:return 5;}store2(values+i*2,x);}
 for(size_t i=0;i<512;i++){if(roots[i]>=n)return 6;store2(out+i*8,load2(values+roots[i]*2));}return 0;}
static inline __m256i load4(const uint64_t*p){return _mm256_loadu_si256((const __m256i*)p);}
static inline void store4(uint64_t*p,__m256i x){_mm256_storeu_si256((__m256i*)p,x);}
static int eval4(const MaskNode*nodes,size_t n,const uint64_t*ports,uint64_t*values,const uint32_t*roots,uint64_t*out){
 for(size_t i=0;i<n;i++){MaskNode o=nodes[i];if(o.aux)return 2;__m256i x;
 switch(o.kind){case 0:x=_mm256_setzero_si256();break;case 1:x=_mm256_set1_epi64x(-1);break;
 case 2:if(o.a>=1024)return 3;x=load4(ports+o.a*8);break;
 case 3:case 4:case 5:{if(o.a>=i||o.b>=i)return 4;__m256i a=load4(values+o.a*4),b=load4(values+o.b*4);
 x=o.kind==3?_mm256_xor_si256(a,b):o.kind==4?_mm256_and_si256(a,b):_mm256_or_si256(a,b);break;}default:return 5;}store4(values+i*4,x);}
 for(size_t i=0;i<512;i++){if(roots[i]>=n)return 6;store4(out+i*8,load4(values+roots[i]*4));}return 0;}
static inline __m512i load8(const uint64_t*p){return _mm512_loadu_si512(p);}
static inline void store8(uint64_t*p,__m512i x){_mm512_storeu_si512(p,x);}
static int eval8(const MaskNode*nodes,size_t n,const uint64_t*ports,uint64_t*values,const uint32_t*roots,uint64_t*out){
 for(size_t i=0;i<n;i++){MaskNode o=nodes[i];if(o.aux)return 2;__m512i x;
 switch(o.kind){case 0:x=_mm512_setzero_si512();break;case 1:x=_mm512_set1_epi64(-1);break;
 case 2:if(o.a>=1024)return 3;x=load8(ports+o.a*8);break;
 case 3:case 4:case 5:{if(o.a>=i||o.b>=i)return 4;__m512i a=load8(values+o.a*8),b=load8(values+o.b*8);
 x=o.kind==3?_mm512_xor_si512(a,b):o.kind==4?_mm512_and_si512(a,b):_mm512_or_si512(a,b);break;}default:return 5;}store8(values+i*8,x);}
 for(size_t i=0;i<512;i++){if(roots[i]>=n)return 6;store8(out+i*8,load8(values+roots[i]*8));}return 0;}
int mask8_eval_width(const MaskNode*nodes,size_t n,const uint64_t*ports,size_t np,uint64_t*values,size_t capacity,const uint32_t*roots,size_t nr,uint64_t*out,size_t words){
 if(capacity<n||np!=1024||nr!=512)return 1;
 switch(words){case 1:return eval1(nodes,n,ports,values,roots,out);case 2:return eval2(nodes,n,ports,values,roots,out);case 4:return eval4(nodes,n,ports,values,roots,out);case 8:return eval8(nodes,n,ports,values,roots,out);default:return 7;}}
