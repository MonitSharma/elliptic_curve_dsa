//! v2 : the review's four latent guards G1..G4 coded in (SL_COND_NOGUARD=1 turns
//! them off), and its print-only premise census (SL_COND_RVDIAG=1).
//! cond pass: exact op-stream post-passes over Toffolis whose result is consumed only by phases or
//! by a measurement or reset, or that need no Toffoli at all. Research switch `SL_COND` (unset or "0": the gate list
//! byte for byte):
//!   m  a CCX whose AND equals one control's value (the other control holds 1, or both hold one value) -> CX
//!   u  a CCX that XORs a wire's whole AND back out (the wire is 0 after it) -> HMR into a fresh bit + CZ(a, b) under it
//!   f  a CCX whose result is read only by Z gates before its wire is measured, reset, or the same AND is XORed in
//!      again -> Clifford phases on the operands' values (a CZ of two wires holding them, or of affine forms of them);
//!      at a measured end the builder's own fix CZ on the same two values is deleted
//!   s  a CCX every read of which runs under one classical bit c (a measurement made after the CCX) -> moved to
//!      just after c exists (its operands rebuilt there as affine forms, CX only) and built under c; its measured
//!      erase's phase fix is put under c too (technique 4: build the AND only under the bit that decides its read)
//!   r  K3a measurement absorption generalized: a reset end (the wire is 0 there on every correct shot), writes under
//!      conditions, windows followed through swaps; the wire is measured before the writes, which become phases under
//!      the outcome (a measured end hands the moved outcome to its bit and keeps an idle reset)
//! `SL_COND=1` means "mufsr". `SL_COND_FAULT=f|r|u|u2` breaks one site of that lever (u2: every u site) on purpose
//! (diagnostic only).
//! `SL_COND_ALIGN=1` (diagnostic only, never a candidate): the UNCHANGED gate list with an idle reset of a fresh wire
//! wherever u and r would add a measurement, so it draws the candidate's random words in the candidate's order and
//! can be compared with it shot for shot (dcd525d's aligned copy).
//! m and f keep every measurement in place (the checker's random words stay aligned); u and r add one measurement a
//! site, so later random words shift.
//! Values are hash-consed (atoms: opaque, AND, conditioned; XOR = canonical sets of atoms), so equal ids are equal
//! Boolean functions; contexts are sets of classical bit VALUES (a push captures the value, as the simulator does).

use crate::circuit::{BitId, Op, OperationType as K, QubitId, RegisterId};
use std::collections::{HashMap, HashSet};

const NQ: u32 = u32::MAX;
#[derive(Clone, Copy, PartialEq, Eq)]
struct L { kind: u8, c2: u32, c1: u32, t: u32, ct: u32, cc: u32, rt: u32 }
const K_NEG: u8 = 0; const K_APP: u8 = 2; const K_BINV: u8 = 3; const K_BS0: u8 = 4; const K_BS1: u8 = 5;
const K_X: u8 = 6; const K_Z: u8 = 7; const K_CX: u8 = 8; const K_CZ: u8 = 9; const K_SWAP: u8 = 10; const K_R: u8 = 11;
const K_HMR: u8 = 12; const K_CCX: u8 = 13; const K_CCZ: u8 = 14; const K_PUSH: u8 = 15; const K_POP: u8 = 16;

fn d(v: u64) -> u32 { if v == u64::MAX { NQ } else { assert!(v < NQ as u64, "cond_pass: id {v} too large"); v as u32 } }
fn e(v: u32) -> u64 { if v == NQ { u64::MAX } else { v as u64 } }
fn to_l(o: &Op) -> L { L { kind: o.kind as u8, c2: d(o.q_control2.0), c1: d(o.q_control1.0), t: d(o.q_target.0), ct: d(o.c_target.0), cc: d(o.c_condition.0), rt: d(o.r_target.0) } }
fn kind_of(k: u8) -> K {
    match k { 0 => K::Neg, 1 => K::Register, 2 => K::AppendToRegister, 3 => K::BitInvert, 4 => K::BitStore0, 5 => K::BitStore1,
        6 => K::X, 7 => K::Z, 8 => K::CX, 9 => K::CZ, 10 => K::Swap, 11 => K::R, 12 => K::Hmr, 13 => K::CCX, 14 => K::CCZ,
        15 => K::PushCondition, 16 => K::PopCondition, _ => K::DebugPrint }
}
fn from_l(l: &L) -> Op {
    let mut o = Op::empty();
    o.kind = kind_of(l.kind);
    o.q_control2 = QubitId(e(l.c2)); o.q_control1 = QubitId(e(l.c1)); o.q_target = QubitId(e(l.t));
    o.c_target = BitId(e(l.ct)); o.c_condition = BitId(e(l.cc)); o.r_target = RegisterId(e(l.rt));
    o.validate();
    o
}
fn op(kind: u8, c1: u32, t: u32, cc: u32) -> L { L { kind, c2: NQ, c1, t, ct: NQ, cc, rt: NQ } }

// ---- values ----
const ZERO: u32 = 0; const ONE: u32 = 1;
const T_OPQ: u8 = 2; const T_AND: u8 = 3; const T_COND: u8 = 5; const T_SET: u8 = 6;
const XSET_CAP: usize = 96;
struct Vals { node: Vec<(u8, u32, u32)>, h: HashMap<(u8, u32, u32), u32>, store: Vec<Vec<u32>>, hs: HashMap<Vec<u32>, u32> }
impl Vals {
    fn new() -> Self { Vals { node: vec![(0, 0, 0), (1, 0, 0)], h: HashMap::new(), store: Vec::new(), hs: HashMap::new() } }
    fn opq(&mut self) -> u32 { let i = self.node.len() as u32; self.node.push((T_OPQ, i, 0)); i }
    fn mk(&mut self, t: u8, a: u32, b: u32) -> u32 {
        if let Some(&i) = self.h.get(&(t, a, b)) { return i; }
        let i = self.node.len() as u32; self.node.push((t, a, b)); self.h.insert((t, a, b), i); i
    }
    fn and(&mut self, a: u32, b: u32) -> u32 {
        if a == ZERO || b == ZERO { return ZERO; }
        if a == ONE { return b; } if b == ONE { return a; } if a == b { return a; }
        let (x, y) = if a < b { (a, b) } else { (b, a) }; self.mk(T_AND, x, y)
    }
    fn xor(&mut self, a: u32, b: u32) -> u32 {
        if a == ZERO { return b; } if b == ZERO { return a; } if a == b { return ZERO; }
        let one_a = [a]; let one_b = [b];
        let sa: &[u32] = if self.node[a as usize].0 == T_SET { &self.store[self.node[a as usize].1 as usize] } else { &one_a };
        let sb: &[u32] = if self.node[b as usize].0 == T_SET { &self.store[self.node[b as usize].1 as usize] } else { &one_b };
        let mut r: Vec<u32> = Vec::with_capacity(sa.len() + sb.len());
        let (mut i, mut j) = (0, 0);
        while i < sa.len() && j < sb.len() {
            if sa[i] < sb[j] { r.push(sa[i]); i += 1; } else if sa[i] > sb[j] { r.push(sb[j]); j += 1; } else { i += 1; j += 1; }
        }
        r.extend_from_slice(&sa[i..]); r.extend_from_slice(&sb[j..]);
        match r.len() {
            0 => ZERO,
            1 => r[0],
            l if l > XSET_CAP => self.opq(),
            _ => {
                if let Some(&id) = self.hs.get(&r) { return id; }
                let si = self.store.len() as u32; self.store.push(r.clone());
                let id = self.node.len() as u32; self.node.push((T_SET, si, 0)); self.hs.insert(r, id); id
            }
        }
    }
    fn cond(&mut self, ctx: u32, x: u32) -> u32 { if ctx == 0 || x == ZERO { x } else { self.mk(T_COND, ctx, x) } }
}
struct Ctxs { sets: Vec<Vec<u32>>, h: HashMap<Vec<u32>, u32> }
impl Ctxs {
    fn new() -> Self { let mut c = Ctxs { sets: vec![vec![]], h: HashMap::new() }; c.h.insert(vec![], 0); c }
    fn add(&mut self, c: u32, b: u32) -> u32 {
        if b == BV1 { return c; }
        if self.sets[c as usize].contains(&b) { return c; }
        let mut v = self.sets[c as usize].clone(); v.push(b); v.sort_unstable();
        if let Some(&i) = self.h.get(&v) { return i; }
        let i = self.sets.len() as u32; self.sets.push(v.clone()); self.h.insert(v, i); i
    }
}
const BV0: u32 = 0; const BV1: u32 = 1;
const E_OPEN: u8 = 0; const E_CANCEL: u8 = 1; const E_HMR: u8 = 3; const E_R: u8 = 4;

/// A CCX's XOR-write into its target, tracked until the same AND is XORed in again or the wire is measured / reset.
struct Contrib { swapped: bool, op: u32, wire: u32, term: u32, ctx: u32, va: u32, vb: u32, reads: Vec<(u32, u32)>, zonly: bool,
    end_kind: u8, end_op: u32, end_bit: u32,
    /// bits every read so far runs under beyond the CCX's own (None: no read yet); first read; the wire held only this
    /// AND when measured
    inter: Option<Vec<u32>>, first_read: u32, end_sole: bool }

struct Analysis {
    opctx: Vec<u32>, cx: Ctxs, contribs: Vec<Contrib>,
    zhold: HashMap<(u32, u32), (u32, u32)>, endhold: HashMap<u32, (u32, u32)>, fixcz: HashMap<u32, Vec<(u32, u32, u32)>>,
    misc: Vec<(u32, u8, u32)>, unc: Vec<u32>,
    /// per bit value: the op that created it and the slot it was written to; derived = another value was computed from it
    bcreator: Vec<u32>, bslot: Vec<u32>, bderived: Vec<bool>, depth_after: Vec<u8>,
    guard_readhold: HashMap<(u32,u32),(u32,u32)>,
}

fn analyze(ops: &[L]) -> Analysis {
    let n = ops.len();
    let mut nq = 0u32; let mut nb = 0u32;
    for o in ops { for q in [o.c2, o.c1, o.t] { if q != NQ { nq = nq.max(q + 1); } } for b in [o.ct, o.cc] { if b != NQ { nb = nb.max(b + 1); } } }
    let mut reg_q = vec![false; nq as usize]; let mut reg_b = vec![false; nb as usize];
    for o in ops { if o.kind == K_APP { if o.t != NQ { reg_q[o.t as usize] = true; } if o.ct != NQ { reg_b[o.ct as usize] = true; } } }
    let mut v = Vals::new();
    let mut cx = Ctxs::new();
    let mut qv: Vec<u32> = (0..nq).map(|q| if reg_q[q as usize] { v.opq() } else { ZERO }).collect();
    let mut nbits: u32 = 2;
    let mut bv: Vec<u32> = vec![BV0; nb as usize];
    for b in 0..nb as usize { if reg_b[b] { bv[b] = nbits; nbits += 1; } }
    let mut holders: HashMap<u32, Vec<u32>> = HashMap::new();
    for q in 0..nq { if qv[q as usize] != ZERO { holders.entry(qv[q as usize]).or_default().push(q); } }
    let mut stack: Vec<u32> = vec![0];
    let mut opctx: Vec<u32> = vec![0; n];
    let mut contribs: Vec<Contrib> = Vec::new();
    let mut open: Vec<Vec<u32>> = vec![Vec::new(); nq as usize];
    let mut zhold = HashMap::new(); let mut endhold = HashMap::new();
    let mut fixcz: HashMap<u32, Vec<(u32, u32, u32)>> = HashMap::new();
    let mut misc = Vec::new(); let mut unc = Vec::new();
    let mut guard_readhold=HashMap::new();
    let mut guard_eligible=HashSet::new();let mut pending=vec![None;nq as usize];
    for (j,o)in ops.iter().enumerate(){match o.kind{
      K_CCX=>pending[o.t as usize]=Some(j as u32),
      K_HMR=>{if let Some(p)=pending[o.t as usize].take(){guard_eligible.insert(p);}},
      K_CX|K_X|K_R=>pending[o.t as usize]=None,
      K_SWAP=>{pending[o.t as usize]=None;pending[o.c1 as usize]=None;},_=>{}
    }}

    let mut bcreator: Vec<u32> = vec![NQ; nbits as usize]; let mut bslot: Vec<u32> = vec![NQ; nbits as usize];
    let mut bderived: Vec<bool> = vec![false; nbits as usize]; let mut depth_after: Vec<u8> = vec![0; n];
    macro_rules! setq { ($q:expr, $val:expr) => {{
        let q = $q as usize; let old = qv[q]; let nv = $val;
        if old != nv {
            if old != ZERO { if let Some(hv) = holders.get_mut(&old) { if let Some(p) = hv.iter().position(|&x| x == q as u32) { hv.swap_remove(p); } if hv.is_empty() { holders.remove(&old); } } }
            if nv != ZERO { holders.entry(nv).or_default().push(q as u32); }
            qv[q] = nv;
        }
    }}}
    let hold = |val: u32, holders: &HashMap<u32, Vec<u32>>| -> u32 { holders.get(&val).and_then(|v| v.first().copied()).unwrap_or(NQ) };
    for (k, o) in ops.iter().enumerate() {
        let k32 = k as u32;
        let top = *stack.last().unwrap();
        let mut ctx = top;
        if o.cc != NQ && o.kind != K_PUSH { ctx = cx.add(ctx, bv[o.cc as usize]); }
        opctx[k] = ctx;
        if (o.kind == K_CZ || o.kind == K_Z) && o.cc != NQ {
            let (x, y) = if o.kind == K_CZ { (qv[o.c1 as usize], qv[o.t as usize]) } else { (qv[o.t as usize], qv[o.t as usize]) };
            fixcz.entry(bv[o.cc as usize]).or_default().push((k32, x, y));
        }
        let mut reads: [u32; 3] = [NQ; 3];
        match o.kind {
            K_CCX => { reads[0] = o.c1; reads[1] = o.c2; }
            K_CX => { reads[0] = o.c1; }
            K_Z => { reads[0] = o.t; }
            K_CZ => { reads[0] = o.c1; reads[1] = o.t; }
            K_CCZ => { reads[0] = o.c1; reads[1] = o.c2; reads[2] = o.t; }
            K_SWAP => { if ctx != 0 { reads[0] = o.c1; reads[1] = o.t; } }
            _ => {}
        }
        for &q in reads.iter() {
            if q == NQ { continue; }
            for &ci in &open[q as usize] {
                let c = &mut contribs[ci as usize];
                if c.first_read == NQ { c.first_read = k32; }
                if c.inter.as_ref().map_or(true, |x| !x.is_empty()) {
                    let own = &cx.sets[c.ctx as usize];
                    let rs: Vec<u32> = cx.sets[ctx as usize].iter().copied().filter(|b| !own.contains(b)).collect();
                    c.inter = Some(match c.inter.take() { None => rs, Some(mut x) => { x.retain(|b| rs.contains(b)); x } });
                }
                if c.ctx==0 && guard_eligible.contains(&c.op) {let alias=|v|holders.get(&v).and_then(|qs|qs.iter().copied().find(|&q|q!=c.wire)).unwrap_or(NQ);let pair=(alias(c.va),alias(c.vb));if pair.0!=NQ&&pair.1!=NQ{guard_readhold.insert((ci,k32),pair);}}
                if !c.zonly { continue; }
                if o.kind == K_Z && c.reads.len() < 64 {
                    zhold.insert((ci, k32), (hold(c.va, &holders), hold(c.vb, &holders)));
                    c.reads.push((k32, ctx));
                } else { c.zonly = false; c.reads = Vec::new(); }
            }
        }
        match o.kind {
            K_CCX | K_CX | K_X => {
                let t = o.t as usize;
                let (va, vb) = if o.kind == K_CCX { (qv[o.c1 as usize], qv[o.c2 as usize]) } else { (NQ, NQ) };
                let bare = match o.kind { K_CCX => v.and(va, vb), K_CX => qv[o.c1 as usize], _ => ONE };
                let term = v.cond(ctx, bare);
                if o.kind == K_CCX {
                    if bare == ZERO { misc.push((k32, 0, NQ)); }
                    else if bare == va { misc.push((k32, 1, o.c1)); } else if bare == vb { misc.push((k32, 2, o.c2)); }
                }
                if o.kind != K_X {
                    if let Some(p) = open[t].iter().position(|&ci| contribs[ci as usize].term == term) {
                        let ci = open[t].remove(p);
                        let c = &mut contribs[ci as usize]; c.end_kind = E_CANCEL; c.end_op = k32;
                        if o.kind == K_CCX && qv[t] == term { unc.push(k32); }
                    } else if o.kind == K_CCX && term != ZERO {
                        let ci = contribs.len() as u32;
                        contribs.push(Contrib { swapped: false, op: k32, wire: o.t, term, ctx, va, vb, reads: vec![], zonly: true, end_kind: E_OPEN, end_op: NQ, end_bit: NQ, inter: None, first_read: NQ, end_sole: false });
                        open[t].push(ci);
                        if open[t].len() > 512 { let old = open[t].remove(0); let c = &mut contribs[old as usize]; c.zonly = false; c.reads = Vec::new(); }
                    }
                }
                let nv = v.xor(qv[t], term); setq!(t, nv);
            }
            K_SWAP => {
                let (a, b) = (o.c1 as usize, o.t as usize);
                if ctx == 0 { let (xa, xb) = (qv[a], qv[b]); setq!(a, xb); setq!(b, xa); open.swap(a, b); for &ci in &open[a] { contribs[ci as usize].wire = a as u32; contribs[ci as usize].swapped = true; } for &ci in &open[b] { contribs[ci as usize].wire = b as u32; contribs[ci as usize].swapped = true; } }
                else { let x = v.opq(); setq!(a, x); let y = v.opq(); setq!(b, y); }
            }
            K_R | K_HMR => {
                let t = o.t as usize;
                let mut newb = NQ;
                if o.kind == K_HMR { newb = nbits; nbits += 1; bv[o.ct as usize] = newb; bcreator.push(k32); bslot.push(o.ct); bderived.push(false); }
                let sole = open[t].len() == 1 && contribs[open[t][0] as usize].term == qv[t];
                for ci in std::mem::take(&mut open[t]) {
                    let c = &mut contribs[ci as usize];
                    c.end_kind = if o.kind == K_HMR { E_HMR } else { E_R }; c.end_op = k32; c.end_bit = newb; c.end_sole = sole && ctx == 0;
                    if c.zonly { endhold.insert(ci, (hold(c.va, &holders), hold(c.vb, &holders))); }
                }
                if ctx == 0 { setq!(t, ZERO); } else { let x = v.opq(); setq!(t, x); }
            }
            K_BS0 | K_BS1 | K_BINV => {
                let b = o.ct as usize; let old = bv[b];
                let cs = &cx.sets[ctx as usize];
                let nv = if ctx == 0 && o.kind == K_BS0 { BV0 } else if ctx == 0 && o.kind == K_BS1 { BV1 }
                    else if cs.len() == 1 && (o.kind == K_BS1 || o.kind == K_BINV) && old == BV0 { cs[0] }
                    else {
                        if old >= 2 { bderived[old as usize] = true; }
                        for &x in cs.iter() { if x >= 2 { bderived[x as usize] = true; } }
                        let id = nbits; nbits += 1; bcreator.push(k32); bslot.push(o.ct); bderived.push(false); id };
                bv[b] = nv;
            }
            K_PUSH => { let c = cx.add(top, bv[o.cc as usize]); stack.push(c); }
            K_POP => { stack.pop(); assert!(!stack.is_empty(), "cond_pass: unbalanced pop"); }
            _ => {}
        }
        depth_after[k] = (stack.len() - 1).min(255) as u8;
    }
    Analysis { opctx, cx, contribs, zhold, endhold, fixcz, misc, unc, bcreator, bslot, bderived, depth_after, guard_readhold }
}

/// Affine forms of wires `start` (values at op p) over the wires at each op in `at` (sorted, all > p). None if a member
/// is written nonlinearly, under a condition the CCX's own context does not imply, or measured / reset first.
fn forms_at(ops: &[L], a: &Analysis, p: usize, start: &[u32], at: &[usize]) -> Option<Vec<Vec<(Vec<u32>, bool)>>> {
    let own = &a.cx.sets[a.opctx[p] as usize];
    let mut fs: Vec<(Vec<u32>, bool)> = start.iter().map(|&w| (vec![w], false)).collect();
    let mut out = Vec::new();
    let mut ai = 0;
    let last = *at.last().unwrap();
    for k in p + 1..=last {
        while ai < at.len() && at[ai] == k { out.push(fs.iter().map(|f| { let mut v = f.0.clone(); v.sort_unstable(); (v, f.1) }).collect()); ai += 1; }
        if ai == at.len() { break; }
        let o = &ops[k];
        let uncond = a.cx.sets[a.opctx[k] as usize].iter().all(|b| own.contains(b));
        for f in fs.iter_mut() {
            let inn = |w: u32, f: &Vec<u32>| f.contains(&w);
            match o.kind {
                K_CX => if inn(o.t, &f.0) { if !uncond { return None; } if let Some(q) = f.0.iter().position(|&x| x == o.c1) { f.0.swap_remove(q); } else { f.0.push(o.c1); } },
                K_X => if inn(o.t, &f.0) { if !uncond { return None; } f.1 ^= true; },
                K_CCX | K_R | K_HMR => if inn(o.t, &f.0) { return None; },
                K_SWAP => { let (x, y) = (inn(o.c1, &f.0), inn(o.t, &f.0)); if x || y { if !uncond { return None; }
                    for w in f.0.iter_mut() { if *w == o.c1 { *w = o.t; } else if *w == o.t { *w = o.c1; } } } }
                _ => {}
            }
        }
    }
    if out.len() != at.len() { return None; }
    Some(out)
}

/// Phase (-1)^(Fa * Fb) as CZ / Z / NEG ops under the per-op condition `cc`.
fn phase_ops(fa: &(Vec<u32>, bool), fb: &(Vec<u32>, bool), cc: u32) -> Vec<L> {
    let mut pairs: HashMap<(u32, u32), bool> = HashMap::new();
    let mut singles: HashMap<u32, bool> = HashMap::new();
    for &u in &fa.0 { for &w in &fb.0 { if u == w { *singles.entry(u).or_insert(false) ^= true; } else { let key = if u < w { (u, w) } else { (w, u) }; *pairs.entry(key).or_insert(false) ^= true; } } }
    if fb.1 { for &u in &fa.0 { *singles.entry(u).or_insert(false) ^= true; } }
    if fa.1 { for &w in &fb.0 { *singles.entry(w).or_insert(false) ^= true; } }
    let mut v = Vec::new();
    let mut ps: Vec<_> = pairs.into_iter().filter(|x| x.1).map(|x| x.0).collect(); ps.sort_unstable();
    for (u, w) in ps { v.push(op(K_CZ, u, w, cc)); }
    let mut ss: Vec<_> = singles.into_iter().filter(|x| x.1).map(|x| x.0).collect(); ss.sort_unstable();
    for u in ss { v.push(op(K_Z, NQ, u, cc)); }
    if fa.1 && fb.1 { v.push(L { kind: K_NEG, c2: NQ, c1: NQ, t: NQ, ct: NQ, cc, rt: NQ }); }
    v
}
fn pair_op(u: u32, w: u32, cc: u32) -> L { if u == w { op(K_Z, NQ, u, cc) } else { op(K_CZ, u, w, cc) } }

struct Edits { delete: HashSet<u32>, replace: HashMap<u32, Vec<L>>, after: HashMap<u32, Vec<L>>, before: HashMap<u32, Vec<L>> }
impl Edits {
    fn new() -> Self { Edits { delete: HashSet::new(), replace: HashMap::new(), after: HashMap::new(), before: HashMap::new() } }
    fn touched(&self, k: u32) -> bool { self.delete.contains(&k) || self.replace.contains_key(&k) }
    fn apply(&self, ops: &[L]) -> Vec<L> {
        let mut out = Vec::with_capacity(ops.len() + 1024);
        for (k, o) in ops.iter().enumerate() {
            let k32 = k as u32;
            if let Some(v) = self.before.get(&k32) { out.extend_from_slice(v); }
            if let Some(v) = self.replace.get(&k32) { out.extend_from_slice(v); } else if !self.delete.contains(&k32) { out.push(*o); }
            if let Some(v) = self.after.get(&k32) { out.extend_from_slice(v); }
        }
        out
    }
}

fn weight_of(ops: &[L]) -> f64 {
    let mut depth = 0i32; let mut t = 0f64;
    for o in ops {
        match o.kind {
            K_PUSH => depth += 1, K_POP => depth -= 1,
            K_CCX | K_CCZ => t += 0.5f64.powi(depth + (o.cc != NQ) as i32),
            _ => {}
        }
    }
    t
}
fn max_bit(ops: &[L]) -> u32 { let mut nb = 0u32; for o in ops { for b in [o.ct, o.cc] { if b != NQ { nb = nb.max(b + 1); } } } nb }

/// m, u, f planned on one analysis of `ops`.
fn guards_on() -> bool { !std::env::var("SL_COND_NOGUARD").is_ok_and(|x| x == "1") }
static GUARD_HITS: std::sync::Mutex<[usize; 4]> = std::sync::Mutex::new([0; 4]);
fn guard_hit(i: usize) { GUARD_HITS.lock().unwrap()[i] += 1; }
fn plan_muf(ops: &[L], levers: &str, fault: &str) -> (Edits, [usize; 4], [f64; 4]) {
    let a = analyze(ops);
    let gon = guards_on();
    let wt = |k: u32| 0.5f64.powi(a.cx.sets[a.opctx[k as usize] as usize].len() as i32);
    let mut ed = Edits::new();
    let mut nb = max_bit(ops);
    let mut cnt = [0usize; 4]; let mut sav = [0f64; 4];
    if levers.contains('m') {
        for &(k, how, u) in &a.misc {
            let o = ops[k as usize];
            ed.replace.insert(k, if how == 0 { vec![] } else { vec![op(K_CX, u, o.t, o.cc)] });
            cnt[0] += 1; sav[0] += wt(k);
        }
    }
    if levers.contains('u') {
        let mut faulted = false;
        for &k in &a.unc {
            let o = ops[k as usize];
            if o.cc != NQ || ed.touched(k) { continue; }
            let f = nb; nb += 1;
            let mut fix = op(K_CZ, o.c1, o.c2, f);
            if fault == "u" && !faulted { fix = op(K_Z, NQ, o.c1, f); faulted = true; }
            let mut v = vec![L { kind: K_HMR, c2: NQ, c1: NQ, t: o.t, ct: f, cc: NQ, rt: NQ }, fix];
            if fault == "u2" { v.pop(); } // every u site's phase fix left out
            ed.replace.insert(k, v);
            cnt[1] += 1; sav[1] += wt(k);
            if std::env::var("SL_COND_RVDIAG").is_ok_and(|x| x == "1") { eprintln!("RVU op {} ctx {:?} depth_after {} cc {}", k, a.cx.sets[a.opctx[k as usize] as usize], a.depth_after[k as usize], o.cc as i64); }
        }
    }
    if levers.contains('f') {
        struct Site { ci: u32, wire: u32, op: u32, end: u32, uses: Vec<(u32, u32)>, after: Vec<(u32, Vec<L>)>, replace: Vec<(u32, L)>, delete: Vec<u32>, save: f64, bit: u32 }
        let mut sites: Vec<Site> = Vec::new();
        let mut taken: HashSet<u32> = HashSet::new();
        for (ci, c) in a.contribs.iter().enumerate() {
            let ci = ci as u32;
            if !c.zonly || ed.touched(c.op) { continue; }
            // v2 G2: a contribution a swap moved during its life is not taken (the overlap check keys on one label)
            if gon && c.swapped { guard_hit(1); continue; }
            if !c.reads.iter().all(|&(r, _)| ops[r as usize].t == c.wire) { continue; }
            let p = c.op as usize; let o = ops[p];
            let own = &a.cx.sets[c.ctx as usize];
            let sub = |x: u32| -> bool { let s = &a.cx.sets[x as usize]; own.iter().all(|b| s.contains(b)) };
            if !c.reads.iter().all(|&(_, rc)| sub(rc)) { continue; }
            let e = c.end_op as usize;
            match c.end_kind {
                E_HMR | E_R => { if ops[e].cc != NQ || !sub(a.opctx[e]) || ed.touched(e as u32) { continue; }
                    // v2 G1: the end runs under exactly the CCX's context
                    if gon && a.opctx[e] != c.ctx { guard_hit(0); continue; } }
                E_CANCEL => { if !matches!(ops[e].kind, K_CCX | K_CX) || taken.contains(&(e as u32)) || ed.touched(e as u32) { continue; } }
                _ => continue,
            }
            let mut s = Site { ci, wire: c.wire, op: c.op, end: c.end_op, uses: vec![], after: vec![], replace: vec![], delete: vec![c.op], save: wt(c.op), bit: NQ };
            let mut need: Vec<(usize, u32)> = Vec::new();
            for &(r, _) in &c.reads {
                let z = ops[r as usize];
                match a.zhold.get(&(ci, r)) {
                    Some(&(u, w)) if u != NQ && w != NQ && u != c.wire && w != c.wire => { s.after.push((r, vec![pair_op(u, w, z.cc)])); s.uses.push((u, r)); s.uses.push((w, r)); }
                    _ => need.push((r as usize, z.cc)),
                }
            }
            match c.end_kind {
                E_HMR => {
                    let k = c.end_bit;
                    let mut want: Vec<u32> = own.clone(); want.push(k); want.sort_unstable(); want.dedup();
                    let found = a.fixcz.get(&k).and_then(|v| v.iter().find(|&&(f, x, y)| !taken.contains(&f) && !ed.touched(f)
                        && ((x == c.va && y == c.vb) || (x == c.vb && y == c.va)) && a.cx.sets[a.opctx[f as usize] as usize] == want));
                    if let Some(&(f, _, _)) = found { s.delete.push(f); }
                    else {
                        match a.endhold.get(&ci) {
                            // v2 G3: never the measured wire itself
                            Some(&(u, w)) if gon && u != NQ && w != NQ && (u == c.wire || w == c.wire) => { guard_hit(2); continue; }
                            Some(&(u, w)) if u != NQ && w != NQ => { s.after.push((e as u32, vec![pair_op(u, w, ops[e].ct)])); s.uses.push((u, e as u32)); s.uses.push((w, e as u32)); }
                            _ => need.push((e, ops[e].ct)),
                        }
                    }
                }
                E_R => {
                    let f = nb; s.bit = f;
                    let mut h = ops[e]; h.kind = K_HMR; h.ct = f;
                    s.replace.push((e as u32, h));
                    match a.endhold.get(&ci) {
                        // v2 G3: never the reset wire itself
                        Some(&(u, w)) if gon && u != NQ && w != NQ && (u == c.wire || w == c.wire) => { guard_hit(2); continue; }
                        Some(&(u, w)) if u != NQ && w != NQ => { s.after.push((e as u32, vec![pair_op(u, w, f)])); s.uses.push((u, e as u32)); s.uses.push((w, e as u32)); }
                        _ => need.push((e, f)),
                    }
                }
                _ => { s.delete.push(e as u32); if ops[e].kind == K_CCX { s.save += wt(e as u32); } }
            }
            if !need.is_empty() {
                need.sort_unstable();
                let at: Vec<usize> = need.iter().map(|x| x.0).collect();
                let Some(fs) = forms_at(ops, &a, p, &[o.c1, o.c2], &at) else { continue };
                for (i, &(t, cc)) in need.iter().enumerate() {
                    for w in fs[i][0].0.iter().chain(fs[i][1].0.iter()) { s.uses.push((*w, t as u32)); }
                    s.after.push((t as u32, phase_ops(&fs[i][0], &fs[i][1], cc)));
                }
            }
            if s.bit != NQ { nb += 1; }
            for &x in &s.delete { taken.insert(x); }
            sites.push(s);
        }
        // a fix must not read a wire whose value a kept site changes at that time
        let mut iv: HashMap<u32, Vec<(u32, u32)>> = HashMap::new();
        for s in &sites { iv.entry(s.wire).or_default().push((s.op, s.end)); }
        let mut faulted = false;
        for s in &sites {
            if s.uses.iter().any(|&(w, t)| iv.get(&w).is_some_and(|v| v.iter().any(|&(p, e)| p < t && t <= e))) { continue; }
            for &x in &s.delete { ed.delete.insert(x); }
            for (k, l) in &s.replace { ed.replace.insert(*k, vec![*l]); }
            for (k, v) in &s.after {
                let mut v = v.clone();
                if fault == "f" && !faulted && !v.is_empty() { v.pop(); faulted = true; }
                ed.after.entry(*k).or_default().extend(v);
            }
            cnt[2] += 1; sav[2] += s.save;
            if std::env::var("SL_COND_RVDIAG").is_ok_and(|x| x == "1") {
                let c = &a.contribs[s.ci as usize]; let e = c.end_op as usize;
                let own = &a.cx.sets[c.ctx as usize]; let ce = &a.cx.sets[a.opctx[e] as usize];
                let w0 = ops[c.op as usize].t;
                let eh = a.endhold.get(&s.ci).copied();
                let hw = eh.is_some_and(|(u, w)| u == c.wire || w == c.wire);
                let rx = c.reads.iter().filter(|&&(_, rc)| a.cx.sets[rc as usize].len() > own.len()).count();
                let kind_e = ops[e].kind;
                let mut lab = w0; let mut nsw = 0;
                for j in c.op as usize + 1..e { let x = &ops[j]; if x.kind == K_SWAP { if x.c1 == lab { lab = x.t; nsw += 1; } else if x.t == lab { lab = x.c1; nsw += 1; } } }
                eprintln!("RVF op {} end {} endkind {} opkind_e {} own {:?} ctx_e {:?} ctx_e_eq_own {} w0 {} wire {} swaps {} reads {} reads_extra_ctx {} del {} repl {} after {} endhold {:?} holder_is_wire {} depth_ccx {} depth_e {}",
                    c.op, e, c.end_kind, kind_e, own, ce, ce == own, w0, c.wire, nsw, c.reads.len(), rx, s.delete.len(), s.replace.len(), s.after.len(), eh, hw,
                    a.depth_after[c.op as usize], a.depth_after[e]);
            }
        }
    }
    if levers.contains('s') {
        // copy point of a bit value: the first op at or after its creator with an empty condition stack, the slot not
        // rewritten in between
        let copy_point = |b: u32| -> u32 {
            let k = a.bcreator[b as usize]; let src = a.bslot[b as usize];
            if k == NQ { return NQ; }
            let mut j = k as usize;
            loop {
                if j >= ops.len() { return NQ; }
                if j > k as usize { let o = &ops[j]; if matches!(o.kind, K_HMR | K_BS0 | K_BS1 | K_BINV) && o.ct == src { return NQ; } }
                if a.depth_after[j] == 0 { return j as u32; }
                j += 1;
            }
        };
        let mut faulted = false;
        let mut cands: Vec<(u32, u32, u32, bool, Vec<L>, u32, u32)> = Vec::new();
        let dbg_all = std::env::var("SL_COND_DEBUG").is_ok_and(|x| x == "all");
        let dbg: Option<u32> = std::env::var("SL_COND_DEBUG").ok().and_then(|x| x.parse().ok());
        for c in a.contribs.iter() {
            let p = c.op as usize; let o = ops[p];
            if dbg == Some(c.op) { eprintln!("SL_COND_DEBUG op {} ctx {} inter {:?} first_read {} end {} {} sole {} k {} derived {}", c.op, c.ctx, c.inter, c.first_read as i64, c.end_kind, c.end_op as i64, c.end_sole, c.end_bit as i64, if c.end_bit != NQ { a.bderived[c.end_bit as usize] } else { false });
                if let Some(set) = &c.inter { for &b in set { if b >= 2 { eprintln!("  bit {b} creator {} slot {} copy_point {}", a.bcreator[b as usize] as i64, a.bslot[b as usize] as i64, copy_point(b) as i64); } } } }
            let why = |r: &str| { if dbg_all { eprintln!("SL_COND_S op {} weight-ctx {} end {} sole {} : {r}", c.op, c.ctx, c.end_kind, c.end_sole); } };
            let Some(set) = &c.inter else { continue };
            if set.is_empty() { continue; }
            if o.cc != NQ { why("CCX with a per-op condition"); continue; }
            if ed.touched(c.op) { why("taken by another lever"); continue; }
            if c.end_kind != E_HMR || !c.end_sole { why("end not a measured erase of this AND alone"); continue; }
            let e = c.end_op as usize;
            if ops[e].cc != NQ || a.opctx[e] != 0 || ed.touched(e as u32) { why("erase conditioned or taken"); continue; }
            let k = c.end_bit;
            if a.bderived[k as usize] { why("outcome bit derived"); continue; }
            // the read bit: a value created by an op (not an input), copyable before the first read
            let mut pick: Option<(u32, u32)> = None;
            for &b in set { if b < 2 { continue; } let cp = copy_point(b); if cp != NQ && cp < c.first_read { pick = Some((b, cp)); break; } }
            let Some((cb, cp)) = pick else { why("no copyable read bit before the first read"); continue };
            let sink = cp >= c.op;
            if sink && c.ctx != 0 { why("CCX under a condition and its read bit made after it"); continue; }
            let mut block: Vec<L> = Vec::new();
            let f = NQ; // the fresh slot is assigned once the site is kept
            if sink {
                // the target is not read, measured or swapped before the new place (XOR-writes into it commute with the
                // moved CCX); operands as affine forms there (disjoint, not the target)
                if (p + 1..=cp as usize).any(|j| { let x = &ops[j]; x.c1 == c.wire || x.c2 == c.wire || (x.t == c.wire && !matches!(x.kind, K_X | K_CX | K_CCX)) }) { why("target used before the bit"); continue; }
                let Some(fs) = forms_at(ops, &a, p, &[o.c1, o.c2], &[cp as usize + 1]) else { why("operand forms break before the bit"); continue };
                let (fa, fb) = (&fs[0][0], &fs[0][1]);
                if dbg == Some(c.op) { eprintln!("  forms a {:?} b {:?}", fa, fb); }
                // hosts: Fa is built into ha (a member, preferably not in Fb); Fb is then rewritten over the current wires
                // (ha now holds Fa) and built into a member hb != ha. Members are only read.
                if fa.0.contains(&c.wire) || fb.0.contains(&c.wire) { why("target in a form"); continue; }
                let ha = *fa.0.iter().find(|w| !fb.0.contains(w)).unwrap_or(&fa.0[0]);
                let mut fbc: Vec<u32> = fb.0.clone(); let mut fbk = fb.1;
                if fb.0.contains(&ha) { for &w in fa.0.iter().filter(|&&w| w != ha) { if let Some(i) = fbc.iter().position(|&x| x == w) { fbc.swap_remove(i); } else { fbc.push(w); } } fbk ^= fa.1; }
                let Some(&hb) = fbc.iter().find(|&&w| w != ha) else { why("no host"); continue };
                let mut on: Vec<L> = Vec::new();
                for &w in fa.0.iter().filter(|&&w| w != ha) { on.push(op(K_CX, w, ha, NQ)); } if fa.1 { on.push(op(K_X, NQ, ha, NQ)); }
                for &w in fbc.iter().filter(|&&w| w != hb) { on.push(op(K_CX, w, hb, NQ)); } if fbk { on.push(op(K_X, NQ, hb, NQ)); }
                block.extend(on.iter().copied());
                block.push(L { kind: K_CCX, c2: ha, c1: hb, t: c.wire, ct: NQ, cc: f, rt: NQ });
                block.extend(on.iter().rev().copied());
            }
            cands.push((c.op, cb, cp, sink, block, k, e as u32));
        }
        // the measured erase's phase fix: every op of the stream under the outcome bit (quantum ops get c; no inner
        // measurement, no other lever's op)
        let want: HashSet<u32> = cands.iter().map(|x| x.5).collect();
        let mut kops: HashMap<u32, Vec<u32>> = HashMap::new();
        for j in 0..ops.len() { for &b in &a.cx.sets[a.opctx[j] as usize] { if want.contains(&b) { kops.entry(b).or_default().push(j as u32); } } }
        for (cop, cb, cp, sink, block, k, _e) in cands {
            let o = ops[cop as usize];
            let mut fixes: Vec<u32> = Vec::new(); let mut bad = false;
            for &j in kops.get(&k).map(|v| v.as_slice()).unwrap_or(&[]) {
                match ops[j as usize].kind { K_HMR | K_R => { bad = true; break; } K_PUSH | K_POP | K_BS0 | K_BS1 | K_BINV => {}
                    // v2 G4: a fix must be phase-only
                    kk if gon && !matches!(kk, K_Z | K_CZ | K_CCZ | K_NEG) => { guard_hit(3); bad = true; break; }
                    _ => fixes.push(j) }
                if ed.touched(j) { bad = true; break; }
            }
            if dbg == Some(cop) || dbg_all { eprintln!("SL_COND_S op {cop} fixes {} bad {bad} sink {sink}", fixes.len()); }
            if bad || fixes.is_empty() || ed.touched(cop) { continue; }
            let f = nb; nb += 1;
            let block: Vec<L> = block.into_iter().map(|mut x| { if x.kind == K_CCX { x.cc = f; } x }).collect();
            ed.after.entry(cp).or_default().extend([L { kind: K_BS0, c2: NQ, c1: NQ, t: NQ, ct: f, cc: NQ, rt: NQ },
                L { kind: K_BINV, c2: NQ, c1: NQ, t: NQ, ct: f, cc: a.bslot[cb as usize], rt: NQ }]);
            if sink { ed.delete.insert(cop); ed.after.get_mut(&cp).unwrap().extend(block); }
            else { let mut x = o; x.cc = f; ed.replace.insert(cop, vec![x]); }
            for &j in &fixes {
                if fault == "s" && !faulted { continue; }
                let x = ops[j as usize];
                let v = if x.cc == NQ { let mut y = x; y.cc = f; vec![y] } else {
                    vec![L { kind: K_PUSH, c2: NQ, c1: NQ, t: NQ, ct: NQ, cc: f, rt: NQ }, x, L { kind: K_POP, c2: NQ, c1: NQ, t: NQ, ct: NQ, cc: NQ, rt: NQ }] };
                ed.replace.insert(j, v);
            }
            if fault == "s" { faulted = true; }
            cnt[3] += 1; sav[3] += 0.5;
            if std::env::var("SL_COND_RVDIAG").is_ok_and(|x| x == "1") {
                let mut kinds: std::collections::BTreeMap<u8, usize> = Default::default();
                for &j in &fixes { *kinds.entry(ops[j as usize].kind).or_default() += 1; }
                let writes = fixes.iter().filter(|&&j| matches!(ops[j as usize].kind, K_X | K_CX | K_CCX | K_SWAP | K_R | K_HMR)).count();
                eprintln!("RVS op {} ccxctx {:?} bit {} copy_point {} sink {} outcome {} fixes {} kinds {:?} write_fixes {} first_fix {} last_fix {}", cop, a.cx.sets[a.opctx[cop as usize] as usize], cb, cp, sink, k, fixes.len(), kinds, writes, fixes.first().copied().unwrap_or(NQ) as i64, fixes.last().copied().unwrap_or(NQ) as i64);
            }
        }
    }
    (ed, cnt, sav)
}

/// r: K3a absorption with a reset end (see the module doc). Returns the edits, sites, CCX absorbed, expected saving.
fn plan_r(ops: &[L], fault: &str) -> (Edits, usize, usize, f64) {
    // A window = the X-type writes (X, CX into it, CCX into it; any condition) into a wire's content since its last
    // read, followed through unconditional swaps, ended by an unconditional reset or measurement. The absorbed part is
    // the shortest suffix of it that holds every CCX and starts at a write before which the measurement can be placed
    // (`ip`: an empty condition stack, no op on the wire in between); earlier writes stay as they are.
    let mut nq = 0u32; for o in ops { for q in [o.c1, o.c2, o.t] { if q != NQ { nq = nq.max(q + 1); } } }
    let mut nb = max_bit(ops);
    let mut window: Vec<Vec<u32>> = vec![Vec::new(); nq as usize]; // writes and swaps of the content, in order
    let mut lo_w: Vec<u32> = vec![0; nq as usize]; // first op after the content's last touch before the window
    let mut last_touch: Vec<u32> = vec![NQ; nq as usize];
    let mut depth_before: Vec<u8> = Vec::with_capacity(ops.len());
    let mut plan: Vec<(Vec<u32>, u32, u32)> = Vec::new();
    let mut depth = 0usize;
    let dbg = std::env::var("SL_COND_DEBUG").is_ok_and(|x| x == "r");
    for (k, o) in ops.iter().enumerate() {
        depth_before.push(depth.min(255) as u8);
        let cond = depth > 0 || o.cc != NQ;
        let rd = |q: u32, window: &mut Vec<Vec<u32>>| { if q != NQ { window[q as usize].clear(); } };
        match o.kind {
            K_PUSH => depth += 1,
            K_POP => depth -= 1,
            K_X | K_CX | K_CCX => {
                if o.kind != K_X { rd(o.c1, &mut window); }
                if o.kind == K_CCX { rd(o.c2, &mut window); }
                let t = o.t as usize;
                if window[t].is_empty() { lo_w[t] = if last_touch[t] == NQ { 0 } else { last_touch[t] + 1 }; }
                window[t].push(k as u32);
            }
            K_CZ => { rd(o.c1, &mut window); rd(o.t, &mut window); }
            K_CCZ => { rd(o.c1, &mut window); rd(o.c2, &mut window); rd(o.t, &mut window); }
            K_Z => { rd(o.t, &mut window); }
            K_SWAP => {
                let (a, b) = (o.c1 as usize, o.t as usize);
                if !cond {
                    window.swap(a, b); lo_w.swap(a, b);
                    for q in [a, b] { if !window[q].is_empty() { window[q].push(k as u32); } }
                } else { rd(o.c1, &mut window); rd(o.t, &mut window); }
            }
            K_R | K_HMR => {
                let t = o.t as usize;
                let w = std::mem::take(&mut window[t]);
                let last_ccx = w.iter().rposition(|&j| ops[j as usize].kind == K_CCX);
                if let (false, Some(lc)) = (cond, last_ccx) {
                    // latest start i <= first CCX ... no: the suffix must hold every CCX, so i <= the first CCX's index;
                    // take the latest such i that admits an insertion point
                    let first_ccx = w.iter().position(|&j| ops[j as usize].kind == K_CCX).unwrap();
                    let _ = lc;
                    let mut found: Option<(usize, u32)> = None;
                    let mut i = first_ccx as isize;
                    while i >= 0 {
                        let iu = i as usize;
                        if ops[w[iu] as usize].kind != K_SWAP {
                            let lo = if iu == 0 { lo_w[t] as usize } else { w[iu - 1] as usize + 1 };
                            let mut j = w[iu] as usize;
                            let mut ip = NQ;
                            loop { if depth_before[j] == 0 { ip = j as u32; break; } if j <= lo { break; } j -= 1; }
                            if ip != NQ { found = Some((iu, ip)); break; }
                        }
                        i -= 1;
                    }
                    match found {
                        Some((iu, ip)) => {
                            let writes: Vec<u32> = w[iu..].iter().copied().filter(|&j| ops[j as usize].kind != K_SWAP).collect();
                            plan.push((writes, k as u32, ip));
                        }
                        None => if dbg { eprintln!("SL_COND_R skip end {k}: no insertion point (first write {})", w[0]); },
                    }
                } else if dbg && last_ccx.is_some() { eprintln!("SL_COND_R skip end {k}: conditional end"); }
            }
            _ => {}
        }
        for q in [o.c1, o.c2, o.t] { if q != NQ { last_touch[q as usize] = k as u32; } }
    }
    let mut ed = Edits::new();
    let mut nccx = 0usize;
    let mut faulted = false;
    for (w, e, ip) in &plan {
        if std::env::var("SL_COND_RVDIAG").is_ok_and(|x| x == "1") {
            let nccx = w.iter().filter(|&&j| ops[j as usize].kind == K_CCX).count();
            let ncond = w.iter().filter(|&&j| ops[j as usize].cc != NQ || depth_before[j as usize] > 0).count();
            let mut nsw = 0; let mut lab = ops[w[0] as usize].t;
            for j in *ip as usize..*e as usize { let x = &ops[j]; if x.kind == K_SWAP { if x.c1 == lab { lab = x.t; nsw += 1; } else if x.t == lab { lab = x.c1; nsw += 1; } } }
            eprintln!("RVR end {} endkind {} ip {} first_write {} writes {} ccx {} cond_writes {} swaps {} label_end_ok {}", e, ops[*e as usize].kind, ip, w[0], w.len(), nccx, ncond, nsw, lab == ops[*e as usize].t);
        }
        let t0 = ops[w[0] as usize].t; // the content's label at the absorbed part's first write (nothing touches it from ip)
        let f = nb; nb += 1;
        ed.before.entry(*ip).or_default().push(L { kind: K_HMR, c2: NQ, c1: NQ, t: t0, ct: f, cc: NQ, rt: NQ });
        for &j in w {
            let x = ops[j as usize];
            let mut p = match x.kind {
                K_X => L { kind: K_NEG, c2: NQ, c1: NQ, t: NQ, ct: NQ, cc: NQ, rt: NQ },
                K_CX => op(K_Z, NQ, x.c1, NQ),
                _ => { nccx += 1; op(K_CZ, x.c1, x.c2, NQ) }
            };
            if fault == "r" && !faulted && x.kind == K_CCX { p = op(K_Z, NQ, x.c1, NQ); faulted = true; }
            let v = if x.cc == NQ { p.cc = f; vec![p] } else {
                p.cc = x.cc;
                vec![L { kind: K_PUSH, c2: NQ, c1: NQ, t: NQ, ct: NQ, cc: f, rt: NQ }, p, L { kind: K_POP, c2: NQ, c1: NQ, t: NQ, ct: NQ, cc: NQ, rt: NQ }] };
            let drop2 = (fault == "r2" && !faulted && x.kind == K_CCX) || (fault == "r3" && !faulted && x.kind != K_CCX);
            if drop2 { faulted = true; }
            ed.replace.insert(j, if drop2 { vec![] } else { v });
        }
        let eo = ops[*e as usize];
        if eo.kind == K_HMR {
            // the old outcome bit takes the moved measurement's value; an idle reset keeps the measurement count
            ed.replace.insert(*e, vec![L { kind: K_BS0, c2: NQ, c1: NQ, t: NQ, ct: eo.ct, cc: NQ, rt: NQ },
                L { kind: K_BINV, c2: NQ, c1: NQ, t: NQ, ct: eo.ct, cc: f, rt: NQ }, L { kind: K_R, c2: NQ, c1: NQ, t: eo.t, ct: NQ, cc: NQ, rt: NQ }]);
        }
    }
    let n = plan.len();
    (ed, n, nccx, nccx as f64)
}

pub fn run(ops: Vec<Op>) -> Vec<Op> {
    let sw = std::env::var("SL_COND").unwrap_or_default();
    if sw.is_empty() || sw == "0" { return ops; }
    let levers = if sw == "1" { "mufsr".to_string() } else { sw };
    let fault = std::env::var("SL_COND_FAULT").unwrap_or_default();
    let mut l: Vec<L> = ops.iter().map(to_l).collect();
    drop(ops);
    let w0 = weight_of(&l);
    if std::env::var("SL_COND_ALIGN").is_ok_and(|v| v == "1") {
        let mut nq = 0u32; for o in &l { for q in [o.c1, o.c2, o.t] { if q != NQ { nq = nq.max(q + 1); } } }
        let idle = L { kind: K_R, c2: NQ, c1: NQ, t: nq, ct: NQ, cc: NQ, rt: NQ };
        let mut ed = Edits::new(); let (mut nu, mut nr) = (0, 0);
        if levers.contains('u') { let (e2, _, _) = plan_muf(&l, "u", ""); for k in e2.replace.keys() { ed.before.entry(*k).or_default().push(idle); nu += 1; } }
        if levers.contains('r') { let (e2, _, _, _) = plan_r(&l, ""); for k in e2.before.keys() { ed.before.entry(*k).or_default().push(idle); nr += 1; } }
        l = ed.apply(&l);
        eprintln!("SL_COND ALIGN: unchanged gate list + idle resets of wire {nq} at {nu} u sites and {nr} r windows");
        return l.iter().map(from_l).collect();
    }
    if levers.contains('m') || levers.contains('u') || levers.contains('f') {
        let first: String = levers.chars().filter(|c| "muf".contains(*c)).collect();
        let (ed, cnt, sav) = plan_muf(&l, &first, &fault);
        l = ed.apply(&l);
        eprintln!("SL_COND m: {} CCX -> CX ({:.2} T); u: {} CCX -> HMR + CZ-if ({:.2} T); f: {} ANDs as phases ({:.2} T)", cnt[0], sav[0], cnt[1], sav[1], cnt[2], sav[2]);
    }
    if levers.contains('s') {
        // on the stream after m, u, f: f turns ANDs read only by phases into CZ reads of their operands, which can leave
        // those operands read only under a bit
        let (ed, cnt, sav) = plan_muf(&l, "s", &fault);
        l = ed.apply(&l);
        eprintln!("SL_COND s: {} ANDs built under their read bit ({:.2} T)", cnt[3], sav[3]);
    }
    if levers.contains('r') {
        let (ed, n, nccx, sav) = plan_r(&l, &fault);
        l = ed.apply(&l);
        eprintln!("SL_COND r: {n} absorbed windows (reset or measured end), {nccx} CCX -> CZ-if ({sav:.2} T)");
    }
    { let g = GUARD_HITS.lock().unwrap(); eprintln!("SL_COND guards{}: G1 {} G2 {} G3 {} G4 {}", if guards_on() { "" } else { " (OFF)" }, g[0], g[1], g[2], g[3]); }
    let w1 = weight_of(&l);
    eprintln!("SL_COND static expected Toffoli {w0:.1} -> {w1:.1} ({:.1}){}", w1 - w0, if fault.is_empty() { String::new() } else { format!("; FAULT {fault}") });
    l.iter().map(from_l).collect()
}

// Lazy construction of a sole AND used only under classical guards.
// Every original measurement stays in place. The measured erase's exact
// CZ twin is suppressed exactly when no read caused the AND to be built.
pub fn lazy_single_reference(ops:Vec<Op>)->Vec<Op>{
 let l:Vec<L>=ops.iter().map(to_l).collect();drop(ops);
 let a=analyze(&l);let mut ed=Edits::new();let mut nb=max_bit(&l);
 let wanted:HashSet<_>=a.contribs.iter().filter(|c|c.end_kind==E_HMR).map(|c|c.end_bit).collect();
 let mut outcome_uses:HashMap<u32,Vec<u32>>=HashMap::new();
 for(j,o)in l.iter().enumerate(){if matches!(o.kind,K_PUSH|K_POP|K_BS0|K_BS1|K_BINV){continue;}for &b in &a.cx.sets[a.opctx[j] as usize]{if wanted.contains(&b){outcome_uses.entry(b).or_default().push(j as u32);}}}
 // Analysis.contribs.reads is deliberately phase-only; gather every physical
 // data/phase read for this distinct pass instead of reusing that field.
 let mut physical_reads:HashMap<u32,Vec<(u32,u32)>>=HashMap::new();
 for(j,o)in l.iter().enumerate(){
  let qs=match o.kind {K_CCX=>[o.c1,o.c2,NQ],K_CX=>[o.c1,NQ,NQ],K_Z=>[o.t,NQ,NQ],K_CZ=>[o.c1,o.t,NQ],K_CCZ=>[o.c1,o.c2,o.t],_=>[NQ;3]};
  for q in qs{if q!=NQ{physical_reads.entry(q).or_default().push((j as u32,a.opctx[j]));}}
 }
 // Accepted target lifetimes and new temporary reads prevent cross-site interference.
 let mut kept:Vec<(u32,u32,u32,Vec<(u32,u32)>)>=vec![];
 let mut selected=0;
 for c in &a.contribs {
  if c.ctx!=0 || c.swapped || c.end_kind!=E_HMR || !c.end_sole {continue;}
  let p=c.op as usize;let e=c.end_op as usize;let original=l[p];
  if original.cc!=NQ || l[e].cc!=NQ || a.opctx[e]!=0 || a.bderived[c.end_bit as usize] || ed.touched(c.op){continue;}
  let Some(all_reads)=physical_reads.get(&c.wire) else{continue;};
  let rs=all_reads.partition_point(|r|r.0<=c.op);let re=all_reads.partition_point(|r|r.0<c.end_op);let these_reads=&all_reads[rs..re];
  if these_reads.is_empty()||these_reads.iter().any(|&(_,ctx)|a.cx.sets[ctx as usize].is_empty()){continue;}
  if (p+1..e).any(|j|{let o=l[j];o.t==c.wire&&matches!(o.kind,K_X|K_CX|K_CCX|K_R|K_HMR|K_SWAP)||o.kind==K_SWAP&&o.c1==c.wire}){continue;}
  let Some(fixes)=a.fixcz.get(&c.end_bit) else{continue;};
  let matches:Vec<_>=fixes.iter().filter(|&&(j,x,y)|((x==c.va&&y==c.vb)||(x==c.vb&&y==c.va))&&a.cx.sets[a.opctx[j as usize] as usize]==vec![c.end_bit]).collect();
  if matches.len()!=1{continue;}let fix=matches[0].0;
  // The outcome may control only its one exact CZ twin, never data operations.
  if outcome_uses.get(&c.end_bit).is_none_or(|v|v.as_slice()!=[fix]){continue;}
  if ed.touched(fix){continue;}
  let mut reads:Vec<usize>=these_reads.iter().map(|r|r.0 as usize).collect();reads.sort_unstable();reads.dedup();
  if reads.iter().any(|&j|j<=p||j>=e){continue;}
  let Some(forms)=forms_at(&l,&a,p,&[original.c1,original.c2],&reads) else{continue;};
  let mut blocks=vec![];let mut uses=vec![];let mut bad=false;
  for (i,&at) in reads.iter().enumerate(){
   let(fa,fb)=(&forms[i][0],&forms[i][1]);
   if fa.0.is_empty()||fb.0.is_empty()||fa.0.contains(&c.wire)||fb.0.contains(&c.wire){bad=true;break;}
   let ha=*fa.0.iter().find(|w|!fb.0.contains(w)).unwrap_or(&fa.0[0]);
   let mut fbc=fb.0.clone();let mut fbk=fb.1;
   if fb.0.contains(&ha){for &w in fa.0.iter().filter(|&&w|w!=ha){if let Some(j)=fbc.iter().position(|&v|v==w){fbc.swap_remove(j);}else{fbc.push(w);}}fbk^=fa.1;}
   let Some(&hb)=fbc.iter().find(|&&w|w!=ha) else{bad=true;break;};
   let mut on=vec![];
   for &w in fa.0.iter().filter(|&&w|w!=ha){on.push(op(K_CX,w,ha,NQ));}if fa.1{on.push(op(K_X,NQ,ha,NQ));}
   for &w in fbc.iter().filter(|&&w|w!=hb){on.push(op(K_CX,w,hb,NQ));}if fbk{on.push(op(K_X,NQ,hb,NQ));}
   for &w in fa.0.iter().chain(fb.0.iter()){uses.push((w,at as u32));}
   blocks.push((at as u32,on,ha,hb));
  }
  if bad{continue;}
  if uses.iter().any(|&(w,t)|kept.iter().any(|&(q,s,z,_)|w==q&&s<t&&t<=z)) || kept.iter().any(|(_,_,_,u)|u.iter().any(|&(w,t)|w==c.wire&&c.op<t&&t<=fix)){continue;}
  let valid=nb;let temporary=nb+1;nb+=2;
  let store=|b:u32,one:bool|L{kind:if one{K_BS1}else{K_BS0},c2:NQ,c1:NQ,t:NQ,ct:b,cc:NQ,rt:NQ};
  let push=|b:u32|L{kind:K_PUSH,c2:NQ,c1:NQ,t:NQ,ct:NQ,cc:b,rt:NQ};
  let pop=L{kind:K_POP,c2:NQ,c1:NQ,t:NQ,ct:NQ,cc:NQ,rt:NQ};
  ed.replace.insert(c.op,vec![store(valid,false),store(temporary,false)]);
  for(at,on,ha,hb)in blocks {
   let mut block=vec![store(temporary,true),L{kind:K_BINV,c2:NQ,c1:NQ,t:NQ,ct:temporary,cc:valid,rt:NQ},push(temporary)];
   if l[at as usize].cc!=NQ{block.push(push(l[at as usize].cc));}
   block.extend(on.iter().copied());block.push(L{kind:K_CCX,c2:hb,c1:ha,t:c.wire,ct:NQ,cc:NQ,rt:NQ});block.extend(on.iter().rev().copied());block.push(store(valid,true));
   if l[at as usize].cc!=NQ{block.push(pop);}
   block.push(pop);block.push(store(temporary,false));
   ed.before.entry(at).or_default().extend(block);
  }
  ed.replace.insert(fix,vec![push(valid),l[fix as usize],pop]);
  let mut clear=fix as usize;while clear<l.len()&&a.depth_after[clear]!=0{clear+=1;}
  assert!(clear<l.len());ed.after.entry(clear as u32).or_default().extend([store(valid,false),store(temporary,false)]);
  kept.push((c.wire,c.op,fix,uses));selected+=1;
  println!("LAZY_SINGLE_SITE producer={} end={} fix={fix} wire={} reads={reads:?}",c.op,c.end_op,c.wire);
 }
 println!("LAZY_SINGLE_SUMMARY selected={selected} new_classical_bits={} quantum_width_unchanged=true",nb-max_bit(&l));
 ed.apply(&l).iter().map(from_l).collect()
}

#[cfg(test)]
mod lazy_single_tests {
 use super::*;
 use quantum_ecc::circuit::{analyze_ops,NO_BIT};
 use quantum_ecc::sim::Simulator;
 struct Words(u64);
 impl sha3::digest::XofReader for Words{fn read(&mut self,out:&mut[u8]){assert_eq!(out.len(),8);out.copy_from_slice(&self.0.to_le_bytes());}}
 fn program(nested:bool)->Vec<Op>{
  let mut p=vec![];let mut r=Op::empty();r.kind=K::Register;r.r_target=RegisterId(0);p.push(r);
  for q in [0,1,3]{let mut o=Op::empty();o.kind=K::AppendToRegister;o.r_target=RegisterId(0);o.q_target=QubitId(q);p.push(o);}
  for b in 0..2{let mut o=Op::empty();o.kind=K::AppendToRegister;o.r_target=RegisterId(0);o.c_target=BitId(b);p.push(o);}
  let list=[L{kind:K_CCX,c2:1,c1:0,t:2,ct:NQ,cc:NQ,rt:NQ},
    op(K_CX,2,3,0),op(K_CX,2,3,1),
    L{kind:K_HMR,c2:NQ,c1:NQ,t:2,ct:2,cc:NQ,rt:NQ},op(K_CZ,0,1,2)];
  p.extend(list.iter().map(from_l));
  if nested {let base=6;p.insert(base+1,from_l(&op(K_CX,0,1,NQ)));let h=p.iter().position(|o|o.kind==K::Hmr).unwrap();p.insert(h,from_l(&op(K_CX,0,1,NQ)));}
  p
 }
 fn check(p:&[Op],q:&[Op])->bool{
  let(nq,nb,_,_)=analyze_ops(p.iter());let(rq,rb,_,_)=analyze_ops(q.iter());assert_eq!(nq,rq);assert!(rb>nb);
  let mut equal=true;let mut saving=0;
  for random in [0,u64::MAX]{
   let mut ra=Words(random);let mut rbng=Words(random);let mut a=Simulator::new(nq as usize,nb as usize,&mut ra);let mut b=Simulator::new(rq as usize,rb as usize,&mut rbng);
   for bit in 0..5{let v=(0..64).fold(0u64,|v,l|v|((((l>>bit)&1)as u64)<<l));match bit{0|1=>{a.qubits[bit]=v;b.qubits[bit]=v;},2=>{a.qubits[3]=v;b.qubits[3]=v;},_=>{a.bits[bit-3]=v;b.bits[bit-3]=v;}}}
   for v in &mut b.bits[nb as usize..]{*v=0xa5a5a5a5a5a5a5a5;}
   a.phase=0x55aa55aa55aa55aa;b.phase=a.phase;
   a.apply_iter(p.iter());b.apply_iter(q.iter());
   equal&=a.qubits==b.qubits&&a.bits==b.bits[..nb as usize]&&a.phase==b.phase&&b.bits[nb as usize..].iter().all(|v|*v==0);
   saving+=a.stats.toffoli_gates as i64-b.stats.toffoli_gates as i64;
  }
  assert!(saving>0);equal
 }
 #[test]fn lazy_single_all_inputs_and_measurements(){let p=program(false);let q=lazy_single(p.clone());assert!(check(&p,&q));}
 #[test]fn lazy_single_nested_affine_hosts(){let p=program(true);let q=lazy_single(p.clone());assert!(check(&p,&q));}
 #[test]fn lazy_single_missing_twin_guard_is_detected(){let p=program(false);let mut q=lazy_single(p.clone());let j=q.iter().position(|o|o.kind==K::CZ&&o.c_condition!=NO_BIT).unwrap();assert_eq!(q[j-1].kind,K::PushCondition);assert_eq!(q[j+1].kind,K::PopCondition);q.remove(j+1);q.remove(j-1);assert!(!check(&p,&q));}
}

pub fn lazy_single(ops:Vec<Op>)->Vec<Op>{
 let l:Vec<L>=ops.iter().map(to_l).collect();drop(ops);
 let a=analyze(&l);let mut ed=Edits::new();let mut nb=max_bit(&l);
 let wanted:HashSet<_>=a.contribs.iter().filter(|c|c.end_kind==E_HMR).map(|c|c.end_bit).collect();
 let mut outcome_uses:HashMap<u32,Vec<u32>>=HashMap::new();
 for(j,o)in l.iter().enumerate(){if matches!(o.kind,K_PUSH|K_POP|K_BS0|K_BS1|K_BINV){continue;}for &b in &a.cx.sets[a.opctx[j] as usize]{if wanted.contains(&b){outcome_uses.entry(b).or_default().push(j as u32);}}}
 // Analysis.contribs.reads is deliberately phase-only; gather every physical
 // data/phase read for this distinct pass instead of reusing that field.
 let mut physical_reads:HashMap<u32,Vec<(u32,u32)>>=HashMap::new();
 for(j,o)in l.iter().enumerate(){
  let qs=match o.kind {K_CCX=>[o.c1,o.c2,NQ],K_CX=>[o.c1,NQ,NQ],K_Z=>[o.t,NQ,NQ],K_CZ=>[o.c1,o.t,NQ],K_CCZ=>[o.c1,o.c2,o.t],_=>[NQ;3]};
  for q in qs{if q!=NQ{physical_reads.entry(q).or_default().push((j as u32,a.opctx[j]));}}
 }
 // Accepted target lifetimes and new temporary reads prevent cross-site interference.
 let mut kept:Vec<(u32,u32,u32,Vec<(u32,u32)>)>=vec![];
 let mut selected=0;
 for (ci,c) in a.contribs.iter().enumerate() {
  if c.ctx!=0 || c.swapped || c.end_kind!=E_HMR {continue;}
  let p=c.op as usize;let e=c.end_op as usize;let original=l[p];
  if original.cc!=NQ || l[e].cc!=NQ || a.opctx[e]!=0 || ed.touched(c.op){continue;}
  let Some(all_reads)=physical_reads.get(&c.wire) else{continue;};
  let rs=all_reads.partition_point(|r|r.0<=c.op);let re=all_reads.partition_point(|r|r.0<c.end_op);let these_reads=&all_reads[rs..re];
  if these_reads.is_empty()||these_reads.iter().any(|&(_,ctx)|a.cx.sets[ctx as usize].is_empty()){continue;}
  if (p+1..e).any(|j|{let o=l[j];o.t==c.wire&&matches!(o.kind,K_X|K_CX|K_CCX|K_R|K_HMR|K_SWAP)||o.kind==K_SWAP&&o.c1==c.wire}){continue;}
  let Some(fixes)=a.fixcz.get(&c.end_bit) else{continue;};
  let matches:Vec<_>=fixes.iter().filter(|&&(j,x,y)|((x==c.va&&y==c.vb)||(x==c.vb&&y==c.va))&&a.cx.sets[a.opctx[j as usize] as usize]==vec![c.end_bit]).collect();
  if matches.len()!=1{continue;}let fix=matches[0].0;
  // The outcome may control only its one exact CZ twin, never data operations.
  // Unchanged HMR draws make arbitrary original outcome uses and descendants safe.
  if ed.touched(fix){continue;}
  let mut reads:Vec<usize>=these_reads.iter().map(|r|r.0 as usize).collect();reads.sort_unstable();reads.dedup();
  if reads.iter().any(|&j|j<=p||j>=e){continue;}

  let affine=forms_at(&l,&a,p,&[original.c1,original.c2],&reads);
  let mut forms=Vec::new();let mut admitted=true;let mut holder_uses=0;
  for (ri,&at)in reads.iter().enumerate(){
   let aliases=a.guard_readhold.get(&(ci as u32,at as u32));
   let alias=aliases.and_then(|&(x,y)|{
    if [x,y].iter().any(|&q|q==c.wire||kept.iter().any(|&(w,s,z,_)|w==q&&s<(at as u32)&&(at as u32)<=z)){None}else{Some((x,y))}
   });
   if let Some((x,y))=alias{forms.push(vec![(vec![x],false),(vec![y],false)]);holder_uses+=1;}
   else if let Some(ref fs)=affine{forms.push(fs[ri].clone());}
   else{admitted=false;break;}
  }
  if !admitted{continue;}

  let mut blocks=vec![];let mut uses=vec![];let mut bad=false;
  for (i,&at) in reads.iter().enumerate(){
   let(fa,fb)=(&forms[i][0],&forms[i][1]);
   if fa.0.is_empty()||fb.0.is_empty()||fa.0.contains(&c.wire)||fb.0.contains(&c.wire){bad=true;break;}
   let ha=*fa.0.iter().find(|w|!fb.0.contains(w)).unwrap_or(&fa.0[0]);
   let mut fbc=fb.0.clone();let mut fbk=fb.1;
   if fb.0.contains(&ha){for &w in fa.0.iter().filter(|&&w|w!=ha){if let Some(j)=fbc.iter().position(|&v|v==w){fbc.swap_remove(j);}else{fbc.push(w);}}fbk^=fa.1;}
   let Some(&hb)=fbc.iter().find(|&&w|w!=ha) else{bad=true;break;};
   let mut on=vec![];
   for &w in fa.0.iter().filter(|&&w|w!=ha){on.push(op(K_CX,w,ha,NQ));}if fa.1{on.push(op(K_X,NQ,ha,NQ));}
   for &w in fbc.iter().filter(|&&w|w!=hb){on.push(op(K_CX,w,hb,NQ));}if fbk{on.push(op(K_X,NQ,hb,NQ));}
   for &w in fa.0.iter().chain(fb.0.iter()){uses.push((w,at as u32));}
   blocks.push((at as u32,on,ha,hb));
  }
  if bad{continue;}
  if uses.iter().any(|&(w,t)|kept.iter().any(|&(q,s,z,_)|w==q&&s<t&&t<=z)) || kept.iter().any(|(_,_,_,u)|u.iter().any(|&(w,t)|w==c.wire&&c.op<t&&t<=fix)){continue;}
  let valid=nb;let temporary=nb+1;nb+=2;
  let store=|b:u32,one:bool|L{kind:if one{K_BS1}else{K_BS0},c2:NQ,c1:NQ,t:NQ,ct:b,cc:NQ,rt:NQ};
  let push=|b:u32|L{kind:K_PUSH,c2:NQ,c1:NQ,t:NQ,ct:NQ,cc:b,rt:NQ};
  let pop=L{kind:K_POP,c2:NQ,c1:NQ,t:NQ,ct:NQ,cc:NQ,rt:NQ};
  ed.replace.insert(c.op,vec![store(valid,false),store(temporary,false)]);
  for(at,on,ha,hb)in blocks {
   let mut block=vec![store(temporary,true),L{kind:K_BINV,c2:NQ,c1:NQ,t:NQ,ct:temporary,cc:valid,rt:NQ},push(temporary)];
   if l[at as usize].cc!=NQ{block.push(push(l[at as usize].cc));}
   block.extend(on.iter().copied());block.push(L{kind:K_CCX,c2:hb,c1:ha,t:c.wire,ct:NQ,cc:NQ,rt:NQ});block.extend(on.iter().rev().copied());block.push(store(valid,true));
   if l[at as usize].cc!=NQ{block.push(pop);}
   block.push(pop);block.push(store(temporary,false));
   ed.before.entry(at).or_default().extend(block);
  }
  ed.replace.insert(fix,vec![push(valid),l[fix as usize],pop]);
  let mut clear=fix as usize;while clear<l.len()&&a.depth_after[clear]!=0{clear+=1;}
  assert!(clear<l.len());ed.after.entry(clear as u32).or_default().extend([store(valid,false),store(temporary,false)]);
  kept.push((c.wire,c.op,fix,uses));selected+=1;
  println!("LAZY_SINGLE_SITE producer={} end={} fix={fix} wire={} reads={reads:?}",c.op,c.end_op,c.wire);
 }
 println!("LAZY_SINGLE_SUMMARY selected={selected} new_classical_bits={} quantum_width_unchanged=true",nb-max_bit(&l));
 ed.apply(&l).iter().map(from_l).collect()
}

#[cfg(test)]
mod guard_tree_tests {
 use super::*;
 use quantum_ecc::circuit::{analyze_ops,NO_BIT};
 use quantum_ecc::sim::Simulator;
 struct Words(u64);
 impl sha3::digest::XofReader for Words{fn read(&mut self,out:&mut[u8]){assert_eq!(out.len(),8);out.copy_from_slice(&self.0.to_le_bytes());}}
 fn program(nested:bool)->Vec<Op>{
  let mut p=vec![];let mut r=Op::empty();r.kind=K::Register;r.r_target=RegisterId(0);p.push(r);
  for q in [0,1,3]{let mut o=Op::empty();o.kind=K::AppendToRegister;o.r_target=RegisterId(0);o.q_target=QubitId(q);p.push(o);}
  for b in 0..2{let mut o=Op::empty();o.kind=K::AppendToRegister;o.r_target=RegisterId(0);o.c_target=BitId(b);p.push(o);}
  let list=[L{kind:K_CCX,c2:1,c1:0,t:2,ct:NQ,cc:NQ,rt:NQ},
    op(K_CX,2,3,0),op(K_CX,2,3,1),
    L{kind:K_HMR,c2:NQ,c1:NQ,t:2,ct:2,cc:NQ,rt:NQ},op(K_CZ,0,1,2)];
  p.extend(list.iter().map(from_l));
  if nested {let base=6;p.insert(base+1,from_l(&op(K_CX,0,1,NQ)));let h=p.iter().position(|o|o.kind==K::Hmr).unwrap();p.insert(h,from_l(&op(K_CX,0,1,NQ)));}
  p
 }
 fn check(p:&[Op],q:&[Op])->bool{
  let(nq,nb,_,_)=analyze_ops(p.iter());let(rq,rb,_,_)=analyze_ops(q.iter());assert_eq!(nq,rq);assert!(rb>nb);
  let mut equal=true;let mut saving=0;
  for random in [0,u64::MAX]{
   let mut ra=Words(random);let mut rbng=Words(random);let mut a=Simulator::new(nq as usize,nb as usize,&mut ra);let mut b=Simulator::new(rq as usize,rb as usize,&mut rbng);
   for bit in 0..5{let v=(0..64).fold(0u64,|v,l|v|((((l>>bit)&1)as u64)<<l));match bit{0|1=>{a.qubits[bit]=v;b.qubits[bit]=v;},2=>{a.qubits[3]=v;b.qubits[3]=v;},_=>{a.bits[bit-3]=v;b.bits[bit-3]=v;}}}
   if p.iter().any(|o|o.kind==K::AppendToRegister&&o.q_target==QubitId(2)){let v=(0..64).fold(0u64,|v,l|v|((((l>>5)&1)as u64)<<l));a.qubits[2]=v;b.qubits[2]=v;}
   for v in &mut b.bits[nb as usize..]{*v=0xa5a5a5a5a5a5a5a5;}
   a.phase=0x55aa55aa55aa55aa;b.phase=a.phase;
   a.apply_iter(p.iter());b.apply_iter(q.iter());
   equal&=a.qubits==b.qubits&&a.bits==b.bits[..nb as usize]&&a.phase==b.phase&&b.bits[nb as usize..].iter().all(|v|*v==0);
   saving+=a.stats.toffoli_gates as i64-b.stats.toffoli_gates as i64;
  }
  assert!(saving>0);equal
 }
 #[test]fn lazy_single_all_inputs_and_measurements(){let p=program(false);let q=lazy_single(p.clone());assert!(check(&p,&q));}
 #[test]fn lazy_single_nested_affine_hosts(){let p=program(true);let q=lazy_single(p.clone());assert!(check(&p,&q));}
 #[test]fn lazy_single_missing_twin_guard_is_detected(){let p=program(false);let mut q=lazy_single(p.clone());let j=q.iter().position(|o|o.kind==K::CZ&&o.c_condition!=NO_BIT).unwrap();assert_eq!(q[j-1].kind,K::PushCondition);assert_eq!(q[j+1].kind,K::PopCondition);q.remove(j+1);q.remove(j-1);assert!(!check(&p,&q));}
 struct Sequence{words:Vec<u64>,at:usize}
 impl sha3::digest::XofReader for Sequence{fn read(&mut self,out:&mut[u8]){assert_eq!(out.len(),8);out.copy_from_slice(&self.words[self.at].to_le_bytes());self.at+=1;}}
 fn exhaustive(p:&[Op],q:&[Op]){
  let(nq,nb,_,_)=analyze_ops(p.iter());let(rq,rb,_,_)=analyze_ops(q.iter());assert_eq!(nq,rq);assert!(rb>nb);
  let count=p.iter().filter(|o|matches!(o.kind,K::Hmr|K::R)).count();assert_eq!(count,q.iter().filter(|o|matches!(o.kind,K::Hmr|K::R)).count());assert!(count<=4);
  let mut saved=0;
  for assignment in 0..1usize<<count{for dirty in [0,u64::MAX,0xa5a5a5a5a5a5a5a5]{
   let words:Vec<_>=(0..count).map(|i|if assignment>>i&1==0{0}else{u64::MAX}).collect();let mut ra=Sequence{words:words.clone(),at:0};let mut rr=Sequence{words,at:0};
   let mut a=Simulator::new(nq as usize,nb as usize,&mut ra);let mut b=Simulator::new(rq as usize,rb as usize,&mut rr);
   for bit in 0..5{let v=(0..64).fold(0u64,|v,l|v|((((l>>bit)&1)as u64)<<l));match bit{0|1=>{a.qubits[bit]=v;b.qubits[bit]=v;},2=>{a.qubits[3]=v;b.qubits[3]=v;},_=>{a.bits[bit-3]=v;b.bits[bit-3]=v;}}}
   if p.iter().any(|o|o.kind==K::AppendToRegister&&o.q_target==QubitId(2)){let v=(0..64).fold(0u64,|v,l|v|((((l>>5)&1)as u64)<<l));a.qubits[2]=v;b.qubits[2]=v;}
   for x in &mut b.bits[nb as usize..]{*x=dirty;}a.phase=0x55aa55aa55aa55aa;b.phase=a.phase;
   a.apply_iter(p.iter());b.apply_iter(q.iter());assert_eq!(a.qubits,b.qubits);assert_eq!(a.bits,&b.bits[..nb as usize]);assert_eq!(a.phase,b.phase);assert!(b.bits[nb as usize..].iter().all(|x|*x==0));saved+=a.stats.toffoli_gates as i64-b.stats.toffoli_gates as i64;
   drop(a);drop(b);assert_eq!(ra.at,rr.at);assert_eq!(ra.at,count);
  }}assert!(saved>0);
 }
 #[test]fn guard_tree_derived_outcome_and_extra_data_phase_uses(){
  let mut p=program(false);let j=p.iter().position(|o|o.kind==K::Hmr).unwrap()+1;
  let extra=[L{kind:K_BS1,c2:NQ,c1:NQ,t:NQ,ct:3,cc:NQ,rt:NQ},L{kind:K_BINV,c2:NQ,c1:NQ,t:NQ,ct:3,cc:2,rt:NQ},op(K_CX,0,3,3),op(K_Z,NQ,3,2)];p.splice(j..j,extra.iter().map(from_l));
  let l:Vec<_>=p.iter().map(to_l).collect();let a=analyze(&l);assert!(a.contribs.iter().any(|c|c.end_kind==E_HMR&&a.bderived[c.end_bit as usize]));let q=lazy_single(p.clone());exhaustive(&p,&q);
 }
 #[test]fn guard_tree_alias_survives_original_control_measurement(){
  let mut p=program(false);let prod=p.iter().position(|o|o.kind==K::CCX).unwrap();p.insert(prod,from_l(&op(K_CX,0,4,NQ)));
  let prod=p.iter().position(|o|o.kind==K::CCX).unwrap();p.insert(prod+1,from_l(&L{kind:K_HMR,c2:NQ,c1:NQ,t:0,ct:3,cc:NQ,rt:NQ}));
  let fix=p.iter_mut().find(|o|o.kind==K::CZ).unwrap();fix.q_control1=QubitId(4);
  let q=lazy_single(p.clone());exhaustive(&p,&q);
 }
 #[test]fn guard_tree_dirty_quantum_target_all_inputs_and_measurements(){
  let mut p=program(false);let mut app=Op::empty();app.kind=K::AppendToRegister;app.r_target=RegisterId(0);app.q_target=QubitId(2);p.insert(4,app);
  let l:Vec<_>=p.iter().map(to_l).collect();let a=analyze(&l);assert!(a.contribs.iter().any(|c|c.end_kind==E_HMR&&!c.end_sole));let q=lazy_single(p.clone());exhaustive(&p,&q);
 }
}
