//! Joint retained-final-carry / overlapping low-constant fold experiment.
//! It preserves the original B comparisons, exactly erases the inserted
//! prefix boundary and final overflow, and explicitly changes the low fold.
use super::*;
thread_local! { pub(super) static DPARK:std::cell::Cell<bool>=const{std::cell::Cell::new(false)}; }
// PP_U_DPARK layout shadow: plan the chunk layout as if d still held a wire.
thread_local! { pub(super) static DSHADOW:std::cell::Cell<usize>=const{std::cell::Cell::new(0)}; }
pub(super) fn dshadow()->usize {DSHADOW.with(|p|p.get())}
// PP_U_C0WIDE: with the prebias double, chunk 0 has no carry-in and one wire of slack.
thread_local! { static C0SHIFT:std::cell::Cell<bool>=const{std::cell::Cell::new(false)}; }
thread_local! { pub(super) static GUARD:std::cell::Cell<Option<usize>>=const{std::cell::Cell::new(None)}; }

fn low_bits(guard:usize)->usize { super::super::optional_env::<usize>("PP_JOINT_LOW_BITS").unwrap_or(32+guard) }

#[derive(Debug)]
struct Plan { bounds:Vec<(usize,usize)>, prefix:usize, guard:usize, bits:usize, saving:f64, exact:bool, dropped:bool }

fn plan(circ:&Builder,round:usize,multiply:bool,fw:usize,drop:bool)->Option<Plan> {
    if !multiply && env_raw("PP_PREBIAS_RETAIN_BITS").is_some() {return None;}
    let guard=super::super::optional_env::<usize>("PP_JOINT_GUARD")?;
    let low=if env_flag("PP_SPRINT_MIXED") && multiply && (364..=402).contains(&round) {29}else{(low_bits(guard) as isize+super::super::go_slice("GO_JLB",round,if multiply{b'm'}else{b'd'})) as usize};assert!((12..=fw).contains(&low) && !split_fold());

    assert!(env_flag("PP_REUSE_DIV_PARITY") && env_flag("PP_REUSE_MUL_SELECTORS"));
    let room=walk_max_qubits().saturating_sub(circ.active_qubits()as usize);
    let loans=REPLAY_SIGN_LOANS.with(|s|s.get());
    let Some(old_bounds)=composition_bounds(circ,round,multiply) else {if !drop{drop_trace(round,multiply,"nocomp",String::new());}return None;};
    let (bounds,db)=if drop {drop_exact_lead(circ,&old_bounds,round,multiply,fw)?}
        else {(retained_rebalance(circ,&old_bounds,round,multiply),0.0)};
    if bounds.len()<2 {return None;}
    let bounds=if C0SHIFT.with(|c|c.get()) {
        let n=bounds.len();if bounds[n-1].1-bounds[n-1].0<=2 {return None;}
        bounds.iter().enumerate().map(|(j,&(lo,hi))|(if j==0{lo}else{lo+1},if j==n-1{hi}else{hi+1})).collect::<Vec<_>>()
    } else {bounds};
    let &(lo,hi)=bounds.last()?;
    let (plo,phi)=bounds[bounds.len()-2];
    let (k,seeded)=boundary_repair_spec(round,multiply,plo,phi);
    if lo<fw || phi-k-usize::from(seeded)<fw {drop_trace(round,multiply,"lofw",format!("drop={} fw={} {:?}",drop,fw,bounds));return None;}
    let need=(low-3).max(fw-34);
    let existing=walk_max_qubits()as isize-circ.active_qubits()as isize-(hi-lo)as isize-if multiply&&env_flag("PP_JOINT_MUL_FOLD"){3}else{4}-(multiply&&DPARK.with(|p|p.get())) as isize;
    let missing=(need as isize-existing).max(0)as usize;
    let prefix=if missing==0 {0} else {missing+1};
    if prefix+1>=hi-lo {drop_trace(round,multiply,"prefix",format!("drop={} fw={} missing={} {:?}",drop,fw,missing,bounds));return None;}
    let mut fk=if multiply {flag_compare(round)+usize::from(a5_policy()=="mul-f-plus1-early200"&&(2..202).contains(&round))}
        else {flag_compare(round)+usize::from(policy_width(round)>=flag_widen_div())};
    // EXP PP_SEED_SHORT_MUL_F_COST: the plain path's narrow multiply F compare is one bit shorter.
    let short_cost=multiply && policy_width(round)<38 && env_flag("PP_SEED_SHORT_MUL_F_COST") && !env_flag("PP_SEED_SHORT_MUL_F_COST_NOPLAN");
    let seeded=if multiply {(policy_width(round)>=38 && matches!(a5_policy(),"mul-f-seed"|"mul-fb-seed")) || short_cost}else{env_flag("CMP_SEED_ALL")};
    if (!multiply && seeded) || short_cost {fk-=1;}
    if !seeded {fk=refined_unseeded_width(fk,N,"PP_REFINE_UNSEEDED_F");}
    let saving=(fk-1)as f64/2.0-missing as f64/2.0-(low as f64-33.0)-db;
    if saving<=0.0 {drop_trace(round,multiply,"saving",format!("drop={} fw={} fk={} missing={} db={} {:?}",drop,fw,fk,missing,db,bounds));return None;}
    // Release a bounded additional carry prefix to fit the full finite fold.
    // Outer B comparisons are unchanged; the inserted midpoint uses exact cleanup.
    let limit=super::super::optional_env::<usize>("PP_RETAIN_EXACT_EXTRA_MUL").unwrap_or(0);
    let exact_missing=((fw-3) as isize-existing).max(0) as usize;
    let exact_prefix=if exact_missing==0 {0}else{exact_missing+1};
    let exact=(multiply && env_flag("PP_RETAIN_EXACT_MUL") && exact_missing<=limit || drop_exact_lead_exact(drop,exact_missing)) && exact_prefix+1<hi-lo;
    let prefix=if exact {exact_prefix}else{prefix};
    let saving=if exact {saving-(exact_missing-missing) as f64/2.0-1.0}else{saving};
    if !drop_exact_lead_minsave(drop,saving) {return None;}
    Some(Plan{bounds,prefix,guard,bits:low,saving,exact,dropped:drop})
}

pub(super) fn try_replay(circ:&mut Builder,sign:QubitId,a:&[QubitId],b:&[QubitId],fw:usize,
    round:usize,doubled:Option<QubitId>)->bool {
    let multiply=doubled.is_some();
    let mk=|circ:&Builder|plan(circ,round,multiply,fw,false).or_else(||plan(circ,round,multiply,fw,true));
    let park=multiply&&DPARK.with(|p|p.get());
    let shadow=|circ:&Builder|{DSHADOW.with(|p|p.set(1));let q=mk(circ);DSHADOW.with(|p|p.set(0));q};
    // Pick the cheaper of the parked and the shadow layout: boundary compares minus fold saving.
    let cost=|p:&Plan|p.bounds[..p.bounds.len()-1].iter().enumerate().map(|(j,&(lo,hi))|{
        let (k,_)=if p.dropped&&j==0 {drop_lead_first_compare(round,multiply,hi)}else{boundary_repair_spec(round,multiply,lo,hi)};
        (k as f64-1.0)/2.0}).sum::<f64>()-p.saving;
    let c0=multiply&&env_flag("PP_U_C0WIDE")&&env_flag("PP_PREBIAS_DOUBLE");
    let p=if c0 {
        let mut cands=Vec::new();
        for sh in [false,true] {C0SHIFT.with(|c|c.set(sh));cands.push(mk(circ));if park {cands.push(shadow(circ));}}
        C0SHIFT.with(|c|c.set(false));
        cands.into_iter().flatten().min_by(|x,y|cost(x).partial_cmp(&cost(y)).unwrap())
    } else if park&&env_flag("PP_U_DPARK_BEST") {
        match (mk(circ),shadow(circ)) {
            (Some(a),Some(b))=>Some(if cost(&b)<cost(&a){b}else{a}),(a,b)=>a.or(b)}
    } else {mk(circ).or_else(||if park {shadow(circ)} else {None})};
    let Some(p)=p else{return false;};
    if p.dropped {eprintln!("DROP_EXACT_LEAD mul={} r={} base={} saving={} bounds={:?}",multiply as u8,round,circ.active_qubits(),p.saving,p.bounds);}
    eprintln!("JOINT_LOWFOLD r={} mul={} base={} last={} prefix={} guard={} saving={}",round,multiply as u8,
        circ.active_qubits(),p.bounds.last().unwrap().1-p.bounds.last().unwrap().0,p.prefix,p.guard,p.saving);
    if env_flag("PP_COMPOSE_TRACE"){eprintln!("COMPOSE_MUL {} {} {} {} {} {:?}",round,circ.active_qubits(),fw,p.bits,REPLAY_SIGN_LOANS.with(|s|s.get()),p.bounds);}
    if p.exact {eprintln!("EXACT_RETAINED_FOLD mul {} {}",round,fw);}
    super::super::leapfrog::y17_log(circ,||format!("joint(r={round},room={},fw={fw},bits={},prefix={},exact={},dropped={},loans={},bridge={},bounds={:?})",walk_max_qubits().saturating_sub(circ.active_qubits()as usize),p.bits,p.prefix,p.exact,p.dropped,REPLAY_SIGN_LOANS.with(|s|s.get()),super::super::bridge::budget(),p.bounds.iter().map(|&(a,b)|b-a).collect::<Vec<_>>()));
    let mut incoming=None;
    let mut previous=None;
    // EXP PP_PREBIAS_DOUBLE: bit 0 leaves the main add. z0 = s^a0 by CX, and the
    // missing carry s&a0 joins the fold's own bit-1 carry (the two are exclusive).
    let pre=multiply && env_flag("PP_PREBIAS_DOUBLE");
    if pre {circ.cx(a[0],b[0]);}
    for &(lo,hi)in &p.bounds {
        let next=circ.alloc_qubit();
        if hi==N {
            let split=lo+p.prefix;
            let mid=if p.prefix==0 {incoming}else{
                let m=circ.alloc_qubit();ripple_add(circ,&a[lo..split],&b[lo..split],incoming,Some(m));Some(m)
            };
            super::super::modular::ripple_add_consume(circ,&a[split..hi],&b[split..hi],mid,next,
                |c,o,at,st,carry|{
                    GUARD.with(|g|{assert!(g.replace(if p.exact {None}else{Some(p.bits)}).is_none());});
                    if let Some(d)=doubled {
                        // PP_U_DPARK: d lives in b0 as d^sign^a0; take it back out.
                        let d=if DPARK.with(|p|p.get()) {assert!(pre);
                            let d=c.alloc_qubit();c.cx(b[0],d);c.cx(sign,d);c.cx(a[0],d);c.cx(d,b[0]);d} else {d};
                        if env_flag("PP_JOINT_MUL_FOLD"){fold_double_joint(c,&b[..fw],sign,a[0],d,o,pre);}else{fold_double_reused(c,&b[..fw],sign,d,o);}
                        c.cx(b[0],d);c.cx(sign,d);c.cx(a[0],d);c.cx(o,d);c.free(d);
                    }else{fold_halve_reused(c,&b[..fw],sign,o);}
                    GUARD.with(|g|g.set(None));
                    super::super::modular::erase_overflow_from_frame(c,o,at,st,carry);
                });
            if p.prefix>0 {
                let mid=mid.unwrap();
                // Exact: carry(a+b+incoming) = [sum<a]+[sum=a]*incoming.
                erase_with_compare(circ,mid,&b[lo..split],&a[lo..split],incoming);circ.free(mid);
            }
        }else{let at=if pre&&lo==0{1}else{lo};ripple_add(circ,&a[at..hi],&b[at..hi],incoming,Some(next));}
        if let Some((q,plo,phi))=previous {
            let(k,seeded)=if p.dropped&&plo==0 {drop_lead_first_compare(round,multiply,phi)}else{boundary_repair_spec(round,multiply,plo,phi)};let k=if seeded&&plo>0{e_badj(round,multiply,k,phi,if hi==N{fw}else{1})}else{k};
            let k=if super::super::leapfrog::C35_CMP_FX.with(|x|x.get()){k.min(2)}else{k};
            circ.record_replay_site('B',round,phi,k);
            // A full first-chunk compare must skip bit 0, which the add no longer covers.
            let from=if pre&&plo==0&&phi==k{1}else{phi-k};
            erase_with_compare(circ,q,&b[from..phi],&a[from..phi],seeded.then(||a[phi-k-1]));circ.free(q);
        }
        incoming=Some(next);previous=Some((next,lo,hi));
    }
    true
}

pub(super) fn fold(circ:&mut Builder,acc:&[QubitId],f:U256,plus:QubitId,twice:Option<QubitId>,minus:QubitId,first:QubitId,g:usize) {
    assert_eq!(f>>32usize,U256::from(1));let low=g;assert!(low<=acc.len());
    let small=f&((U256::from(1)<<32usize)-U256::from(1));
    fold_selected_single(circ,&acc[..low],small,plus,twice,minus,first);
    let boundary=circ.alloc_qubit();
    with_selector_xor(circ,&[plus,minus],plus,|c,q|c.ccx(acc[32],q,boundary));
    fold_selected_single(circ,&acc[32..],U256::from(1),plus,twice,minus,boundary);
    with_selector_xor(circ,&[plus,minus],plus,|c,q|{
        c.cx(q,acc[32]);and_uncompute(c,boundary,acc[32],q);c.cx(q,acc[32]);
    });
}
