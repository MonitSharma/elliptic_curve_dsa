# Strong proved-clean epochs for the highest quantum role

Declared before launch. New copy-cache input, existing exact strong support
semantics, fixed16-term/32-factor limits. Add only read-only metadata, with NO
new Boolean/abstraction queries. Require all12 old controls plus3 boundary
controls, identical whole output hash and every old report field on the same
complete input. Find every high-role interval ending in proved global zero,
including conditional resets; report all donor counts but only8 donor IDs.
This refines the lexical footprint's three multi-million-op intervals and
two trailing uses. It is NOT the old negative support-branch alias screen:
future leasing uncomputes/restores a held value and needs an independent
value identity. No alias, circuit rewrite, width result, gate or nonce here.
One server CPU/12GiB. Preserve original/failed sources and running jobs.
