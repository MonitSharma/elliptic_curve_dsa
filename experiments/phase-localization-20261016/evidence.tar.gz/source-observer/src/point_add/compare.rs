use super::Builder;
use crate::circuit::QubitId;

/// `u < v` as a phase, applied inside whatever classical condition is already
/// pushed. The caller owns the condition.
///
/// The ladder runs on `~u`, so its carry-out is the carry of `~u + v`, which
/// overflows exactly when `v > u`. `carries[i]` takes the borrow out of bit `i`
/// and `u[i]` is left holding the running prefix; the inverse pass measures each
/// carry out and repairs its phase, so unwinding is free. The top bit never
/// needs a wire at all: its carry step `MAJ(u_top, v_top, carry)` is wanted only
/// as a phase, and `(-1)^(x^y) = (-1)^x (-1)^y` splits that MAJ into three CZs.
///
/// `borrow_in` is the borrow entering bit 0, for a caller that has already
/// accounted for the bits below by other means. With `None` the comparison
/// starts clean, and after the first CX `u[0]` already holds what a clean
/// carry-in wire would have held — so it serves as the first nonlinear control
/// and no wire is needed either way.
#[track_caller]
pub(crate) fn cmp_lt_phase(circ: &mut Builder, u: &[QubitId], v: &[QubitId], borrow_in: Option<QubitId>) {
    // C35_TRACE (no effect on the gates): the call site, width and seed of every phase compare.
    if true { let l = std::panic::Location::caller(); eprintln!("C35_SITE\t{}:{}\t{}\t{}\t{}", l.file(), l.line(), u.len(), borrow_in.is_some() as u8, circ.op_count()); }
    let macro_compare_at=circ.op_count();
    cmp_lt_phase_v0(circ, u, v, borrow_in, None);
    eprintln!("C35_END\t{}\t{}\t{}\t{}",macro_compare_at,circ.op_count(),u.len(),borrow_in.is_some()as u8);
}

/// R5_CCMP (sky-PM Round 5): [`cmp_lt_phase`] where `v[0]` is known to hold the classical bit `v0cl`
/// (a register loaded from classical data). The first carry `u0' & (v0 ^ u0') = u0' & !v0` is then a
/// CX plus a classically conditioned CX: one Toffoli less, same predicate, same measurements.
pub(crate) fn cmp_lt_phase_v0(circ: &mut Builder, u: &[QubitId], v: &[QubitId], borrow_in: Option<QubitId>, v0cl: Option<crate::circuit::BitId>) {
    if super::dirty_boundary_probe::try_tail(circ,u,v,borrow_in){return;}
    if super::constant_templates::square_compare(circ,u,v,borrow_in){return;}
    let _dirty_trace=super::dirty_boundary_probe::Trace::new(circ,"cmp_lt_phase",u.len());

    let n = u.len();
    assert_eq!(v.len(), n);
    // Two bits is the narrowest comparison any caller asks for: the walk's
    // boundary repair is the only one that supplies a borrow, and
    // `walk_low_chunk` only splits when `low >= 4`, which leaves it `low - 2`
    // bits wide.
    assert!(n > 1);
    // A source-bit predictor may now lie inside a widened comparison window.
    // If it is the first source bit, MAJ(!u0,v0,v0)=v0: that whole position
    // is redundant. Otherwise restore the predictor before its operand bit
    // is read, and recreate the first control only for the final phase erase.
    // No separate predictor copy or extra nonlinear gate is necessary.
    if borrow_in==Some(v[0]) {
        assert!(n>=3,"aliased low seed needs at least two remaining comparison bits");
        return cmp_lt_phase_v0(circ,&u[1..],&v[1..],borrow_in,None);
    }
    let operand_seed=borrow_in.is_some_and(|q|v[1..].contains(&q));
    assert!(!borrow_in.is_some_and(|q|u.contains(&q)),"seed cannot alias the accumulator");
    let last = n - 1;

    // C35_WIDEN diagnostics (pads = 0 in every kept build): idle wires taken before the carries, measured after them
    let pads = super::leapfrog::C35_PADS.with(|p| p.replace(0));
    let all = circ.alloc_qubits(pads + last);
    let carries = &all[pads..];
    circ.x_all(u);

    // Forward: borrow-prefix ladder over bits 0..last.
    circ.cx(u[0], v[0]);
    let first_ctrl = borrow_in.map_or(u[0], |p| {
        circ.cx(u[0], p);
        p
    });
    match (v0cl, borrow_in) {
        (Some(b0), None) => {
            circ.cx(u[0], carries[0]);
            circ.push_condition(b0);
            circ.cx(u[0], carries[0]);
            circ.pop_condition();
        }
        _ => circ.ccx(first_ctrl, v[0], carries[0]),
    }
    if operand_seed {circ.cx(u[0],borrow_in.unwrap());}
    circ.cx(carries[0], u[0]);
    for i in 1..last {
        circ.cx(u[i], v[i]);
        circ.cx(u[i], u[i - 1]);
        circ.ccx(u[i - 1], v[i], carries[i]);
        circ.cx(carries[i], u[i]);
    }

    // The top bit's carry step, as three Clifford CZs.
    circ.cz(u[last], v[last]);
    circ.cz(u[last], u[last - 1]);
    circ.cz(v[last], u[last - 1]);

    // Inverse: every carry measured out and phase-repaired, zero Toffoli.
    for i in (1..last).rev() {
        circ.cx(carries[i], u[i]);
        let m = circ.alloc_bit();
        circ.hmr(carries[i], m);
        circ.cz_if(u[i - 1], v[i], m);
        circ.free_bit(m);
        circ.cx(u[i], u[i - 1]);
        circ.cx(u[i], v[i]);
    }
    circ.cx(carries[0], u[0]);
    let m0 = circ.alloc_bit();
    circ.hmr(carries[0], m0);
    match borrow_in {
        Some(p) => {
            if operand_seed {circ.cx(u[0],p);}
            circ.cz_if(p, v[0], m0);
            circ.cx(u[0], p);
        }
        None => circ.cz_if(u[0], v[0], m0),
    }
    circ.free_bit(m0);
    circ.cx(u[0], v[0]);

    for i in (0..pads).rev() { let m = circ.alloc_bit(); circ.hmr(all[i], m); circ.free_bit(m); }
    circ.free_vec(&all);
    circ.x_all(u);
}

/// Measured-erasure repair, the pattern behind every truncated comparison in
/// the circuit.
///
/// `target` is a carry or overflow wire that is cheaper to measure out than to
/// unwind. `hmr` measures it in a basis that costs a known phase, and the
/// comparison below -- run conditionally on the measurement outcome -- applies
/// the cancelling phase by re-deriving `a < b` from the operands.
///
/// **The slices are the window.** Comparing only the top `k` bits of each
/// operand is the sole approximation: the predicate is wrong exactly when both
/// agree across all `k`, i.e. with probability ~2^-k. Widening by one bit costs
/// one Toffoli and halves that error. Callers slice, as they do for every fold
/// window in the tree, and `borrow_in` lets one account for the bits below by
/// other means instead.
///
/// The caller owns `target` and frees it.
/// [`erase_with_compare`] with `b[0]` known to hold the classical bit `b0cl` (see [`cmp_lt_phase_v0`]).
pub fn erase_with_compare_v0(circ: &mut Builder, target: QubitId, a: &[QubitId], b: &[QubitId], b0cl: crate::circuit::BitId) {
    let bit = circ.alloc_bit();
    circ.hmr(target, bit);
    circ.push_condition(bit);
    cmp_lt_phase_v0(circ, a, b, None, Some(b0cl));
    circ.pop_condition();
    circ.free_bit(bit);
}

#[track_caller]
pub fn erase_with_compare(
    circ: &mut Builder,
    target: QubitId,
    a: &[QubitId],
    b: &[QubitId],
    borrow_in: Option<QubitId>,
) {
    let y16 = super::leapfrog::y16_enter(circ); // y16 trace (no effect on the gates)
    let bit = circ.alloc_bit();
    circ.hmr(target, bit);
    circ.push_condition(bit);
    cmp_lt_phase(circ, a, b, borrow_in);
    circ.pop_condition();
    circ.free_bit(bit);
    super::leapfrog::y16_leave(circ, 1, y16);
    super::leapfrog::y17_log(circ, || format!("cmp{}{}={:.1}", a.len(), if borrow_in.is_some() { "s" } else { "" }, circ.expected_total() - y16.0));
}
