use super::Builder;use crate::circuit::QubitId;use std::sync::Mutex;
static START:Mutex<Option<(usize,f64)>>=Mutex::new(None);
pub fn begin(c:&Builder,r:&[Vec<QubitId>;2]){*START.lock().unwrap()=Some((c.op_count(),c.expected_total()));eprintln!("N2_RETENTION_BEGIN phase={} at={} active={} peak={} dims={:?} rails={:?}",c.current_phase(),c.op_count(),c.active_qubits(),c.peak_total(),c.i13_dims(),r);}
pub fn end(c:&Builder,r:&[Vec<QubitId>;2]){let(at,t)=START.lock().unwrap().take().unwrap();eprintln!("N2_RETENTION_END phase={} begin={at} end={} source_expected_T_delta={} active={} peak={} dims={:?} rails={:?}",c.current_phase(),c.op_count(),c.expected_total()-t,c.active_qubits(),c.peak_total(),c.i13_dims(),r);}
pub fn complete(c:&Builder){eprintln!("N2_RETENTION_RAW_COMPLETE ops={} dims={:?} peak={} source_expected_T={} STATUS=COMPONENT_ONLY_ALL_ORIGINAL_CHECKS_FOLLOW",c.op_count(),c.i13_dims(),c.peak_total(),c.expected_total());}
