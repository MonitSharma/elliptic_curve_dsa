#include "rail8.h"
#include <string.h>
#include <immintrin.h>
typedef __m512i V;typedef __mmask8 M;typedef struct{V l[5];} I;
typedef struct{M sign;V extra;} Choice;
#define A(x,y) _mm512_and_si512(x,y)
#define X(x,y) _mm512_xor_si512(x,y)
#define O(x,y) _mm512_or_si512(x,y)
#define N(x) X(x,_mm512_set1_epi64(-1))
static inline V zero(void){return _mm512_setzero_si512();}
static inline V one(void){return _mm512_set1_epi64(1);}
static inline V cn(uint64_t x){return _mm512_set1_epi64((long long)x);}
static inline I add(I a,I b){I r;M carry=0;for(int i=0;i<5;i++){V s=_mm512_add_epi64(a.l[i],b.l[i]);M c=_mm512_cmp_epu64_mask(s,a.l[i],_MM_CMPINT_LT);V t=_mm512_mask_add_epi64(s,carry,s,one());carry=c|_mm512_cmp_epu64_mask(t,s,_MM_CMPINT_LT);r.l[i]=t;}return r;}
static inline I neg(I a){I b;for(int i=0;i<5;i++)b.l[i]=N(a.l[i]);I c={{one(),zero(),zero(),zero(),zero()}};return add(b,c);}
static inline I select_i(M m,I a,I b){I r;for(int i=0;i<5;i++)r.l[i]=_mm512_mask_blend_epi64(m,a.l[i],b.l[i]);return r;}
static inline I conditional_neg(I a,M m){return select_i(m,a,neg(a));}
static inline M negative(I a){return _mm512_movepi64_mask(a.l[4]);}
static inline M bit(I a,unsigned n){return _mm512_test_epi64_mask(a.l[n/64],cn(UINT64_C(1)<<(n%64)));}
static inline M different(I a,I b){M m=0;for(int i=0;i<5;i++)m|=_mm512_cmpneq_epi64_mask(a.l[i],b.l[i]);return m;}
static inline I arv(I a,V n){I r;V inv=_mm512_sub_epi64(cn(64),n);for(int i=0;i<4;i++)r.l[i]=O(_mm512_srlv_epi64(a.l[i],n),_mm512_sllv_epi64(a.l[i+1],inv));r.l[4]=_mm512_srav_epi64(a.l[4],n);return r;}
static inline I ar(I a,unsigned n){return arv(a,cn(n));}
static inline I sx(I a,unsigned w){M sign=bit(a,w-1);V fill=_mm512_movm_epi64(sign);for(unsigned i=0;i<5;i++){unsigned k=w>64*i?w-64*i:0;uint64_t m=k>=64?UINT64_MAX:((UINT64_C(1)<<k)-1);a.l[i]=O(A(a.l[i],cn(m)),A(fill,cn(~m)));}return a;}
static inline unsigned window_low(unsigned tick,unsigned anchor,unsigned *k){unsigned length=22;if(tick>=1)length=13;if(tick>=6)length=17;if(tick>=11)length=22;if(tick>=90)length=19;if(tick>=100)length=17;if(tick>=112)length=15;if(tick>=118)length=13;if(tick>=124)length=11;*k=length-2;return anchor>*k?anchor-*k:0;}
static inline V window(I a,unsigned width,unsigned low,unsigned k){if(width-1<=low)return zero();M sign=negative(a);V flip=_mm512_movm_epi64(sign);unsigned limb=low/64,off=low%64;V raw=X(a.l[limb],flip);V v=_mm512_srlv_epi64(raw,cn(off));if(limb<4)v=O(v,_mm512_sllv_epi64(X(a.l[limb+1],flip),cn(64-off)));unsigned count=k+2;if(count>width-1-low)count=width-1-low;return A(v,cn((UINT64_C(1)<<count)-1));}
static inline Choice choice(I t,I b,unsigned tw,unsigned bw,unsigned tick,unsigned anchor,int has_before,I before,M forced,int has_old_source,M old_source){
 M dq=bit(t,1)^bit(b,1);M z2=bit(t,2)^bit(b,2)^dq,z3=bit(t,3)^bit(b,3)^dq,z4=bit(t,4)^bit(b,4)^dq;
 M eq=negative(t)^negative(b)^dq,a1=(M)(~z2)&(M)(~z3),a2=a1&(M)(~z4),out=dq^(M)255^a2,v3=0;
 if(tick==0){out^=eq&z2;}else{unsigned k;unsigned low=window_low(tick,anchor,&k);V wt=window(t,tw,low,k),wb=window(b,bw,low,k);M y;
  if(has_before){y=_mm512_cmp_epu64_mask(wt,_mm512_slli_epi64(wb,1),_MM_CMPINT_GT);if(!has_old_source)old_source=negative(b);M not_flipped=(M)~(negative(before)^negative(t)^old_source^negative(b));M added=(M)~(negative(before)^old_source^forced);M veto=eq&(y^not_flipped);out^=veto&z2;v3=veto&(M)~z2&z3&added;out^=v3;}
  else{y=_mm512_cmp_epu64_mask(wt,_mm512_slli_epi64(wb,2),_MM_CMPINT_GT);out^=eq&(M)~y&z2;}
 }
 M k2=(M)~z2^a2^v3,dsel=out^dq,k1=dsel^(M)~z2^a1^v3;Choice c={out,O(_mm512_maskz_set1_epi64(k1,1),_mm512_maskz_set1_epi64(k2,2))};return c;
}
static inline unsigned min(unsigned a,unsigned b){return a<b?a:b;}
static inline unsigned max(unsigned a,unsigned b){return a>b?a:b;}
static inline unsigned bw(unsigned n,int fused,unsigned w,unsigned wn){return fused?min(n,min(w,wn)):n;}
static const RailStep fixed_steps[138]={
{257,258,258,258,257,255},
{257,258,258,258,257,255},
{257,258,258,258,257,255},
{257,258,258,258,257,255},
{257,258,258,258,257,254},
{257,258,258,257,255,253},
{257,257,256,255,254,251},
{255,255,255,254,252,250},
{254,254,253,252,251,248},
{252,252,252,251,249,247},
{251,251,250,249,248,245},
{249,249,249,248,246,243},
{248,248,247,246,245,242},
{246,246,245,244,243,240},
{244,244,243,242,241,238},
{242,242,241,240,239,237},
{240,240,240,239,237,235},
{239,239,238,237,236,233},
{237,237,236,235,234,232},
{235,235,235,234,232,230},
{234,234,233,232,231,228},
{232,232,231,230,229,226},
{230,230,229,228,227,225},
{228,228,228,227,225,223},
{227,227,226,225,224,221},
{225,225,224,223,222,220},
{223,223,222,221,220,218},
{221,221,220,219,218,216},
{219,219,218,217,216,214},
{217,217,216,215,214,212},
{215,215,215,214,212,210},
{214,214,213,212,211,209},
{212,212,211,210,209,207},
{210,210,209,208,207,205},
{208,208,207,206,205,203},
{206,206,205,204,203,201},
{204,204,204,203,201,199},
{203,203,202,201,200,198},
{201,201,200,199,198,196},
{199,199,198,197,196,194},
{197,197,196,195,194,192},
{195,195,194,193,192,190},
{193,193,192,191,190,188},
{191,191,190,189,188,187},
{189,189,188,187,186,185},
{187,187,186,185,184,183},
{185,185,184,183,182,181},
{183,183,183,182,180,179},
{182,182,181,180,179,177},
{180,180,179,178,177,175},
{178,178,177,176,175,173},
{176,176,175,174,173,172},
{174,174,173,172,171,170},
{172,172,171,170,169,168},
{170,170,169,168,167,166},
{168,168,167,166,165,164},
{166,166,165,164,163,162},
{164,164,163,162,161,160},
{162,162,161,160,159,159},
{160,160,159,158,157,157},
{158,158,157,156,155,155},
{156,156,155,154,153,153},
{154,154,153,152,151,151},
{152,152,152,151,149,149},
{151,151,150,149,148,147},
{149,149,148,147,146,145},
{147,147,146,145,144,143},
{145,145,144,143,142,141},
{143,143,142,141,140,140},
{141,141,140,139,138,138},
{139,139,138,137,136,136},
{137,137,136,135,134,134},
{135,135,134,133,132,132},
{133,133,132,131,130,130},
{131,131,130,129,128,128},
{129,129,128,127,126,126},
{127,127,126,125,124,124},
{125,125,124,123,122,122},
{123,123,122,121,120,120},
{121,121,120,119,118,118},
{119,119,118,117,116,117},
{117,117,116,115,114,115},
{115,115,114,113,112,113},
{113,113,112,111,110,111},
{111,111,110,109,108,109},
{109,109,108,107,106,107},
{107,107,107,106,104,105},
{106,106,105,104,103,103},
{104,104,103,102,101,101},
{102,102,101,100,99,99},
{100,100,99,98,97,97},
{98,98,97,96,95,95},
{96,96,95,94,93,93},
{94,94,93,92,91,91},
{92,92,91,90,89,89},
{90,90,89,88,87,87},
{88,88,87,86,85,85},
{86,86,85,84,83,83},
{84,84,83,82,81,81},
{82,82,81,80,79,79},
{80,80,79,78,77,77},
{78,78,77,76,75,75},
{76,76,75,74,73,73},
{74,74,73,72,71,71},
{72,72,71,70,69,69},
{70,70,69,68,67,67},
{68,68,67,66,65,65},
{66,66,65,64,63,63},
{64,64,63,62,61,61},
{62,62,61,60,59,59},
{60,60,60,59,57,57},
{59,59,58,57,56,55},
{57,57,56,55,54,53},
{55,55,54,53,52,51},
{53,53,52,51,50,49},
{51,51,50,49,48,47},
{49,49,48,47,46,45},
{47,47,46,45,44,43},
{45,45,44,43,42,41},
{43,43,42,41,40,39},
{41,41,40,39,38,37},
{39,39,38,37,36,35},
{37,37,36,35,34,33},
{35,35,34,33,32,31},
{33,33,32,31,30,29},
{31,31,30,29,28,27},
{29,29,28,27,26,25},
{27,27,26,25,24,23},
{25,25,24,23,22,21},
{23,23,22,21,20,18},
{21,21,20,19,18,16},
{19,19,18,17,16,14},
{17,17,16,15,14,12},
{15,15,14,13,12,10},
{13,13,12,11,9,8},
{10,10,9,8,7,6},
{8,8,7,6,5,3},
{6,6,6,6,5,3},
};
static void walk_0(I d,M *nonunit,M *overflow){
 const RailStep *s=fixed_steps; const size_t n=138; const int divide=0;

 I ps={{cn(UINT64_C(0xfffffffefffffc2f)),cn(UINT64_MAX),cn(UINT64_MAX),cn(UINT64_MAX),zero()}};
 I minusps=neg(ps);I r[2];r[0]=select_i(bit(d,0),add(d,minusps),d);r[1]=ar(add(r[0],select_i(bit(r[0],1),minusps,ps)),1);M over=0;

 { const size_t tick=0;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=1;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=2;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=3;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=4;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=5;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=6;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=7;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=8;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=9;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=10;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=11;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=12;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=13;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=14;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=15;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=16;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=17;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=18;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=19;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=20;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=21;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=22;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=23;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=24;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=25;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=26;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=27;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=28;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=29;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=30;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=31;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=32;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=33;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=34;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=35;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=36;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=37;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=38;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=39;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=40;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=41;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=42;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=43;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=44;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=45;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=46;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=47;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=48;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=49;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=50;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=51;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=52;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=53;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=54;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=55;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=56;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=57;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=58;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=59;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=60;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=61;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=62;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=63;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=64;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=65;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=66;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=67;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=68;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=69;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=70;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=71;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=72;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=73;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=74;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=75;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=76;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=77;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=78;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=79;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=80;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=81;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=82;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=83;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=84;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=85;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=86;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=87;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=88;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=89;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=90;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=91;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=92;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=93;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=94;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=95;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=96;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=97;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=98;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=99;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=100;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=101;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=102;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=103;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=104;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=105;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=106;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=107;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=108;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=109;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=110;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=111;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=112;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=113;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=114;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=115;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=116;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=117;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=118;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=119;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=120;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=121;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=122;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=123;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=124;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=125;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=126;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=127;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=128;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=129;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=130;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=131;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=132;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=133;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=134;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=135;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=136;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=137;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }
 I one_i={{one(),zero(),zero(),zero(),zero()}},minusone=neg(one_i);M unit0=(M)~different(r[0],one_i)|(M)~different(r[0],minusone),unit1=(M)~different(r[1],one_i)|(M)~different(r[1],minusone);*nonunit=(M)~(unit0&unit1);*overflow=over;
}
static void walk_1(I d,M *nonunit,M *overflow){
 const RailStep *s=fixed_steps; const size_t n=138; const int divide=1;

 I ps={{cn(UINT64_C(0xfffffffefffffc2f)),cn(UINT64_MAX),cn(UINT64_MAX),cn(UINT64_MAX),zero()}};
 I minusps=neg(ps);I r[2];r[0]=select_i(bit(d,0),add(d,minusps),d);r[1]=ar(add(r[0],select_i(bit(r[0],1),minusps,ps)),1);M over=0;

 { const size_t tick=0;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=1;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=2;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=3;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=4;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=5;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=6;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=7;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=8;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=9;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=10;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=11;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=12;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=13;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=14;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=15;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=16;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=17;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=18;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=19;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=20;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=21;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=22;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=23;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=24;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=25;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=26;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=27;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=28;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=29;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=30;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=31;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=32;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=33;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=34;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=35;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=36;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=37;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=38;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=39;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=40;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=41;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=42;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=43;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=44;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=45;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=46;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=47;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=48;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=49;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=50;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=51;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=52;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=53;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=54;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=55;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=56;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=57;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=58;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=59;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=60;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=61;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=62;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=63;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=64;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=65;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=66;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=67;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=68;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=69;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=70;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=71;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=72;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=73;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=74;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=75;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=76;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=77;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=78;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=79;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=80;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=81;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=82;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=83;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=84;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=85;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=86;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=87;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=88;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=89;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=90;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=91;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=92;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=93;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=94;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=95;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=96;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=97;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=98;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=99;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=100;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=101;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=102;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=103;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=104;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=105;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=106;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=107;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=108;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=109;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=110;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=111;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=112;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=113;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=114;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=115;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=116;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=117;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=118;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=119;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=120;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=121;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=122;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=123;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=124;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=125;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=126;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=127;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=128;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=129;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=130;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=131;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=132;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=133;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=134;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=135;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=136;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }

 { const size_t tick=137;

  unsigned ti=tick%2,si=1-ti,w=s[tick].w,n0=s[tick].n0,n1=s[tick].n1,n2=s[tick].n2,nb=s[tick].nb,wn=s[min(tick+1,n-1)].w;
  int fused=divide&&tick>=42&&tick<131;unsigned forced=tick+1<n?2:0;int has_before=0,has_capture=0;I before=r[0];M lastsign=0;Choice captured={0,zero()};unsigned nk[2]={n0,n1},next[2]={n1,n2};
  for(unsigned j=0;j<forced;j++){
   I v=sx(r[ti],nk[j]);over|=different(v,r[ti]);r[ti]=v;v=sx(r[si],bw(nk[j],fused,w,wn));over|=different(v,r[si]);r[si]=v;
   I old=r[ti];M sign=bit(r[ti],1)^bit(r[si],1);v=ar(add(r[ti],conditional_neg(r[si],sign)),1);r[ti]=sx(v,nk[j]-1);over|=different(r[ti],v);
   if(j==1){before=old;has_before=1;lastsign=sign;if(tick!=0){unsigned tw=nk[j]-1,sw=min(bw(nk[j],fused,w,wn),tw);captured=choice(r[ti],sx(r[si],sw),max(tw,6),max(sw,6),tick,s[tick].anchor,1,old,sign,1,negative(r[si]));has_capture=1;}}
   if(fused&&j==0){r[ti]=sx(r[ti],min(nk[j]-1,next[j]));r[si]=sx(r[si],min(bw(nk[j],fused,w,wn),min(w,wn)));}
  }
  r[ti]=sx(r[ti],n2);r[si]=sx(r[si],bw(n2,fused,w,wn));Choice c=has_capture?captured:choice(r[ti],r[si],max(n2,6),max(bw(n2,fused,w,wn),6),tick,s[tick].anchor,has_before,before,lastsign,0,0);
  I v=ar(add(r[ti],conditional_neg(r[si],c.sign)),1);r[ti]=sx(v,n2-1);over|=different(r[ti],v);
  /* Arithmetic shift of a sign-extended nb-bit value is already sign-extended
   * at nb-extra bits, so the reference's final variable-width sx is redundant. */
  r[ti]=arv(sx(r[ti],nb),c.extra);for(unsigned side=0;side<2;side++){v=sx(r[side],wn);over|=different(v,r[side]);r[side]=v;}
  if(fused&&tick<130){RailStep next=s[tick+1];unsigned wnn=s[min(tick+2,n-1)].w;r[ti]=sx(r[ti],min(next.n0,min(next.w,wnn)));}
 
 }
 I one_i={{one(),zero(),zero(),zero(),zero()}},minusone=neg(one_i);M unit0=(M)~different(r[0],one_i)|(M)~different(r[0],minusone),unit1=(M)~different(r[1],one_i)|(M)~different(r[1],minusone);*nonunit=(M)~(unit0&unit1);*overflow=over;
}
int rail8_population(const RailStep *s,size_t n,const uint64_t *pairs,size_t count,uint8_t *flags){
 if(n!=138)return 1;for(size_t i=0;i<n;i++)if(memcmp(&s[i],&fixed_steps[i],sizeof(RailStep)))return 3;for(size_t i=0;i<n;i++){if(s[i].w<1||s[i].w>319||s[i].n0<2||s[i].n0>319||s[i].n1<2||s[i].n1>319||s[i].n2<2||s[i].n2>319||s[i].nb<4||s[i].nb>319||s[i].anchor>319)return 2;}
 V idx=_mm512_set_epi64(56,48,40,32,24,16,8,0);for(size_t at=0;at<count;at+=8){I d1,d2;uint64_t padded[64]={0};const uint64_t *ptr=pairs+at*8;if(count-at<8){for(size_t j=0;j<count-at;j++)for(int k=0;k<8;k++)padded[8*j+k]=ptr[8*j+k];ptr=padded;}
  for(int k=0;k<4;k++){d1.l[k]=_mm512_i64gather_epi64(idx,ptr+k,8);d2.l[k]=_mm512_i64gather_epi64(idx,ptr+4+k,8);}d1.l[4]=d2.l[4]=zero();M a,b,c,d;walk_1(d1,&a,&b);walk_0(d2,&c,&d);M nonunit=a|c,overflow=b|d;for(size_t j=0;j<8&&at+j<count;j++)flags[at+j]=((nonunit>>j)&1)|(((overflow>>j)&1)<<1);
 }return 0;
}
