# Disabled runtime port for the frozen copy-cache source

Only candidate stream hash/opcount and exact proof bindings change from the
qualified source12 runtime. Universal full final-q/c/phase/physical-RNG equality
composes with its old value-mask transfer, including arbitrary boundary values.
Temporary storage differences inside the held interval are permitted only
because the complete final-state proof closes every wire and RNG continuation.
Own-seed/full9024/zero-MR/partial/4096-prefix controls remain mandatory after
this source's sole final census PASS. Build is allowed first; nonce evaluation,
authoritative rejection and production are disabled. Never relabel a gate or
retry a statistical failure. The build leader stays root; compiler in subshell.
