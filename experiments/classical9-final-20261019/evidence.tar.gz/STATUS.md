# Classical9 queue-only finalization recipe — not launched

Prepare from the corrected parent4 finalizer, binding the actual classical9
source/archive/stream/opcount paths. Native source inputs can be checked early;
that audit must never be called complete gate/runtime readiness. The terminal
auditor remains explicitly unbound until new-source operational acceptance and
its own1..4096 prefix control pass. Run all six corruption controls again.

Before launching a watcher, bind its actual acceptance and binary hashes and
run the complete path/source/archive/gate/census/runtime audit. Only a terminal
search with full lower-prefix JSONL audit may select its lowest full pass.
Then reproduce native source and its unchanged pre-tail stream, verify48 XX
nonce pairs, check tail invariance on the existing declared inputs, and run the
unchanged official benchmark. All11 native primitive controls remain required.

Build uses1 core; tail controls use2 threads. Historical results are preserved
even if a benchmark/verifier fails, with failed generated rows retained in
separate evidence. Refresh the public record before claiming improvement.
Queue mode, no uploader, no later nonce for a different score. No search or
benchmark has been launched by this recipe.
