# Read-only top-wire leasing footprint

Declared before launch,20 October2026. Parent frozen copy-cache raw d343ca71�,
17,889,637 operations, current own census untouched. Fixed target highest
qubit1233. Find all scope-expanded epochs closed by unconditional depth0 reset,
quantum/phase/ABI touches and static untouched non-ABI donor candidates.
Conditional cleanups are unknown at this first lexical screen. Never infer a
donor is zero or has a recomputable value from inactivity. No operations are
emitted or changed. Four boundary/coverage controls before full input scan.
This diagnostic only decides what exact clean/provenance analysis is needed
next; it cannot establish a width improvement or rule out richer leasing.
One server CPU/12GiB, source/compiler/direct dependencies/input hashes bound.
