#!/bin/bash
set -u
cd /home/hclau/ecdsa_research/simd-prefilter-20261015
export PATH="$HOME/.cargo/bin:$PATH" CARGO_BUILD_JOBS=4 RAYON_NUM_THREADS=1
date -Is > preflight-prepared.log
uptime >> preflight-prepared.log
free -h >> preflight-prepared.log
ps -eo pid,comm,nlwp,pcpu,rss,args --sort=-pcpu | head -20 >> preflight-prepared.log
cd tool
cargo build --release > ../build-prepared.log 2>&1
code=$?
echo "$code" > ../build-prepared.exit
if [ "$code" -eq 0 ]; then
 /usr/bin/time -v target/release/product_paired_diagnostic @fiat /home/hclau/ecdsa_research/product-exact-20261015/tip/ops.bin > ../prepared-verify.log 2>&1
 echo "$?" > ../prepared-verify.exit
fi
