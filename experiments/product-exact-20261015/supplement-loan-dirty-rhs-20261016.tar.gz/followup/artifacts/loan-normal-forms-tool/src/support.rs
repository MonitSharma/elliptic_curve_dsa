//! I25: exact CCX support identities with immutable nonlinear interning. An atom denotes a Boolean
//! function at its creation boundary, never a mutable wire or classical bit.
//! Unknown products and oversized expressions get fresh, non-reused atoms.

use crate::circuit::{analyze_ops, Op, OperationType, QubitId, QubitOrBit, NO_BIT};

const ATOM_CAP: usize = 512;
const PRODUCT_CAP: usize = 200_000;

#[derive(Clone, PartialEq, Eq, Hash)]
struct Affine {
    constant: bool,
    atoms: Vec<u64>,
}

impl Affine {
    fn constant(value: bool) -> Self {
        Self {
            constant: value,
            atoms: Vec::new(),
        }
    }

    fn is_zero(&self) -> bool {
        !self.constant && self.atoms.is_empty()
    }

    fn is_one(&self) -> bool {
        self.constant && self.atoms.is_empty()
    }

    fn complement(&self) -> Self {
        Self {
            constant: !self.constant,
            atoms: self.atoms.clone(),
        }
    }

    fn complements(&self, other: &Self) -> bool {
        self.constant != other.constant && self.atoms == other.atoms
    }
}

pub(super) enum Rewrite {
    Keep,
    Drop,
    X,
    Cx(QubitId),
}

impl Rewrite {
    pub(super) fn emit(self, op: Op, result: &mut Vec<Op>) {
        match self {
            Rewrite::Keep => result.push(op),
            Rewrite::Drop => {}
            rewrite => {
                let mut replacement = Op::empty();
                replacement.q_target = op.q_target;
                replacement.c_condition = op.c_condition;
                match rewrite {
                    Rewrite::X => replacement.kind = OperationType::X,
                    Rewrite::Cx(control) => {
                        replacement.kind = OperationType::CX;
                        replacement.q_control1 = control;
                    }
                    _ => unreachable!(),
                }
                replacement.validate();
                result.push(replacement);
            }
        }
    }
}

pub(super) struct Support {
    qubits: Vec<Affine>,
    bits: Vec<Affine>,
    base_condition: Affine,
    condition_stack: Vec<Affine>,
    next_atom: u64,
    products: std::collections::HashMap<(Vec<u64>,Vec<u64>),u64>,
}

impl Support {
    pub(super) fn new(ops: &[Op]) -> Self {
        let (nq, nb, _, registers) = analyze_ops(ops.iter());
        let mut quantum_inputs = vec![false; nq as usize];
        let mut classical_inputs = vec![false; nb as usize];
        for register in registers {
            for slot in register {
                match slot {
                    QubitOrBit::Qubit(q) => quantum_inputs[q.0 as usize] = true,
                    QubitOrBit::Bit(b) => classical_inputs[b.0 as usize] = true,
                }
            }
        }
        let mut state = Self {
            qubits: vec![Affine::constant(false); nq as usize],
            bits: vec![Affine::constant(false); nb as usize],
            base_condition: Affine::constant(true),
            condition_stack: Vec::new(),
            next_atom: 0,
            products: std::collections::HashMap::new(),
        };
        // Both kinds of ABI slot are unknown. Repeated annotations for one
        // physical slot still describe the same value.
        for (q, input) in quantum_inputs.into_iter().enumerate() {
            if input {
                state.qubits[q] = state.fresh();
            }
        }
        for (b, input) in classical_inputs.into_iter().enumerate() {
            if input {
                state.bits[b] = state.fresh();
            }
        }
        state
    }

    fn fresh(&mut self) -> Affine {
        let id = self.next_atom;
        self.next_atom = id.checked_add(1).expect("affine atom identifier overflow");
        Affine {
            constant: false,
            atoms: vec![id],
        }
    }

    fn xor(&mut self, a: &Affine, b: &Affine) -> Affine {
        let mut atoms = Vec::with_capacity(a.atoms.len() + b.atoms.len());
        let (mut i, mut j) = (0, 0);
        while i < a.atoms.len() || j < b.atoms.len() {
            if j == b.atoms.len() || (i < a.atoms.len() && a.atoms[i] < b.atoms[j]) {
                atoms.push(a.atoms[i]);
                i += 1;
            } else if i == a.atoms.len() || b.atoms[j] < a.atoms[i] {
                atoms.push(b.atoms[j]);
                j += 1;
            } else {
                i += 1;
                j += 1;
            }
        }
        if atoms.len() > ATOM_CAP {
            // This fresh atom represents the entire XOR, including its
            // constant. It must not be mistaken for zero or an older atom.
            self.fresh()
        } else {
            Affine {
                constant: a.constant ^ b.constant,
                atoms,
            }
        }
    }

    fn and(&mut self, a: &Affine, b: &Affine) -> Affine {
        if a.is_zero() || b.is_zero() || a.complements(b) {
            Affine::constant(false)
        } else if a.is_one() {
            b.clone()
        } else if b.is_one() || a == b {
            a.clone()
        } else {
            // Keys denote complete immutable Boolean expressions, never wire
            // slots. HashMap checks exact key equality, not just a hash value.
            // (A^ca)(B^cb) = AB ^ ca*B ^ cb*A ^ ca*cb.
            let ca=a.constant; let cb=b.constant;
            let aa=Affine {constant:false, atoms:a.atoms.clone()};
            let bb=Affine {constant:false, atoms:b.atoms.clone()};
            let mut linear=Affine::constant(ca && cb);
            if ca {linear=self.xor(&linear,&bb);}
            if cb {linear=self.xor(&linear,&aa);}
            let mut left=aa.atoms;let mut right=bb.atoms;
            if left>right {std::mem::swap(&mut left,&mut right);}
            let key=(left,right);
            let id=if let Some(&id)=self.products.get(&key){id}else{
                // Forgetting cache entries only loses proofs. No atom ID is
                // recycled, and all live expressions keep their old meaning.
                if self.products.len()>=PRODUCT_CAP {self.products.clear();}
                let id=self.fresh().atoms[0];self.products.insert(key,id);id
            };
            self.xor(&linear,&Affine{constant:false,atoms:vec![id]})
        }
    }

    fn ccx_rewrite(condition: &Affine, a: &Affine, b: &Affine, op: &Op) -> Rewrite {
        if condition.is_zero() || a.is_zero() || b.is_zero() || a.complements(b) {
            Rewrite::Drop
        } else if a.is_one() && b.is_one() {
            Rewrite::X
        } else if a.is_one() {
            Rewrite::Cx(op.q_control2)
        } else if b.is_one() || a == b {
            Rewrite::Cx(op.q_control1)
        } else {
            Rewrite::Keep
        }
    }

    pub(super) fn step(&mut self, op: &Op) -> Rewrite {
        if op.kind == OperationType::PushCondition {
            self.condition_stack.push(self.base_condition.clone());
            // Snapshot the current value, not a reference to the bit slot.
            self.base_condition = self.and(
                &self.base_condition.clone(),
                &self.bits[op.c_condition.0 as usize].clone(),
            );
            return Rewrite::Keep;
        }
        if op.kind == OperationType::PopCondition {
            if let Some(saved) = self.condition_stack.pop() {
                self.base_condition = saved;
            }
            return Rewrite::Keep;
        }

        let mut condition = self.base_condition.clone();
        if op.c_condition != NO_BIT {
            condition = self.and(&condition, &self.bits[op.c_condition.0 as usize].clone());
        }

        match op.kind {
            OperationType::CCX => {
                let a = self.qubits[op.q_control1.0 as usize].clone();
                let b = self.qubits[op.q_control2.0 as usize].clone();
                let rewrite = Self::ccx_rewrite(&condition, &a, &b, op);
                let product = self.and(&a, &b);
                let toggle = self.and(&condition, &product);
                let target = op.q_target.0 as usize;
                self.qubits[target] = self.xor(&self.qubits[target].clone(), &toggle);
                return rewrite;
            }
            OperationType::CX => {
                let target = op.q_target.0 as usize;
                let toggle = self.and(&condition, &self.qubits[op.q_control1.0 as usize].clone());
                self.qubits[target] = self.xor(&self.qubits[target].clone(), &toggle);
            }
            OperationType::X => {
                let target = op.q_target.0 as usize;
                self.qubits[target] = self.xor(&self.qubits[target].clone(), &condition);
            }
            OperationType::Swap => {
                let a = op.q_control1.0 as usize;
                let b = op.q_target.0 as usize;
                let difference = self.xor(&self.qubits[a].clone(), &self.qubits[b].clone());
                let toggle = self.and(&condition, &difference);
                // Both destinations share this same actual conditional delta.
                let left = self.xor(&self.qubits[a].clone(), &toggle);
                let right = self.xor(&self.qubits[b].clone(), &toggle);
                self.qubits[a] = left;
                self.qubits[b] = right;
            }
            OperationType::Hmr => {
                let target = op.q_target.0 as usize;
                let bit = op.c_target.0 as usize;
                let outcome = self.fresh();
                let difference = self.xor(&self.bits[bit].clone(), &outcome);
                let toggle = self.and(&condition, &difference);
                self.bits[bit] = self.xor(&self.bits[bit].clone(), &toggle);
                self.qubits[target] =
                    self.and(&self.qubits[target].clone(), &condition.complement());
            }
            OperationType::R => {
                let target = op.q_target.0 as usize;
                self.qubits[target] =
                    self.and(&self.qubits[target].clone(), &condition.complement());
            }
            OperationType::BitInvert => {
                let bit = op.c_target.0 as usize;
                self.bits[bit] = self.xor(&self.bits[bit].clone(), &condition);
            }
            OperationType::BitStore0 => {
                let bit = op.c_target.0 as usize;
                self.bits[bit] = self.and(&self.bits[bit].clone(), &condition.complement());
            }
            OperationType::BitStore1 => {
                let bit = op.c_target.0 as usize;
                self.bits[bit] = self
                    .and(&self.bits[bit].complement(), &condition.complement())
                    .complement();
            }
            // Phase gates do not alter basis support. Preserve them, resets,
            // classical operations and annotations verbatim in the output.
            OperationType::Z
            | OperationType::CZ
            | OperationType::CCZ
            | OperationType::Neg
            | OperationType::Register
            | OperationType::AppendToRegister
            | OperationType::DebugPrint => {}
            OperationType::PushCondition | OperationType::PopCondition => unreachable!(),
        }
        Rewrite::Keep
    }
}

/// Derive one pass of exact CCX support identities from this stream's ABI and
/// operations. No saved operation indices, nonce assumptions or legacy passes.
pub(crate) fn simplify(ops: Vec<Op>) -> Vec<Op> {
    let mut state = Support::new(&ops);
    let mut result = Vec::with_capacity(ops.len());
    for op in ops {
        state.step(&op).emit(op, &mut result);
    }
    result
}


/// Exact CCX-to-CX witnesses. No new measurement, reset, or phase gate.
pub(crate) fn witnesses(ops:Vec<Op>)->Vec<Op>{
    use std::collections::{HashMap,BTreeSet};
    let mut state=Support::new(&ops);
    let mut index:HashMap<Affine,BTreeSet<usize>>=HashMap::new();
    for (q,v) in state.qubits.iter().enumerate(){index.entry(v.clone()).or_default().insert(q);}
    let(mut self_n,mut witness_n,mut self_t,mut witness_t,mut depth)=(0,0,0.0,0.0,0i32);
    let mut examples=Vec::new();
    let mut out=Vec::with_capacity(ops.len());
    for (at,op) in ops.iter().enumerate(){
        let mut replacement=None;
        if op.kind==OperationType::PushCondition{depth+=1;}
        if op.kind==OperationType::PopCondition{depth-=1;}
        if op.kind==OperationType::CCX{
            let a=state.qubits[op.q_control1.0 as usize].clone();
            let b=state.qubits[op.q_control2.0 as usize].clone();
            let product=state.and(&a,&b);
            let target=op.q_target.0 as usize;
            if !product.is_zero() && !product.is_one(){
                let weight=2f64.powi(-depth-i32::from(op.c_condition!=NO_BIT));
                let self_hit=state.qubits[target]==product;
                let witness=index.get(&product).and_then(|s|s.iter().copied().find(|&q|q!=target));
                if self_hit{self_n+=1;self_t+=weight;}
                if witness.is_some(){witness_n+=1;witness_t+=weight;replacement=witness;}
                if examples.len()<64 && (self_hit||witness.is_some()){
                    examples.push(format!("{{\"op\":{at},\"target\":{target},\"self_uncompute\":{self_hit},\"witness\":{}}}",witness.map_or("null".to_string(),|q|q.to_string())));
                }
            }
        }
        let changed:Vec<usize>=match op.kind{
            OperationType::CCX|OperationType::CX|OperationType::X|OperationType::R|OperationType::Hmr=>vec![op.q_target.0 as usize],
            OperationType::Swap=>vec![op.q_control1.0 as usize,op.q_target.0 as usize],_=>vec![]};
        for &q in &changed{let key=state.qubits[q].clone();let set=index.get_mut(&key).unwrap();assert!(set.remove(&q));if set.is_empty(){index.remove(&key);}}
        state.step(op);
        for &q in &changed{index.entry(state.qubits[q].clone()).or_default().insert(q);}
        if let Some(q)=replacement{
            assert_ne!(q,op.q_target.0 as usize);
            let mut r=Op::empty();r.kind=OperationType::CX;r.q_control1=QubitId(q as u64);r.q_target=op.q_target;r.c_condition=op.c_condition;
            r.validate();out.push(r);
        }else{out.push(*op);}
    }
    println!("I25_WITNESSES {{\"self_uncompute_native\":{self_n},\"self_uncompute_expected_T\":{self_t},\"witness_native\":{witness_n},\"witness_expected_T\":{witness_t},\"examples\":[{}]}}",examples.join(","));
    out
}

impl Support {
    // Exact XOR identities in an over-approximation of reachable values.
    // Every atom is immutable; forgetting correlations only loses identities.
    pub(crate) fn loan_relation(&self, top:usize, nt:&[usize], nw:&[usize], end:usize)->Option<(usize,Vec<usize>,bool)> {
        use std::collections::{BTreeSet,HashMap};
        if !self.qubits[top].is_zero() { return None; }
        let mut basis:HashMap<u64,(BTreeSet<u64>,BTreeSet<usize>,bool)>=HashMap::new();
        let mut order:Vec<usize>=(0..top).filter(|q|nw[*q]>end).collect();
        // Keep wires read during the interval as basis; prefer unused wires as loans.
        order.sort_by_key(|q|(nt[*q]>end,self.qubits[*q].atoms.len()));
        for q in order {
            let mut atoms:BTreeSet<u64>=self.qubits[q].atoms.iter().copied().collect();
            let mut wires=BTreeSet::from([q]);let mut constant=self.qubits[q].constant;
            while let Some(&pivot)=atoms.last(){
                if let Some((a,w,c))=basis.get(&pivot) {
                    atoms=atoms.symmetric_difference(a).copied().collect();
                    wires=wires.symmetric_difference(w).copied().collect();constant^=c;
                }else{basis.insert(pivot,(atoms.clone(),wires.clone(),constant));break;}
            }
            if atoms.is_empty()&&nt[q]>end {
                assert!(wires.remove(&q));
                return Some((q,wires.into_iter().collect(),constant));
            }
        }
        None
    }
}

impl Support {
    // Exact XOR identities in an over-approximation of reachable values.
    // Every atom is immutable; forgetting correlations only loses identities.
    pub(crate) fn product_loan_relation(&mut self, top:usize, nt:&[usize], nw:&[usize], end:usize,a:usize,b:usize)->Option<(usize,Vec<usize>,bool)> {
        use std::collections::{BTreeSet,HashMap};
        if !self.qubits[top].is_zero() || nw[a]<=end || nw[b]<=end {return None;}
        let wanted=self.and(&self.qubits[a].clone(),&self.qubits[b].clone());
        let mut basis:HashMap<u64,(BTreeSet<u64>,BTreeSet<usize>,bool)>=HashMap::new();
        if let Some(&pivot)=wanted.atoms.last(){basis.insert(pivot,(wanted.atoms.iter().copied().collect(),BTreeSet::from([top]),wanted.constant));}
        let mut order:Vec<usize>=(0..top).filter(|q|nw[*q]>end).collect();
        // Keep wires read during the interval as basis; prefer unused wires as loans.
        order.sort_by_key(|q|(nt[*q]>end,self.qubits[*q].atoms.len()));
        for q in order {
            let mut atoms:BTreeSet<u64>=self.qubits[q].atoms.iter().copied().collect();
            let mut wires=BTreeSet::from([q]);let mut constant=self.qubits[q].constant;
            while let Some(&pivot)=atoms.last(){
                if let Some((a,w,c))=basis.get(&pivot) {
                    atoms=atoms.symmetric_difference(a).copied().collect();
                    wires=wires.symmetric_difference(w).copied().collect();constant^=c;
                }else{basis.insert(pivot,(atoms.clone(),wires.clone(),constant));break;}
            }
            if atoms.is_empty()&&nt[q]>end {
                assert!(wires.remove(&q));
                return Some((q,wires.into_iter().collect(),constant));
            }
        }
        None
    }
}

// Read-only exact dirty-RHS algebra. Source replay is never rewritten.
use std::collections::{BTreeMap,BTreeSet,HashMap,HashSet};
fn sx(a:&[u64],b:&[u64])->Vec<u64>{let(mut i,mut j)=(0,0);let mut out=Vec::new();while i<a.len()||j<b.len(){if j==b.len()||(i<a.len()&&a[i]<b[j]){out.push(a[i]);i+=1;}else if i==a.len()||b[j]<a[i]{out.push(b[j]);j+=1;}else{i+=1;j+=1;}}out}
#[derive(Clone)]struct Basis{rows:HashMap<u64,(Vec<u64>,bool,Vec<u64>)>}
impl Basis{
 fn new()->Self{Self{rows:HashMap::new()}}
 fn reduce(&self,v:&Affine)->(Vec<u64>,bool,Vec<u64>){let mut a=v.atoms.clone();let mut c=v.constant;let mut rhs=vec![];while let Some(&pivot)=a.last(){if let Some((r,k,labels))=self.rows.get(&pivot){a=sx(&a,r);c^=*k;rhs=sx(&rhs,labels);}else{break;}}(a,c,rhs)}
 fn insert(&mut self,v:&Affine,label:u64){let(a,c,rhs)=self.reduce(v);if let Some(&pivot)=a.last(){self.rows.insert(pivot,(a,c,sx(&rhs,&[label])));}}
 fn expression(&self,v:&Affine,nq:usize,nb:usize,pairs:&[(usize,usize,u64)])->Option<serde_json::Value>{let(a,c,rhs)=self.reduce(v);if !a.is_empty(){return None;}let mut q=vec![];let mut b=vec![];let mut p=vec![];for id in rhs{let id=id as usize;if id<nq{q.push(id);}else if id<nq+nb{b.push(id-nq);}else{let z=pairs[id-nq-nb];p.push([z.0,z.1]);}}Some(serde_json::json!({"constant":c,"quantum_xor":q,"classical_xor_snapshot_needed":b,"quantum_products":p,"products_count":p.len(),"roundtrip_added_CCX_if_valid":2*p.len()}))}
}
impl Support{
 pub(super) fn dirty_rhs_queries(&self,eligible:&[usize],targets:&[usize])->serde_json::Value{
  let(nq,nb)=(self.qubits.len(),self.bits.len());let mut byatoms:HashMap<Vec<u64>,Vec<usize>>=HashMap::new();let mut qbasis=Basis::new();
  for &q in eligible{byatoms.entry(self.qubits[q].atoms.clone()).or_default().push(q);qbasis.insert(&self.qubits[q],q as u64);}
  let mut cbasis=qbasis.clone();for(b,v)in self.bits.iter().enumerate(){cbasis.insert(v,(nq+b)as u64);}
  let wanted:HashSet<_>=targets.iter().flat_map(|q|self.qubits[*q].atoms.iter().copied()).collect();
  let mut inverse_relevant=0usize;let mut factor_pair_options=0usize;let mut candidates=BTreeSet::new();
  // Inspect existing exact products only. Never enumerate quantum pairs.
  for((left,right),&id)in &self.products{if !wanted.contains(&id){continue;}inverse_relevant+=1;if let(Some(aa),Some(bb))=(byatoms.get(left),byatoms.get(right)){factor_pair_options+=aa.len()*bb.len();for &a in aa.iter().take(8){for &b in bb.iter().take(8){if a!=b{candidates.insert((a.min(b),a.max(b),id));}}}}}
  let truncated=candidates.len()>4096;let pairs:Vec<_>=candidates.into_iter().take(4096).collect();let mut augmented=cbasis.clone();
  for(i,&(a,b,id))in pairs.iter().enumerate(){let va=&self.qubits[a];let vb=&self.qubits[b];let mut atoms=vec![id];if va.constant{atoms=sx(&atoms,&vb.atoms);}if vb.constant{atoms=sx(&atoms,&va.atoms);}let v=Affine{constant:va.constant&&vb.constant,atoms};augmented.insert(&v,(nq+nb+i)as u64);}
  let mut rows=vec![];
  for &target in targets{let v=&self.qubits[target];let singles=byatoms.get(&v.atoms).map(|qs|qs.iter().take(16).map(|q|serde_json::json!({"q":q,"invert":v.constant^self.qubits[*q].constant})).collect::<Vec<_>>()).unwrap_or_default();
   let mut xor_two=vec![];let mut pair_count=0usize;for &a in eligible{let remainder=sx(&v.atoms,&self.qubits[a].atoms);if let Some(bs)=byatoms.get(&remainder){for &b in bs{if a<b{pair_count+=1;if xor_two.len()<16{xor_two.push(serde_json::json!({"q":[a,b],"invert":v.constant^self.qubits[a].constant^self.qubits[b].constant}));}}}}}
   rows.push(serde_json::json!({"target":target,"atom_count":v.atoms.len(),"constant":v.constant,"direct_q_or_complement":singles,"direct_xor_two_q_count":pair_count,"direct_xor_two_q_first16":xor_two,"stable_q_affine":qbasis.expression(v,nq,nb,&[]),"stable_q_plus_current_c_affine":cbasis.expression(v,nq,nb,&[]),"existing_relevant_products_plus_affine":augmented.expression(v,nq,nb,&pairs)}));
  }
  serde_json::json!({"eligible_full_window_untouched_q":eligible.len(),"quantum_basis_rank":qbasis.rows.len(),"quantum_plus_classical_basis_rank":cbasis.rows.len(),"current_classical_slots":nb,"immutable_next_atom":self.next_atom,"retained_product_nodes":self.products.len(),"target_atom_ids_with_existing_inverse_product":inverse_relevant,"physical_factor_pair_options_before_bounds":factor_pair_options,"candidate_pair_variants_per_factor_form_max":8,"candidate_pairs":pairs.len(),"candidate_limit":4096,"candidate_limit_truncated":truncated,"pair_method":"existing product-node inverse index only; no Cartesian quantum-pair search","query_rows":rows,"scope":"Exact equalities in conservative immutable source support; absence is bounded proof failure, not impossibility. Classical terms require stable snapshots; return-zero and whole repair phase/value obligations remain. No rewrites or sampled inputs."})
 }
}
#[cfg(test)]mod dirty_rhs_tests{
 use super::*;
 #[test]fn gaussian_dirty_rhs_and_product_labels(){let mut b=Basis::new();b.insert(&Affine{constant:false,atoms:vec![1,2]},2);b.insert(&Affine{constant:true,atoms:vec![2]},3);let x=b.expression(&Affine{constant:false,atoms:vec![1]},10,10,&[]).unwrap();assert_eq!(x["quantum_xor"],serde_json::json!([2,3]));assert_eq!(x["constant"],true);assert!(b.expression(&Affine{constant:false,atoms:vec![99]},10,10,&[]).is_none());}
 #[test]fn exact_xor_sorted_parity(){assert_eq!(sx(&[1,3,5],&[2,3,4]),vec![1,2,4,5]);}
}
