pub use quantum_ecc::circuit;
use circuit::{Op,OperationType as K,QubitId,BitId,RegisterId};
use std::{io::Read,collections::BTreeSet};
mod support;
fn load(path:&str)->Vec<Op>{
 let mut f=std::fs::File::open(path).unwrap();let mut h=[0u8;16];f.read_exact(&mut h).unwrap();assert_eq!(&h[..8],b"QECCOPSZ");let n=u64::from_le_bytes(h[8..].try_into().unwrap())as usize;
 let mut d=zstd::stream::read::Decoder::new(f).unwrap();let mut ops=Vec::with_capacity(n);let mut rec=[0u8;56];
 for _ in 0..n{d.read_exact(&mut rec).unwrap();let f:Vec<u64>=rec.chunks_exact(8).map(|x|u64::from_le_bytes(x.try_into().unwrap())).collect();
  let kind=match f[0]{0=>K::Neg,1=>K::Register,2=>K::AppendToRegister,3=>K::BitInvert,4=>K::BitStore0,5=>K::BitStore1,6=>K::X,7=>K::Z,8=>K::CX,9=>K::CZ,10=>K::Swap,11=>K::R,12=>K::Hmr,13=>K::CCX,14=>K::CCZ,15=>K::PushCondition,16=>K::PopCondition,17=>K::DebugPrint,_=>panic!()};
  let o=Op{kind,q_control2:QubitId(f[1]),q_control1:QubitId(f[2]),q_target:QubitId(f[3]),c_target:BitId(f[4]),c_condition:BitId(f[5]),r_target:RegisterId(f[6])};o.validate();ops.push(o);
 }let mut end=[0u8;1];assert_eq!(d.read(&mut end).unwrap(),0);ops
}
fn main(){
 let args:Vec<_>=std::env::args().collect();assert_eq!(args.len(),3);let ops=load(&args[1]);let family:serde_json::Value=serde_json::from_slice(&std::fs::read(&args[2]).unwrap()).unwrap();let mut queries=std::collections::BTreeMap::new();
 for f in family["families"].as_array().unwrap(){let start=f["out_span"][0].as_u64().unwrap()as usize;let after=f["out_span"][1].as_u64().unwrap()as usize;let end=f["returned_span"][1].as_u64().unwrap()as usize;let mut touched=BTreeSet::new();for o in &ops[start..end]{for q in[o.q_control1,o.q_control2,o.q_target]{if q.0!=u64::MAX{touched.insert(q.0 as usize);}}}let eligible:Vec<_>=(0..1234).filter(|q|!touched.contains(q)).collect();assert_eq!(eligible.len(),650);let targets:Vec<_>=f["source_rails_bit1through5"].as_array().unwrap().iter().flat_map(|rail|rail.as_array().unwrap()[..4].iter().map(|x|x.as_u64().unwrap()as usize)).collect();assert_eq!(targets.len(),8);queries.insert(after,(f["phase"].as_str().unwrap().to_string(),end,eligible,targets));}
 let mut state=support::Support::new(&ops);let started=std::time::Instant::now();for(at,op)in ops.iter().enumerate(){if let Some((phase,end,eligible,targets))=queries.remove(&at){let result=state.dirty_rhs_queries(&eligible,&targets);println!("{}",serde_json::json!({"phase":phase,"at_after_out":at,"full_window_end":end,"seconds":started.elapsed().as_secs_f64(),"result":result,"sampled_inputs":0,"rewrites_applied":false}));if queries.is_empty(){break;}}let _=state.step(op);}assert!(queries.is_empty());
}
