"""Restore every inherited deletion; retain all original anchor checks."""
import hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
tree=root/'candidate-product-restore-deletions'
assert not tree.exists()
base='4b2ec52fc55da796aa8f5ef851290297e8706424'
subprocess.run(['git','-C',str(root.parent/'toffoli'),'worktree','add','--detach',str(tree),base],check=True)
relative='src/point_add/census_anchored.rs'
path=tree/relative
text=path.read_text()
old='    super::census_cut::run_rows(ops,mapped)'
assert text.count(old)==1
new='''    // Restore the entire inherited deletion family, selected before any
    // measurement. Every original source neighbourhood was verified above.
    // The depth-weighted figures below are static proxies, not scored means.
    let families:HashMap<usize,bool>=mapped.iter().map(|(i,f)| {
        assert_ne!(f[0], "B", "family restoration expects single-gate rows");
        (*i,f[6]=="del")
    }).collect();
    let (mut depth,mut deleted,mut reduced)=(0i32,0.0f64,0.0f64);
    for (i,o) in ops.iter().enumerate() {
        match o.kind {
            crate::circuit::OperationType::PushCondition => depth+=1,
            crate::circuit::OperationType::PopCondition => depth-=1,
            _ => {}
        }
        if let Some(is_del)=families.get(&i) {
            let weight=0.5f64.powi(depth+(o.c_condition!=crate::circuit::NO_BIT) as i32);
            if *is_del {deleted+=weight;} else {reduced+=weight;}
        }
    }
    let old_len=mapped.len();
    mapped.retain(|(_,f)|f[6]!="del");
    eprintln!("RESTORE_CATEGORY family=all_deletions restored_rows={} retained_rows={} deletion_static_proxy={} reduction_static_proxy={}",old_len-mapped.len(),mapped.len(),deleted,reduced);
    super::census_cut::run_rows(ops,mapped)'''
path.write_text(text.replace(old,new))
patch=subprocess.check_output(['git','-C',str(tree),'diff','--',relative])
(root/'candidate-product-restore-deletions.patch').write_bytes(patch)
plan={'base_revision':base,'candidate':tree.name,'selection':'Restore ALL inherited census_cut deletion rows, after every original content anchor validates; preserve every reduction row and every upstream table/cut. No packet-based row selection.','patch_sha256':hashlib.sha256(patch).hexdigest(),'phase':'construction and cost feasibility only; no census or nonce search scheduled','nonce_search_performed':False,'score':None}
(root/'CATEGORY_RESTORE_DECLARATION.json').write_text(json.dumps(plan,indent=2)+'\n')
print(patch.decode())
