import hashlib,json,os,re,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent;ws=r.parent;t=r/'observer';sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();env=dict(os.environ,PEBBLE_HARD_CAP='1234')
def run(cmd,name,cwd=t,extra=None):
 with(r/(name+'.log')).open('xb')as out:p=subprocess.Popen(cmd,cwd=cwd,env=dict(env,**(extra or{})),stdout=out,stderr=subprocess.STDOUT);(r/(name+'.pid')).write_text(str(p.pid)+'\n');rc=p.wait()
 (r/(name+'.exit')).write_text(str(rc)+'\n');return rc
try:
 assert run(['python3','prepare.py'],'prepare',r)==0;f=json.loads((r/'SOURCE-FREEZE.json').read_text());filters=['exact_strip_port_tests','prime_clean_pool_tests','wide_loan_policy_tests','reverse_budget_tests','fin1_fold_tests','t0_shared_product_tests','core_loan_fold_tests','phase_cubic_cap_tests','phase_pebble','phase_fit','phase_fusion','zero_carry','plan7_tests','terminal_contract_tests','terminal_birth_phase_tests','direct_transport_tests'];expected=[1,2,1,1,1,1,1,1,3,1,4,3,2,3,1,1]
 for i,(flt,n)in enumerate(zip(filters,expected)):
  name='tests-'+str(i);assert run(['/home/hclau/.cargo/bin/cargo','+1.93.0','test','--release','--bin','build_circuit',flt,'--','--nocapture','--test-threads=1'],name)==0;assert re.findall(r'test result: ok\. (\d+) passed; 0 failed;',(r/(name+'.log')).read_text())==[str(n)]
 assert run(['/home/hclau/.cargo/bin/cargo','+1.93.0','test','--release','--bin','build_circuit','grouped_plan_shape_tests','--','--nocapture','--test-threads=1'],'group-plan-tests')==0;assert 'test result: ok. 1 passed; 0 failed;'in(r/'group-plan-tests.log').read_text();unit=[]
 for mode in f['modes']:
  pins='PEBBLE_HARD_CAP='+('1664'if mode.endswith('walk1664')else'1536')+';SQC_G1M='+('0'if mode=='control'else'1')+';SQC_T=28;SQC_G=259;SQC_LEAF_D='+('0'if mode=='control'else'12'if'd12'in mode else'16'if'd16'in mode else'8')+';GROUP_JUNCTION_FAULT=0'+(''if mode=='control'else';G3_SQ_EXACT_SPLIT=1');params={'G3_UT_PINS':pins,'G3_UT_CAP':('1536'if mode.endswith('sq1536')else'1408'),'G3_UT_BATCHES':'16','G3_UT_SEED':'native-grouped-square-safe28-20261020-v1'};rc=run(['/home/hclau/.cargo/bin/cargo','+1.93.0','test','--release','--bin','build_circuit','g3_square_unit','--','--nocapture','--test-threads=1'],'square-unit-'+mode,extra=params);row={'mode':mode,'exit':rc,'historical_six_walk_domain_edges_excluded_by_existing_unit':True};log=(r/('square-unit-'+mode+'.log')).read_text();row['g3_summary']=re.findall(r'^G3_UT pins=[^\n]+',log,re.M);row['edge_phase_masks']=re.findall(r'^G3_UT edge[^\n]+',log,re.M);unit.append(row)
  if mode!='control':assert rc==0,'New grouped square must pass existing native unit contract before full construction'
 fault={'G3_UT_PINS':'PEBBLE_HARD_CAP=1536;SQC_G1M=1;SQC_T=28;SQC_G=259;SQC_LEAF_D=8;G3_SQ_EXACT_SPLIT=1;GROUP_JUNCTION_FAULT=1','G3_UT_CAP':'1408','G3_UT_BATCHES':'2','G3_UT_SEED':'native-grouped-square-junction-fault-20261020-v1'};rc=run(['/home/hclau/.cargo/bin/cargo','+1.93.0','test','--release','--bin','build_circuit','g3_square_unit','--','--nocapture','--test-threads=1'],'square-unit-junction-fault',extra=fault);assert rc==101 and 'G3_UT pins='in(r/'square-unit-junction-fault.log').read_text();(r/'NATIVE-CONTROLS.json').write_text(json.dumps({'prior_exact_native_controls':27,'group_plan_controls':1,'unit_cases':unit,'deliberate_junction_fault_exit':rc,'scope':'Existing G3 unit contract excludes its six documented walk-domain edges; their raw diagnostics retained. No universal arbitraryfield claim.'},indent=2)+'\n');
 for depth in[8,12,16]:
  for width in[32,64]:
   name=f'leaf-unit-d{depth}-m{width}';assert run(['/home/hclau/.cargo/bin/cargo','+1.93.0','test','--release','--bin','build_circuit','sqleaf_unit','--','--nocapture','--test-threads=1'],name,extra={'SQC_LEAF_D':str(depth),'SQLEAF_M':str(width),'SQLEAF_BATCHES':'64'})==0;assert'test result: ok. 1 passed; 0 failed;'in(r/(name+'.log')).read_text()
 assert run(['/home/hclau/.cargo/bin/cargo','+1.93.0','build','--release','--bin','build_circuit'],'build')==0;results=[];stats=ws/'breakthrough-stackv3-width-stats-20261020'
 for mode in f['modes']:
  dest=r/mode;dest.mkdir();start=time.time();rc=run(['timeout','1800',str(t/'target/release/build_circuit')],'generate-'+mode,dest,{'GROUPED_SQUARE_RESEARCH':mode});row={'mode':mode,'exit':rc,'seconds':time.time()-start}
  if rc:assert mode!='control','Exact currentT control failed; no source binding may be bypassed'
  else:
   row['stream_sha256']=sha(dest/'ops.bin');row['raw_stream_sha256']=sha(dest/'raw.ops.bin');stages=re.findall(r'^GENERIC_STAGE[^\n]+',(r/('generate-'+mode+'.log')).read_text(),re.M);last=stages[-1];row['qubits']=int(re.search(r'nq=(\d+)',last)[1]);row['diagnostic_weight']=float(re.search(r'depth_weight=([\d.]+)',last)[1]);row['generic_stages']=stages
   if mode=='control':assert row['stream_sha256']==f['control_expected_complete_nonce0_sha256'],'Full a871 control must reproduce exactly'
   for tag,file in[('raw','raw.ops.bin'),('output','ops.bin')]:assert run([str(stats/'tool/target/release/native_width_stats'),str(dest/file),str(r/(mode+'-'+tag+'-stats.json'))],'stats-'+mode+'-'+tag,r)==0
  results.append(row);(r/'PROGRESS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items()if k!='generic_stages'}),flush=True)
 assert all(sha(t/p)==h for p,h in{**f['source_files'],**f['protected_files']}.items());(r/'RESULT.json').write_text(json.dumps({'status':'GROUPED_SQUARE_NATIVE_FIXED_CASES_NOT_GATED_OR_SCORED','native_controls':34,'unit_cases':unit,'source_freeze_sha256':sha(r/'SOURCE-FREEZE.json'),'cases':results},indent=2)+'\n');(r/'run.exit').write_text('0\n')
except Exception:
 (r/'run.exit').write_text('1\n');raise
