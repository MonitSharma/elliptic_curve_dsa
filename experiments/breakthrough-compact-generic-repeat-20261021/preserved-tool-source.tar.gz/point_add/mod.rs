mod affine_simplify;
mod quadratic_simplify;
mod truth_simplify;
mod interned_witness;
mod mabsorb;
mod pscan;
mod cond_pass;
mod sqtop_pass;
mod zero_force;
mod classical_factors_xor;
mod breakthrough_generic;
mod classical_wide;
pub fn run(ops:Vec<crate::circuit::Op>)->Vec<crate::circuit::Op>{breakthrough_generic::run(ops)}
