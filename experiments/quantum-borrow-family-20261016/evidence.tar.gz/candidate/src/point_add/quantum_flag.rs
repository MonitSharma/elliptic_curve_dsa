//! All source-defined merged flag erasures gain one lower quantum borrow bit.
//! Complete old regions must survive inherited passes unchanged. All original
//! measurement/classical/snapshot operations remain, with one fresh cleanup MR.
use crate::circuit::{Op,OperationType as K,QubitId,BitId,RegisterId,QubitOrBit,analyze_ops};
use std::collections::BTreeSet;
const NONE:u64=u64::MAX;
const DATA:&[u8]=include_bytes!("quantum_flag.bin");
fn decode(bytes:&[u8])->Vec<Op>{assert_eq!(bytes.len()%56,0);bytes.chunks_exact(56).map(|b|{let u=|i|u64::from_le_bytes(b[i..i+8].try_into().unwrap());let kind=match u(0){0=>K::Neg,1=>K::Register,2=>K::AppendToRegister,3=>K::BitInvert,4=>K::BitStore0,5=>K::BitStore1,6=>K::X,7=>K::Z,8=>K::CX,9=>K::CZ,10=>K::Swap,11=>K::R,12=>K::Hmr,13=>K::CCX,14=>K::CCZ,15=>K::PushCondition,16=>K::PopCondition,17=>K::DebugPrint,_=>panic!("front seam operation")};let o=Op{kind,q_control2:QubitId(u(8)),q_control1:QubitId(u(16)),q_target:QubitId(u(24)),c_target:BitId(u(32)),c_condition:BitId(u(40)),r_target:RegisterId(u(48))};o.validate();o}).collect()}
fn quantum(ops:&[Op])->BTreeSet<u64>{ops.iter().flat_map(|o|[o.q_control1.0,o.q_control2.0,o.q_target.0]).filter(|q|*q!=NONE).collect()}
fn depth(d:usize,o:&Op)->usize{match o.kind{K::PushCondition=>d+1,K::PopCondition=>d.checked_sub(1).expect("front seam scope underflow"),_=>d}}
fn quantum_write(o:&Op,q:u64)->bool{matches!(o.kind,K::X|K::CX|K::CCX|K::R|K::Hmr)&&o.q_target.0==q||o.kind==K::Swap&&(o.q_target.0==q||o.q_control1.0==q)}
fn and(a:i8,b:i8)->i8{if a==0||b==0{0}else if a==1&&b==1{1}else{-1}}
fn xor(a:i8,b:i8)->i8{if a<0||b<0{-1}else{a^b}}
fn store(old:i8,c:i8,value:i8)->i8{if c==0{old}else if c==1||old==value{value}else{-1}}
// Conservative propagation: all declared input bits arbitrary, all auxiliary
// wires zero, every MR outcome arbitrary, and Push stores a value snapshot.
fn prefix_zeros(ops:&[Op],at:usize,nq:usize,nb:usize,regs:&[Vec<QubitOrBit>])->Vec<i8>{let mut q=vec![0;nq];let mut b=vec![0;nb];for r in regs{for w in r{match w{QubitOrBit::Qubit(id)=>q[id.0 as usize]=-1,QubitOrBit::Bit(id)=>b[id.0 as usize]=-1}}}let mut base=1;let mut stack=Vec::new();for o in &ops[..at]{let c=if o.c_condition.0==NONE{base}else{and(base,b[o.c_condition.0 as usize])};let t=o.q_target.0 as usize;let bt=o.c_target.0 as usize;match o.kind{K::X=>q[t]=xor(q[t],c),K::CX=>q[t]=xor(q[t],and(c,q[o.q_control1.0 as usize])),K::CCX=>q[t]=xor(q[t],and(c,and(q[o.q_control1.0 as usize],q[o.q_control2.0 as usize]))),K::Swap=>{let a=o.q_control1.0 as usize;let x=q[t];let y=q[a];q[t]=store(x,c,y);q[a]=store(y,c,x);},K::R|K::Hmr=>{q[t]=store(q[t],c,0);if o.kind==K::Hmr{b[bt]=store(b[bt],c,-1);}},K::BitInvert=>b[bt]=xor(b[bt],c),K::BitStore0=>b[bt]=store(b[bt],c,0),K::BitStore1=>b[bt]=store(b[bt],c,1),K::PushCondition=>{stack.push(base);base=c;},K::PopCondition=>base=stack.pop().unwrap(),_=>{}}}q}

fn specs()->Vec<(Vec<Op>,Vec<Op>)>{assert_eq!(&DATA[..8],b"QFLAG001");let u=|i|u64::from_le_bytes(DATA[i..i+8].try_into().unwrap())as usize;assert_eq!(u(8),12);let mut at=16;let mut out=Vec::new();for _ in 0..12{let n=u(at);let m=u(at+8);at+=16;assert_eq!(m,n+16);let old=decode(&DATA[at..at+56*n]);at+=56*n;let new=decode(&DATA[at..at+56*m]);at+=56*m;out.push((old,new));}assert_eq!(at,DATA.len());out}
struct Meta{seed:u64,target:u64,lower:[u64;3],scratch:&'static[u64]}
const META:[Meta;12]=[
Meta{seed:495,target:1233,lower:[1089, 495, 494],scratch:&[177, 197, 209, 210, 211, 556, 567, 576, 583, 586, 588, 616, 1215, 1218, 1221]},
Meta{seed:495,target:613,lower:[554, 495, 494],scratch:&[208, 209, 210, 211, 556, 576, 579, 586, 612, 616, 764, 958, 1200, 1215, 1221]},
Meta{seed:554,target:613,lower:[495, 554, 855],scratch:&[208, 209, 210, 211, 556, 576, 579, 586, 612, 699, 764, 958, 1200, 1215, 1221]},
Meta{seed:495,target:613,lower:[554, 495, 494],scratch:&[208, 547, 556, 576, 586, 764, 858, 862, 868, 958, 1188, 1200, 1218, 1221, 1225]},
Meta{seed:554,target:612,lower:[495, 554, 855],scratch:&[209, 210, 546, 577, 579, 613, 616, 699, 863, 866, 868, 1200, 1215, 1224, 1228]},
Meta{seed:495,target:612,lower:[554, 495, 494],scratch:&[209, 211, 547, 556, 576, 586, 764, 852, 858, 862, 868, 1188, 1221, 1225, 1226]},
Meta{seed:554,target:863,lower:[495, 554, 855],scratch:&[546, 548, 579, 612, 613, 616, 699, 764, 864, 867, 868, 1200, 1215, 1222, 1224]},
Meta{seed:495,target:862,lower:[554, 495, 494],scratch:&[208, 209, 211, 556, 579, 852, 858, 863, 866, 868, 958, 1188, 1218, 1225, 1226]},
Meta{seed:554,target:792,lower:[495, 554, 855],scratch:&[199, 202, 207, 526, 576, 612, 655, 735, 744, 764, 864, 867, 868, 1215, 1225]},
Meta{seed:495,target:1222,lower:[554, 495, 494],scratch:&[196, 199, 209, 211, 215, 576, 579, 586, 858, 864, 867, 1188, 1221, 1225, 1226]},
Meta{seed:854,target:557,lower:[493, 854, 856],scratch:&[194, 202, 207, 209, 546, 579, 586, 612, 616, 721, 744, 813, 866, 867, 1218, 1221, 1225]},
Meta{seed:493,target:1122,lower:[854, 493, 492],scratch:&[193, 194, 196, 208, 209, 547, 579, 586, 721, 735, 764, 813, 864, 867, 1210, 1221, 1225]},
];

fn static_contract(old:&[Op],new:&[Op],m:&Meta){
 assert_eq!(new.len(),old.len()+16);assert_eq!(old[0].kind,K::Hmr);assert_eq!(old[0].q_target.0,m.target);assert_eq!(old[1].kind,K::PushCondition);assert_eq!(old.last().unwrap().kind,K::PopCondition);
 assert_eq!(&new[..2],&old[..2]);let cleanup=new.len()-9;assert_eq!(new[cleanup].kind,K::Hmr);assert_eq!(new[cleanup].q_target.0,m.target);assert_eq!(new[cleanup].c_target.0,45701);assert_eq!(new[cleanup+1].kind,K::PushCondition);assert_eq!(new[cleanup+1].c_condition.0,45701);assert_eq!(new[cleanup+7].kind,K::PopCondition);assert_eq!(new.last(),old.last());
 let mut restored=new[..2].to_vec();restored.extend_from_slice(&new[10..cleanup]);restored.push(*new.last().unwrap());let mut replaced=0;
 for o in &mut restored[2..old.len()-1]{if matches!(o.kind,K::CX|K::CZ|K::CCX|K::CCZ){for q in [&mut o.q_target,&mut o.q_control1,&mut o.q_control2]{if q.0==m.target{q.0=m.seed;replaced+=1;}}}}
 assert_eq!(replaced,4,"flag old seed interface");assert_eq!(restored,old,"flag original operation/MR/snapshot sequence changed");
 let used=quantum(new);assert!(used.iter().all(|q|*q<1234));assert!(old.iter().all(|o|o.c_target.0==NONE||o.c_target.0<45701));assert!(old.iter().all(|o|o.c_condition.0==NONE||o.c_condition.0<45701));
 let mut d=0;for o in old{d=depth(d,o);}assert_eq!(d,0);for o in new{d=depth(d,o);}assert_eq!(d,0);
 let count=|s:&[Op],k|s.iter().filter(|o|o.kind==k).count();assert_eq!(count(new,K::CCX),count(old,K::CCX)+1);assert_eq!(count(new,K::Hmr),count(old,K::Hmr)+1);assert_eq!(count(new,K::R),count(old,K::R));
}
fn matches(ops:&[Op],old:&[Op])->Vec<usize>{ops.windows(old.len()).enumerate().filter(|(_,s)|*s==old).map(|(i,_)|i).collect()}
pub fn run(ops:Vec<Op>)->Vec<Op>{
 let(nq,nb,_,regs)=analyze_ops(ops.iter());assert_eq!(nq,1234);assert_eq!(nb,45701);assert_eq!(regs.len(),4);assert!(regs.iter().all(|r|r.len()==256));
 let mut found=Vec::new();for(j,(old,new))in specs().into_iter().enumerate(){let m=&META[j];static_contract(&old,&new,m);let pos=matches(&ops,&old);assert_eq!(pos.len(),1,"entire source-defined flag family missing/edited/ambiguous");let at=pos[0];let zeros=prefix_zeros(&ops,at,nq as usize,nb as usize,&regs);for q in m.scratch{assert_eq!(zeros[*q as usize],0,"flag comparator carry not proved zero");}eprintln!("QUANTUM_FLAG_BORROW site={j} at={at} addedT_guarded=1 addedQ=0 addedMR=1");found.push((at,old,new));}
 found.sort_by_key(|s|s.0);for pair in found.windows(2){assert!(pair[0].0+pair[0].1.len()<=pair[1].0,"flag family overlap");}
 let mut out=Vec::with_capacity(ops.len()+192);let mut cursor=0;for(at,old,new)in found{out.extend_from_slice(&ops[cursor..at]);out.extend_from_slice(&new);cursor=at+old.len();}out.extend_from_slice(&ops[cursor..]);let(nq2,nb2,_,regs2)=analyze_ops(out.iter());assert_eq!(nq,nq2);assert_eq!(nb2,nb+1);assert_eq!(regs,regs2);out
}
#[cfg(test)]mod tests{use super::*;
 #[test]fn twelve_complete_contracts(){for(j,(a,b))in specs().iter().enumerate(){static_contract(a,b,&META[j]);}}
 #[test]fn changed_region_fails_unique_match(){for(a,_)in specs(){let mut b=a.clone();b[0].q_target=QubitId(0);assert!(matches(&b,&a).is_empty());}}
 #[test]fn ambiguity_detected(){let(a,_)=specs().remove(0);let mut b=a.clone();b.extend_from_slice(&a);assert_eq!(matches(&b,&a).len(),2);}
 #[test]#[should_panic]fn changed_original_mr_rejected(){let(a,mut b)=specs().remove(0);b[0].c_target=BitId(123);static_contract(&a,&b,&META[0]);}
 #[test]#[should_panic]fn extra_capacity_rejected(){let(a,mut b)=specs().remove(0);b[3].q_target=QubitId(1234);static_contract(&a,&b,&META[0]);}
 #[test]fn zero_rules_conservative(){assert_eq!(and(0,-1),0);assert_eq!(store(0,-1,0),0);assert_eq!(xor(-1,-1),-1);}
}
