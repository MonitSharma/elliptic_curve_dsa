#[path="candidate/src/circuit.rs"] mod circuit;
#[path="quantum_flag.rs"] mod quantum_flag;
