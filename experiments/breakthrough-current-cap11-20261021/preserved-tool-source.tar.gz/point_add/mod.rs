mod affine_simplify;mod quadratic_simplify;mod control_wide;mod classical_wide;
pub fn run(ops:Vec<crate::circuit::Op>,control:bool)->Vec<crate::circuit::Op>{if control{control_wide::simplify_classical(ops)}else{classical_wide::simplify_classical(ops)}}
