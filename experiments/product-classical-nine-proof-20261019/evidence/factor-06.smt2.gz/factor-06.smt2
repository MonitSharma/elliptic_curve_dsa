; benchmark generated from python API
(set-info :status unknown)
(declare-fun atom_768 () Bool)
(declare-fun atom_7109061 () Bool)
(assert
 (let (($x9 (or (and atom_768))))
(let (($x10 (or (and (not atom_7109061)))))
(let (($x6 (or and)))
(let (($x79 (and $x6 $x6 $x10 $x9)))
(xor $x79 $x79))))))
(check-sat)
