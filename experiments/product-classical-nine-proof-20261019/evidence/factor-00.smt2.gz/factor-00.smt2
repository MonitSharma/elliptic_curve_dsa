; benchmark generated from python API
(set-info :status unknown)
(declare-fun atom_768 () Bool)
(declare-fun atom_256 () Bool)
(assert
 (let (($x13 (or (and atom_768))))
(let (($x10 (or (and (not atom_256)))))
(let (($x6 (or and)))
(let (($x14 (and $x6 $x6 $x10 $x13)))
(xor $x14 $x14))))))
(check-sat)
