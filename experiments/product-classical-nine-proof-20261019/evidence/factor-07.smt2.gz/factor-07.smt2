; benchmark generated from python API
(set-info :status unknown)
(declare-fun atom_1004 () Bool)
(declare-fun atom_7119406 () Bool)
(declare-fun atom_7119405 () Bool)
(assert
 (let (($x49 (or (and atom_1004))))
(let (($x50 (not $x49)))
(let (($x46 (or (and atom_1004 (not atom_7119405) (not atom_7119406)) (and atom_1004 atom_7119405 (not atom_7119406)) (and atom_1004 (not atom_7119405) atom_7119406) (and (not atom_1004) atom_7119405 atom_7119406))))
(let (($x6 (or and)))
(let (($x36 (or (and atom_7119405))))
(xor (and $x36 $x6 $x46 (or (and atom_7119406))) (and $x36 $x6 $x46 $x50))))))))
(check-sat)
