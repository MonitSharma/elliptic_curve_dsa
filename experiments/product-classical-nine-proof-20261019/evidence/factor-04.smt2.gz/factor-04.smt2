; benchmark generated from python API
(set-info :status unknown)
(declare-fun atom_512 () Bool)
(declare-fun atom_7117654 () Bool)
(assert
 (let (($x11 (or (and (not atom_512)))))
(let (($x9 (or (and atom_7117654))))
(let (($x6 (or and)))
(let (($x12 (and $x6 $x6 $x9 $x11)))
(xor $x12 $x12))))))
(check-sat)
