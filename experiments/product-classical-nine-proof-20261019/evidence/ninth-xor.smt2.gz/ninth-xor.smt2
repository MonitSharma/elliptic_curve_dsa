; benchmark generated from python API
(set-info :status unknown)
(declare-fun y () Bool)
(declare-fun v () Bool)
(declare-fun u () Bool)
(declare-fun t () Bool)
(assert
 (xor (xor t (and (xor u v) y)) (xor (xor t (and u y)) (and v y))))
(check-sat)
