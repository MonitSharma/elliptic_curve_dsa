; benchmark generated from python API
(set-info :status unknown)
(declare-fun atom_748 () Bool)
(declare-fun atom_7118241 () Bool)
(declare-fun atom_7118240 () Bool)
(assert
 (let (($x50 (or (and atom_748))))
(let (($x51 (not $x50)))
(let (($x46 (or (and atom_748 (not atom_7118240) (not atom_7118241)) (and atom_748 atom_7118240 (not atom_7118241)) (and atom_748 (not atom_7118240) atom_7118241) (and (not atom_748) atom_7118240 atom_7118241))))
(let (($x6 (or and)))
(let (($x36 (or (and atom_7118240))))
(xor (and $x36 $x6 $x46 (or (and atom_7118241))) (and $x36 $x6 $x46 $x51))))))))
(check-sat)
