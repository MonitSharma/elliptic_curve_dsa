; benchmark generated from python API
(set-info :status unknown)
(declare-fun atom_2978 () Bool)
(declare-fun atom_1761709 () Bool)
(assert
 (let (($x15 (or (and atom_2978))))
(let (($x33 (not $x15)))
(let (($x9 (or (and atom_1761709))))
(let (($x6 (or and)))
(xor (and $x6 $x6 $x9 (or (and (not atom_2978)))) (and $x6 $x6 $x9 $x33)))))))
(check-sat)
