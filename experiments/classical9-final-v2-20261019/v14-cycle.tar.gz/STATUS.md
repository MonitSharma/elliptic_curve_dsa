# Queue-only classical9 finalizer, explicit next-job registry

Copies the current bound auditor/native preparation and six corruption controls unchanged. Only the final shell root and read-only resource-profile version change. New profile registers forthcoming classical12 runtime jobs. Prepare and test before intentionally retiring the idle old watcher. No circuit, search order, nonce, score or benchmark changes. Never modify a running watched source.
