use super::modular::{mod_add, mod_rsub_vented_loaded, mod_sub_vented};
use super::{Builder, N};
use crate::circuit::{BitId, QubitId};
use alloy_primitives::U256;

/// secp256k1 uses `p = 2^256 - C`, so `2^256 == C (mod p)`. The same constant
/// [`super::modular::f`] derives from the modulus, in the width this file's
/// classical arithmetic works in.
const C: u128 = (1u128 << 32) + 977;
/// Width of the register holding a small multiple of `C` (`2*C < 2^34`).
const C_BITS: usize = 35;

fn zero(circ: &mut Builder, bits: &[BitId]) {
    for &b in bits {
        circ.bit_store0(b);
    }
}

fn copy_into(circ: &mut Builder, dst: &[BitId], src: &[BitId]) {
    for (&d, &s) in dst.iter().zip(src) {
        circ.bit_copy(d, s);
    }
}

/// Loads a classical coordinate into a fresh ancilla register, runs one
/// modular operation against it, then unitarily uncomputes the register back
/// to |0> and releases it. When the coordinate was *derived* here rather than
/// owned by the caller, its classical bits are returned to the pool too.
fn against_coord(
    circ: &mut Builder,
    coord: &[BitId],
    derived: bool,
    f: impl FnOnce(&mut Builder, &[QubitId]),
) {
    let temp = circ.alloc_qubits(coord.len());
    for (&q, &b) in temp.iter().zip(coord) {
        circ.x_if_bit(q, b);
    }
    f(circ, &temp);
    for (&q, &b) in temp.iter().zip(coord) {
        circ.x_if_bit(q, b);
    }
    for q in temp {
        circ.free(q);
    }
    if derived {
        zero(circ, coord);
        circ.free_bit_vec(coord);
    }
}

pub fn coord_sub(circ: &mut Builder, dst: &[QubitId], coord: &[BitId]) {
    assert_eq!(dst.len(), N);
    assert_eq!(coord.len(), N);
    if super::modular::r5_cbits(16) {
        // R5_CBITS bit 16: mod_sub_vented with the classical operand folded into the carry wires.
        let (fs, k) = (super::modular::go_fs("GO_FG_M"), super::modular::erase_compare());
        circ.x_all(dst);
        let ov = circ.alloc_qubit();
        super::modular::r5_ripple_add_cbits(circ, coord, dst, ov);
        super::const_arith::cadd_const_trunc(circ, &dst[..fs], super::modular::f(), ov, false);
        let tv = circ.alloc_qubits(k);
        for i in 0..k { circ.x_if_bit(tv[i], coord[N - k + i]); }
        if super::modular::r5_ccmp(8) {
            super::compare::erase_with_compare_v0(circ, ov, &dst[N - k..], &tv, coord[N - k]);
        } else {
            super::compare::erase_with_compare(circ, ov, &dst[N - k..], &tv, None);
        }
        for i in 0..k { circ.x_if_bit(tv[i], coord[N - k + i]); }
        circ.free_vec(&tv);
        circ.free(ov);
        circ.x_all(dst);
        return;
    }
    against_coord(circ, coord, false, |circ, temp| {
        mod_sub_vented(circ, temp, dst);
    });
}

/// PP_J_YFUSE: `dst <- (dst - coord)/2 (mod p)`.
pub fn coord_sub_halve(circ: &mut Builder, dst: &[QubitId], coord: &[BitId]) {
    against_coord(circ, coord, false, |circ, temp| {
        super::j_fuse::mod_sub_halve(circ, temp, dst);
    });
}

/// PP_J_YFUSE: `dst <- 2*dst - coord (mod p)`.
pub fn coord_double_sub(circ: &mut Builder, dst: &[QubitId], coord: &[BitId]) {
    against_coord(circ, coord, false, |circ, temp| {
        super::j_fuse::mod_double_sub(circ, temp, dst);
    });
}

/// PP_J_XFUSE: `dst <- dst - coord (mod 2^256)`, borrow kept for the walk.
pub fn coord_sub_keep(circ: &mut Builder, dst: &[QubitId], coord: &[BitId]) {
    against_coord(circ, coord, false, |circ, temp| {
        super::j_fuse::mod_sub_keep_borrow(circ, temp, dst, coord);
    });
}

pub fn coord_rsub(circ: &mut Builder, x: &[QubitId], coord: &[BitId]) {
    assert_eq!(x.len(), N);
    assert_eq!(coord.len(), N);
    let coord_p1 = classical_plus1_mod_2n(circ, coord);
    let stash = super::j_fuse::take_r0();
    if super::back_seam::mul_fused() {
        // I-2 back seam: `x` arrives uncorrected from the multiply's FD unseed (see `back_seam`).
        assert!(stash.is_none(), "back seam: r0-fused reverse subtraction is not the seam's consumer");
        super::back_seam::coord_op_at(circ, x, &coord_p1, super::back_seam::Leg::Mul, N,
            super::modular::f(), super::modular::go_fs("GO_FG_M"), super::modular::erase_compare(), true);
        return;
    }
    against_coord(circ, &coord_p1, true, |circ, temp| {
        match stash {
            Some((a0, n)) => super::j_fuse::mod_rsub_r0fused(circ, temp, x, a0, n),
            None => mod_rsub_vented_loaded(circ, temp, x),
        }
    });
}

pub fn coord_add3x(circ: &mut Builder, dst: &[QubitId], coord: &[BitId]) {
    assert_eq!(dst.len(), N);
    assert_eq!(coord.len(), N);
    let mut three_coord = classical_times3_mod_q(circ, coord);
    // SQ_ROW0_COPY: the square that follows leaves x2 short by a constant;
    // add it here with the classical coordinate, where it costs no Toffoli.
    let offset = super::square::sub_square_offset();
    if !offset.is_zero() {
        let shifted = classical_add_const_mod_q(circ, &three_coord, offset);
        zero(circ, &three_coord);
        circ.free_bit_vec(&three_coord);
        three_coord = shifted;
    }
    let stash = super::j_fuse::take_r0();
    if super::back_seam::div_fused() {
        // I-2 back seam: `dst` arrives uncorrected from the divide's FD unseed (see `back_seam`).
        assert!(stash.is_none(), "back seam: r0-fused coordinate add is not the seam's consumer");
        super::back_seam::coord_op_at(circ, dst, &three_coord, super::back_seam::Leg::Div, N,
            super::modular::f(), super::modular::go_fs("GO_FG_M"), super::modular::erase_compare(), true);
        return;
    }
    against_coord(circ, &three_coord, true, |circ, temp| {
        match stash {
            Some((a0, n)) => super::j_fuse::mod_add_r0fused(circ, temp, dst, a0, n),
            None => mod_add(circ, temp, dst),
        }
    });
}

/// Leapfrog `LF_SEAMS`: the classical operand [`coord_add3x`] adds (3 coord + the square's offset, mod p), in fresh
/// bits (release with [`release_operand`]).
pub(crate) fn add3x_operand(circ: &mut Builder, coord: &[BitId]) -> Vec<BitId> {
    let three_coord = classical_times3_mod_q(circ, coord);
    let offset = super::square::sub_square_offset();
    if offset.is_zero() {
        return three_coord;
    }
    let shifted = classical_add_const_mod_q(circ, &three_coord, offset);
    zero(circ, &three_coord);
    circ.free_bit_vec(&three_coord);
    shifted
}
/// Leapfrog `LF_SEAMS`: `coord + 1 mod 2^N` in fresh bits (the operand [`coord_rsub`] loads).
pub(crate) fn plus1_operand(circ: &mut Builder, coord: &[BitId]) -> Vec<BitId> {
    classical_plus1_mod_2n(circ, coord)
}
pub(crate) fn release_operand(circ: &mut Builder, bits: &[BitId]) {
    zero(circ, bits);
    circ.free_bit_vec(bits);
}

/// `(v + k) mod 2^len` in freshly allocated classical bits, `k < 2^128`.
pub(crate) fn classical_add_const_mod2n_at(circ: &mut Builder, v: &[BitId], k: u128) -> Vec<BitId> {
    let s = circ.alloc_bits(v.len());
    copy_into(circ, &s, v);
    classical_add_const(circ, &s, k);
    s
}

/// `3 * coord mod p`, in freshly allocated classical bits.
fn classical_times3_mod_q(circ: &mut Builder, coord: &[BitId]) -> Vec<BitId> {
    assert_eq!(coord.len(), N);

    // s = 3*coord exactly, in N+2 bits.
    let s = circ.alloc_bits(N + 2);
    zero(circ, &s);
    for _ in 0..3 {
        classical_add_into(circ, &s, coord);
    }

    // Fold the overflow back in with 2^256 == C. The high part `s >> 256` is
    // 0, 1 or 2 (never 3: 3*coord < 3*2^256), so the two high bits are
    // mutually exclusive and their contributions can just be OR-ed together.
    // That leaves r = (s mod 2^256) + (s >> 256)*C < 2^256 + 2^34.
    let av = circ.alloc_bits(C_BITS);
    zero(circ, &av);
    or_const_if(circ, &av, C, s[N]);
    or_const_if(circ, &av, 2 * C, s[N + 1]);

    let r = circ.alloc_bits(N + 1);
    copy_into(circ, &r, &s[..N]);
    circ.bit_store0(r[N]);
    classical_add_into(circ, &r, &av);

    // One conditional subtraction of p, as r - p == (r + C) - 2^256. Since
    // r + C < 2^257 it still fits in N+1 bits, so its top bit is exactly the
    // "r >= p" flag and its low N bits are the reduced value.
    let tmp = circ.alloc_bits(N + 1);
    copy_into(circ, &tmp, &r);
    classical_add_const(circ, &tmp, C);

    // result = tmp[N] ? tmp : r, as r ^ (tmp[N] & (r ^ tmp)). Folding r into
    // tmp destroys tmp, which is released immediately below anyway.
    let result = circ.alloc_bits(N);
    for i in 0..N {
        circ.bit_xor_into(tmp[i], r[i]);
        circ.bit_copy(result[i], r[i]);
        circ.bit_and_xor_into(result[i], tmp[N], tmp[i]);
    }

    for reg in [&tmp, &av, &r, &s] {
        zero(circ, reg);
        circ.free_bit_vec(reg);
    }
    result
}

/// `(v + k) mod p` for `v < p` and a constant `k < p`, in freshly allocated
/// classical bits. Same conditional subtraction as [`classical_times3_mod_q`].
fn classical_add_const_mod_q(circ: &mut Builder, v: &[BitId], k: U256) -> Vec<BitId> {
    classical_add_const_mod_at(circ, v, k, N, C)
}

/// [`classical_add_const_mod_q`] at width `n` with `p = 2^n - cc`.
pub(crate) fn classical_add_const_mod_at(circ: &mut Builder, v: &[BitId], k: U256, n: usize, cc: u128) -> Vec<BitId> {
    assert_eq!(v.len(), n);
    let r = circ.alloc_bits(n + 1);
    copy_into(circ, &r, v);
    circ.bit_store0(r[n]);
    let addend = circ.alloc_bits(n);
    for (i, &b) in addend.iter().enumerate() {
        if k.bit(i) { circ.bit_store1(b); } else { circ.bit_store0(b); }
    }
    classical_add_into(circ, &r, &addend);
    zero(circ, &addend);
    circ.free_bit_vec(&addend);

    // r < 2p, so r + C < 2^(n+1) and its top bit is exactly "r >= p".
    let tmp = circ.alloc_bits(n + 1);
    copy_into(circ, &tmp, &r);
    classical_add_const(circ, &tmp, cc);
    let result = circ.alloc_bits(n);
    for i in 0..n {
        circ.bit_xor_into(tmp[i], r[i]);
        circ.bit_copy(result[i], r[i]);
        circ.bit_and_xor_into(result[i], tmp[n], tmp[i]);
    }
    for reg in [&tmp, &r] {
        zero(circ, reg);
        circ.free_bit_vec(reg);
    }
    result
}

/// `coord + 1 mod 2^256`, in freshly allocated classical bits.
fn classical_plus1_mod_2n(circ: &mut Builder, coord: &[BitId]) -> Vec<BitId> {
    assert_eq!(coord.len(), N);
    let s = circ.alloc_bits(N);
    copy_into(circ, &s, coord);
    classical_add_const(circ, &s, 1);
    s
}

/// `dst |= k` under `gate`. `dst` must already be 0 wherever `k` has a bit.
fn or_const_if(circ: &mut Builder, dst: &[BitId], k: u128, gate: BitId) {
    for (i, &b) in dst.iter().enumerate() {
        if (k >> i) & 1 == 1 {
            circ.push_condition(gate);
            circ.bit_store1(b);
            circ.pop_condition();
        }
    }
}

/// `acc += k`, modulo `2^acc.len()`.
fn classical_add_const(circ: &mut Builder, acc: &[BitId], k: u128) {
    let w = (128 - k.leading_zeros() as usize).min(acc.len());
    let addend = circ.alloc_bits(w);
    for (i, &b) in addend.iter().enumerate() {
        if (k >> i) & 1 == 1 {
            circ.bit_store1(b);
        } else {
            circ.bit_store0(b);
        }
    }
    classical_add_into(circ, acc, &addend);
    zero(circ, &addend);
    circ.free_bit_vec(&addend);
}

/// `acc += addend`, modulo `2^acc.len()`. `addend` may be the shorter register.
fn classical_add_into(circ: &mut Builder, acc: &[BitId], addend: &[BitId]) {
    let carry = circ.alloc_bit();
    circ.bit_store0(carry);
    let newcarry = circ.alloc_bit();
    for (i, &acc_i) in acc.iter().enumerate() {
        circ.bit_store0(newcarry);
        match addend.get(i) {
            Some(&a) => {
                circ.bit_and_xor_into(newcarry, acc_i, a);
                circ.bit_and_xor_into(newcarry, acc_i, carry);
                circ.bit_and_xor_into(newcarry, a, carry);
                circ.bit_xor_into(acc_i, a);
            }
            None => circ.bit_and_xor_into(newcarry, acc_i, carry),
        }
        circ.bit_xor_into(acc_i, carry);
        circ.bit_copy(carry, newcarry);
    }
    circ.bit_store0(newcarry);
    circ.bit_store0(carry);
    circ.free_bit(newcarry);
    circ.free_bit(carry);
}
