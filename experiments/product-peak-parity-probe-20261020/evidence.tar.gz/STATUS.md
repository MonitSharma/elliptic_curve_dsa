# Exact ANF parity at the first complete-width state

Declared before launch. Static point1444755 selected from the finished strong
clean-boundary probe on frozen cache input, not from any sampled input/nonce.
Compare unchanged baseline and read-only snapshot copies: prefix hashes, all
sites/atom/cut counters, global ABI metadata all equal. Include every global
ABI annotation before interpreting a prefix; late input annotations must never
be assumed clean.17 tests per copy before execution. Fixed cap256/degree12.
Independent unbounded integer GF2 elimination on the two saved states before/
after the peak checks every discovered relation by raw polynomial symmetric
difference. Exclude high wire and seek non-ABI donors whose ENTIRE relation is
untouched during the fixed epoch. Exact rank here concerns a conservative
abstraction, not physical-width optimality. No lease/circuit/gate/nonce/score.
One server CPU/12GiB, global resource check before pinning actual work.
