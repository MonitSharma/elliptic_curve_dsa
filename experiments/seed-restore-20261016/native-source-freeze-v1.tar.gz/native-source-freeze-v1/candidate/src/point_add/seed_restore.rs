use crate::circuit::{Op,OperationType as K,QubitId,BitId,RegisterId,analyze_ops};
use sha3::{Shake256,digest::{Update,ExtendableOutput,XofReader}};
const NONE:u64=u64::MAX;
const DATA:&[u8]=include_bytes!("seed_restore.bin");
const EXPECTED_INPUT:[u8;32]=[67, 103, 119, 99, 108, 231, 10, 124, 182, 32, 135, 211, 223, 6, 20, 141, 84, 29, 23, 208, 198, 168, 227, 92, 52, 180, 8, 8, 18, 89, 143, 117];
const INPUT_OPS:usize=11630620;
fn decode(bytes:&[u8])->Vec<Op>{assert_eq!(bytes.len()%56,0);bytes.chunks_exact(56).map(|r|{let f:Vec<u64>=r.chunks_exact(8).map(|x|u64::from_le_bytes(x.try_into().unwrap())).collect();let kind=match f[0]{0=>K::Neg,1=>K::Register,2=>K::AppendToRegister,3=>K::BitInvert,4=>K::BitStore0,5=>K::BitStore1,6=>K::X,7=>K::Z,8=>K::CX,9=>K::CZ,10=>K::Swap,11=>K::R,12=>K::Hmr,13=>K::CCX,14=>K::CCZ,15=>K::PushCondition,16=>K::PopCondition,17=>K::DebugPrint,_=>panic!("unknown op")};let o=Op{kind,q_control2:QubitId(f[1]),q_control1:QubitId(f[2]),q_target:QubitId(f[3]),c_target:BitId(f[4]),c_condition:BitId(f[5]),r_target:RegisterId(f[6])};o.validate();o}).collect()}
fn digest(ops:&[Op])->[u8;32]{let mut h=Shake256::default();for o in ops{for v in [o.kind as u64,o.q_control2.0,o.q_control1.0,o.q_target.0,o.c_target.0,o.c_condition.0,o.r_target.0]{h.update(&v.to_le_bytes());}}let mut out=[0u8;32];h.finalize_xof().read(&mut out);out}

fn corrected(old:&[Op])->Vec<Op>{assert_eq!(old.len(),933);let mut out=old.to_vec();let o=old[142];assert_eq!(o.kind,K::CX);assert_eq!(o.q_control2.0,NONE);assert_eq!((o.q_control1.0,o.q_target.0),(1106,1134));assert_eq!((o.c_target.0,o.c_condition.0,o.r_target.0),(NONE,NONE,NONE));out[142].kind=K::CCX;out[142].q_control2=QubitId(881);out[142].validate();out}
fn positions(ops:&[Op],old:&[Op])->Vec<usize>{ops.windows(old.len()).enumerate().filter_map(|(i,w)|(w==old).then_some(i)).collect()}
pub fn run(mut ops:Vec<Op>)->Vec<Op>{assert_eq!(ops.len(),INPUT_OPS);assert_eq!(digest(&ops),EXPECTED_INPUT,"frozen complete post-table input");let(nq,nb,_,regs)=analyze_ops(ops.iter());assert_eq!((nq,nb),(1234,45701));let old=decode(DATA);let new=corrected(&old);let hits=positions(&ops,&old);assert_eq!(hits.len(),1,"complete ALL-seed family changed/ambiguous");let at=hits[0];let mut depth=0isize;for o in &ops[..at]{if o.kind==K::PushCondition{depth+=1}if o.kind==K::PopCondition{depth-=1}}assert_eq!(depth,0);ops[at..at+old.len()].copy_from_slice(&new);let(nq2,nb2,_,regs2)=analyze_ops(ops.iter());assert_eq!((nq2,nb2),(nq,nb));assert_eq!(regs2,regs);eprintln!("SEED_RESTORE all_helpers=1 all_dropped_controls=1 at={} addedT=1 addedQ=0 addedMR=0",at+142);ops}
#[cfg(test)]mod tests{use super::*;
#[test]fn exactly_one_original_control_restored(){let old=decode(DATA);let new=corrected(&old);let diff:Vec<_>=old.iter().zip(&new).enumerate().filter_map(|(i,(a,b))|(a!=b).then_some(i)).collect();assert_eq!(diff,vec![142]);assert_eq!(new[142].q_control2.0,881);}
#[test]fn ambiguity_detected(){let old=decode(DATA);let mut x=old.clone();x.extend_from_slice(&old);assert_eq!(positions(&x,&old).len(),2);}
#[test]#[should_panic]fn wrong_survivor_rejected(){let mut old=decode(DATA);old[142].q_control1=QubitId(1107);corrected(&old);}
#[test]#[should_panic]fn conditional_edit_rejected(){let mut old=decode(DATA);old[142].c_condition=BitId(3);corrected(&old);}
#[test]fn whole_input_mutation_changes_digest(){let old=decode(DATA);let mut x=old.clone();x[0].kind=K::Neg;assert_ne!(digest(&x),digest(&old));}}
