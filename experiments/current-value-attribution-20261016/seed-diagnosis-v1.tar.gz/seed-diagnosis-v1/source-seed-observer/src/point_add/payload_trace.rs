//! Gate-inert payload transition observer. No circuit gates emitted.
use crate::circuit::{analyze_ops,Op,QubitId};
use alloy_primitives::U256;
use sha3::{Shake256,digest::{Update,ExtendableOutput}};
use std::{collections::HashMap,sync::Mutex};
#[derive(Clone)]
struct Mark{at:usize,id:usize,before:bool,phase:&'static str,t:usize,rev:bool,skip:bool,pay:[Vec<QubitId>;2],letter:Vec<QubitId>}
static MARKS:Mutex<Vec<Mark>>=Mutex::new(Vec::new());
#[derive(Clone)]
struct Fold{at:usize,id:usize,before:bool,phase:&'static str,t:usize,rev:bool,acc:Vec<QubitId>,e:[QubitId;3],nm:[QubitId;3],shift:[QubitId;2],src:Vec<QubitId>}
static FOLDS:Mutex<Vec<Fold>>=Mutex::new(Vec::new());
#[derive(Clone)]
struct Stage{at:usize,label:&'static str,x:Vec<QubitId>,y:Vec<QubitId>,offset:U256}
static STAGES:Mutex<Vec<Stage>>=Mutex::new(Vec::new());
#[derive(Clone)]
struct Window{at:usize,id:usize,before:bool,inv:bool,shift:usize,value:Vec<QubitId>,out:Vec<QubitId>,cin:Option<QubitId>}
static WINDOWS:Mutex<Vec<Window>>=Mutex::new(Vec::new());
pub fn window_begin(at:usize,inv:bool,shift:usize,value:&[QubitId],out:&[QubitId],cin:Option<QubitId>)->usize{let mut ws=WINDOWS.lock().unwrap();let id=ws.len();ws.push(Window{at,id,before:true,inv,shift,value:value.to_vec(),out:out.to_vec(),cin});id}
pub fn window_end(id:usize,at:usize){let mut ws=WINDOWS.lock().unwrap();let mut w=ws.iter().find(|w|w.id==id&&w.before).unwrap().clone();w.before=false;w.at=at;ws.push(w);}
fn unsigned(q:&[QubitId],words:&[u64],lane:usize)->U256{let mut v=U256::ZERO;assert!(q.len()<=256);for(i,q)in q.iter().enumerate(){if words[q.0 as usize]>>lane&1!=0{v|=U256::from(1)<<i;}}v}
pub fn stage(at:usize,label:&'static str,x:&[QubitId],y:&[QubitId],offset:U256){STAGES.lock().unwrap().push(Stage{at,label,x:x.to_vec(),y:y.to_vec(),offset});}
fn pow(mut a:U256,mut n:U256,p:U256)->U256{let mut r=U256::from(1);while n!=U256::ZERO{if n.bit(0){r=r.mul_mod(a,p);}a=a.mul_mod(a,p);n>>=1;}r}
fn stage_word(qs:&[QubitId],words:&[u64],lane:usize,p:U256)->U256{let f=U256::from(0x1000003d1u64);let mut v=U256::ZERO;for(i,q)in qs.iter().enumerate(){if words[q.0 as usize]>>lane&1!=0{v=v.add_mod(if i<256{U256::from(1)<<i}else{f<<(i-256)},p);}}if qs.len()>256&&words[qs.last().unwrap().0 as usize]>>lane&1!=0{v=sub(v,f<<(qs.len()-256),p);}v}
pub fn fold_begin(at:usize,acc:&[QubitId],e:[QubitId;3],nm:[QubitId;3],k1:QubitId,k2:QubitId,rev:bool,src:&[QubitId])->usize{
 let marks=MARKS.lock().unwrap();let (phase,t)=marks.last().map(|m|(m.phase,m.t)).unwrap_or(("divide",0));let mut fs=FOLDS.lock().unwrap();let id=fs.len();fs.push(Fold{at,id,before:true,phase,t,rev,acc:acc.to_vec(),e,nm,shift:[k1,k2],src:src.to_vec()});id
}
pub fn fold_end(id:usize,at:usize){let mut fs=FOLDS.lock().unwrap();let mut f=fs.iter().find(|f|f.id==id&&f.before).unwrap().clone();f.at=at;f.before=false;fs.push(f);}
fn small(q:&[QubitId],words:&[u64],lane:usize)->i128{assert!(q.len()<=63);q.iter().enumerate().map(|(i,q)|((words[q.0 as usize]>>lane&1)as i128)<<i).sum()}
pub fn begin(at:usize,phase:&'static str,t:usize,rev:bool,pay:&[Vec<QubitId>;2])->usize{
 let mut m=MARKS.lock().unwrap();let id=m.len();m.push(Mark{at,id,before:true,phase,t,rev,skip:false,pay:pay.clone(),letter:vec![]});id
}
pub fn end(id:usize,at:usize,pay:&[Vec<QubitId>;2],letter:&[QubitId],skip:bool){
 let mut ms=MARKS.lock().unwrap();let mut m=ms.iter().find(|m|m.id==id&&m.before).unwrap().clone();m.at=at;m.before=false;m.pay=pay.clone();m.letter=letter.to_vec();m.skip=skip;ms.push(m);
}
pub fn set_letter(id:usize,letter:&[QubitId]){let mut ms=MARKS.lock().unwrap();let m=ms.iter_mut().find(|m|m.id==id&&m.before).unwrap();m.letter=letter.to_vec();}
fn sub(a:U256,b:U256,p:U256)->U256{if a>=b{a-b}else{p-(b-a)}}
fn half(v:U256,p:U256)->U256{if v.bit(0){(v>>1)+(p>>1)+U256::from(1)}else{v>>1}}
fn word(q:&[QubitId],w:&[u64],lane:usize)->U256{assert_eq!(q.len(),256);let mut v=U256::ZERO;for(i,q)in q.iter().enumerate(){if w[q.0 as usize]>>lane&1!=0{v|=U256::from(1)<<i;}}v}
fn norm(v:U256,p:U256)->U256{if v>=p{v-p}else{v}}

pub fn dump(ops:&[Op]){std::fs::write("/home/hclau/ecdsa_research/current-value-attribution-20261016/raw-seed-markers.jsonl",SEEDS.lock().unwrap().join("\n")+"\n").unwrap();use std::io::Write;let root="/home/hclau/ecdsa_research/current-value-attribution-20261016";let mut out=std::fs::File::create(format!("{root}/raw-seed-base-markers.jsonl")).unwrap();let ids=|q:&[QubitId]|q.iter().map(|q|q.0).collect::<Vec<_>>();
for m in MARKS.lock().unwrap().iter(){writeln!(out,"{{\"family\":\"payload\",\"at\":{},\"id\":{},\"before\":{},\"phase\":\"{}\",\"tick\":{},\"rev\":{},\"skip\":{},\"pay0\":{:?},\"pay1\":{:?},\"letter\":{:?}}}",m.at,m.id,m.before,m.phase,m.t,m.rev,m.skip,ids(&m.pay[0]),ids(&m.pay[1]),ids(&m.letter)).unwrap();}
for m in FOLDS.lock().unwrap().iter(){writeln!(out,"{{\"family\":\"fold\",\"at\":{},\"id\":{},\"before\":{},\"phase\":\"{}\",\"tick\":{},\"rev\":{},\"acc\":{:?},\"e\":{:?},\"nm\":{:?},\"shift\":{:?},\"src\":{:?}}}",m.at,m.id,m.before,m.phase,m.t,m.rev,ids(&m.acc),ids(&m.e),ids(&m.nm),ids(&m.shift),ids(&m.src)).unwrap();}
for(id,m)in STAGES.lock().unwrap().iter().enumerate(){writeln!(out,"{{\"family\":\"stage\",\"at\":{},\"id\":{id},\"label\":\"{}\",\"x\":{:?},\"y\":{:?},\"offset\":\"{:#x}\"}}",m.at,m.label,ids(&m.x),ids(&m.y),m.offset).unwrap();}
for m in WINDOWS.lock().unwrap().iter(){writeln!(out,"{{\"family\":\"window\",\"at\":{},\"id\":{},\"before\":{},\"inv\":{},\"shift\":{},\"value\":{:?},\"out\":{:?},\"cin\":{}}}",m.at,m.id,m.before,m.inv,m.shift,ids(&m.value),ids(&m.out),m.cin.map_or("null".to_string(),|q|q.0.to_string())).unwrap();}
crate::write_ops(ops,std::path::Path::new(&format!("{root}/raw-seed-builder.bin"))).unwrap();eprintln!("SOURCE_MARKERS_ONLY; ACTUAL FINAL OPS MUST BE REPLAYED SEPARATELY; no score");
}

static SEEDS:Mutex<Vec<String>>=Mutex::new(Vec::new());
pub fn seed_mark(at:usize,id:usize,before:bool,target:&[QubitId])->usize{
let mut ms=SEEDS.lock().unwrap();let id=if before{ms.len()}else{id};let ids=target.iter().map(|q|q.0).collect::<Vec<_>>();ms.push(format!("{{\"family\":\"seed\",\"id\":{id},\"at\":{at},\"before\":{before},\"target\":{ids:?}}}"));id}
