# Product67 complete-filter qualification: in progress

This isolated disabled tool binds frozen candidate268aefe2, universal67 proof
303a75ec and its source-bound per-input transfer. The original zeroMR function
and dependency mask apply through that equivalence; no changed arithmetic is
assumed. The live product25 runtime and search remain untouched.

The first native build passed and its full9024 q/b/phase/physicalMR comparison
passed. The driver then correctly failed because the requested candidate-seed
control marker was absent: I had omitted its CANDIDATE_SEED_SHADOW switch.
All first-run logs and the exact driver are retained under failed-v1. The
corrected driver enables that existing control without changing circuit, tool
binary, fixed inputs or acceptance tests. The second run reuses the hash-pinned
binary, repeats the same prescribed checks and retains separate exit/log files.
No completed runtime PASS, nonce selection or resource record is claimed yet.
