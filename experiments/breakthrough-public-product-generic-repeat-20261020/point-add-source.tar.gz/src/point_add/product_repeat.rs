use crate::circuit::{Op,OperationType as K,QubitId};use sha3::{Digest,Sha3_256};
fn strip_identity_tail(mut ops:Vec<Op>)->Vec<Op>{assert!(ops.len()>=96);let no=u64::MAX;let end=ops.len()-96;for pair in ops[end..].chunks_exact(2){assert_eq!(pair[0],pair[1]);let o=pair[0];assert_eq!(o.kind,K::X);assert!(o.q_target.0<2);assert_eq!((o.q_control2.0,o.q_control1.0,o.c_target.0,o.c_condition.0,o.r_target.0),(no,no,no,no,no));}ops.truncate(end);ops}
pub(super)fn run(ops:Vec<Op>)->Vec<Op>{assert_eq!(ops.len(),11682054);let mut h=Sha3_256::new();for o in &ops{for v in[o.kind as u64,o.q_control2.0,o.q_control1.0,o.q_target.0,o.c_target.0,o.c_condition.0,o.r_target.0]{h.update(v.to_le_bytes());}}assert_eq!(format!("{:x}",h.finalize()),"3000fc9119ca08944ea9f087f1f69d42a149ede69ea6221b8a60e2f23929171b");let mut ops=super::breakthrough_generic::run(strip_identity_tail(ops));for _ in 0..48{let mut o=Op::empty();o.kind=K::X;o.q_target=QubitId(0);ops.extend([o,o]);}ops}
#[cfg(test)]mod tests{use super::*;
fn tail(k:u64)->Vec<Op>{let mut ops=vec![];for bit in 0..48{let mut o=Op::empty();o.kind=K::X;o.q_target=QubitId((k>>bit)&1);ops.extend([o,o]);}ops}
#[test]fn every_pair_of_the_actual_identity_tail_is_checked(){for k in[0,261,(1u64<<48)-1]{assert!(strip_identity_tail(tail(k)).is_empty());}}
#[test]#[should_panic]fn asymmetric_tail_is_not_silently_removed(){let mut ops=tail(0);ops[95].q_target=QubitId(1);strip_identity_tail(ops);}
#[test]#[should_panic]fn quantum_data_gate_is_not_accepted_as_a_tail(){let mut ops=tail(0);ops[94].q_target=QubitId(2);ops[95].q_target=QubitId(2);strip_identity_tail(ops);}
}
