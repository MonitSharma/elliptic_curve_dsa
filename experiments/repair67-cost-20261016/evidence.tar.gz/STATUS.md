# Repaired67 bounded cost qualification

Status at 16 October 2026, 07:37 Singapore: active timing experiment only.

The terminal optional fused-guard runtime passes independent review of all79
archived artifacts,16 source files, every row in six4096 comparisons, full9024
quantum/classical/phase/measurement controls, forced scheduler fallbacks, and
the wide classical workspace. Its executable is frozen as
`ab8cf13ceca99f8418ba490e7e02be7b0611a55de975a3451c5943d55c25e28b`.

The fixed four-trial order is raw, fused, fused, raw. Each trial has four
processes with two threads each,12GiB per process, and disjoint4096-nonce
ranges covering1..16384. All complete semantic rows must agree across trials.
The driver verifies59 source/library/model/proof inputs before each trial and
after the suite; it also rechecks executable identity and available memory.
The declaration, source and launch bindings precede the experiment. A second
agent independently reviewed the runner and complete binding coverage.

The detached driver PID is409263. Launch available memory was262.90GiB.
Existing product25 workers, unrelated lattice jobs, and submission work are
unchanged. Timing uses the existing executable without any rebuild. Only
the driver's own returned child processes can be stopped on timeout/error.

The first raw trial completed16384 rows in77.2354 seconds including startup;
its four internal timed sections took32.7375..39.3091 seconds. These are
different scopes. Repeated short-process startup produces a conservative
restart-inclusive forecast, not a measured persistent-worker mean search time.
The fixed protocol continues through all four trials without mode selection.
No nonce is selected and no production-search authority is granted.
