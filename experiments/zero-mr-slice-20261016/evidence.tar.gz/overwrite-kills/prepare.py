from pathlib import Path
import shutil

root = Path(__file__).resolve().parent
old = root.parent / 'zero-mr-20261016'
tool = root / 'tool'
(tool / 'src').mkdir(parents=True, exist_ok=True)
for name in ['Cargo.toml', 'Cargo.lock', 'simd8wide.h']:
    shutil.copyfile(old / 'tool' / name, tool / name)
for name in ['prefix.rs', 'fast_sim_wide.rs']:
    shutil.copyfile(old / 'tool/src' / name, tool / 'src' / name)
for name in ['zero8.c', 'build.rs']:
    shutil.copyfile(old / name, tool / name)
source = (old / 'main.rs').read_text()
slice_source = r'''
// Conservative reverse liveness at fixed MR=0. Every scope remains, including
// its entry-time classical snapshot. Only final coordinate values are queried.
fn slice(p:&Compact, regs:&[Vec<QubitOrBit>], nq:usize, nb:usize)->Compact {
 let mut qlive=vec![false;nq]; let mut blive=vec![false;nb];
 for reg in &regs[..2] { for w in reg { match w {
  QubitOrBit::Qubit(id)=>qlive[id.0 as usize]=true,
  QubitOrBit::Bit(id)=>blive[id.0 as usize]=true,
 } } }
 let mut keep=vec![false;p.ops.len()];
 let mut depth=0usize;
 let unconditional=p.ops.iter().map(|o| {
  let yes=depth==0&&o.c==u32::MAX;
  if o.k==15 {depth+=1;} else if o.k==16 {depth-=1;}
  yes
 }).collect::<Vec<_>>();assert_eq!(depth,0);
 for (i,o) in p.ops.iter().enumerate().rev() {
  let needed=match o.k {
   15|16=>true,
   3|4|5=>blive[o.bt as usize],
   6|8|11|13=>qlive[o.t as usize],
   10=>qlive[o.t as usize]||qlive[o.a as usize],
   12=>qlive[o.t as usize]||blive[o.bt as usize],
   0|7|9|14=>false,
   _=>panic!("unknown opcode {}",o.k),
  };
  if !needed {continue;} keep[i]=true;
  if unconditional[i] {
   match o.k {
    4|5=>blive[o.bt as usize]=false,
    11=>qlive[o.t as usize]=false,
    12=>{qlive[o.t as usize]=false;blive[o.bt as usize]=false;},
    10=>{let a=qlive[o.a as usize];qlive[o.a as usize]=qlive[o.t as usize];qlive[o.t as usize]=a;},
    _=>{},
   }
  }
  if o.c!=u32::MAX {blive[o.c as usize]=true;}
  match o.k {
   8=>qlive[o.a as usize]=true,
   10 if !unconditional[i]=>{qlive[o.a as usize]=true;qlive[o.t as usize]=true;},
   13=>{qlive[o.a as usize]=true;qlive[o.b as usize]=true;},
   _=>{},
  }
 }
 let ops=p.ops.iter().zip(keep).filter_map(|(o,k)|k.then_some(*o)).collect::<Vec<_>>();
 println!("SLICE before={} after={} outputs=registers0and1 scopes=all",p.ops.len(),ops.len());
 Compact{ops,rng_count:0}
}
fn same_outputs(aq:&[u64],ab:&[u64],bq:&[u64],bb:&[u64],regs:&[Vec<QubitOrBit>]) {
 for reg in &regs[..2] {for w in reg {for j in 0..8 {match w {
  QubitOrBit::Qubit(id)=>assert_eq!(aq[id.0 as usize*8+j],bq[id.0 as usize*8+j]),
  QubitOrBit::Bit(id)=>assert_eq!(ab[id.0 as usize*8+j],bb[id.0 as usize*8+j]),
 }}}}
}
'''
source = source.replace('fn main(){', slice_source + '\nfn main(){', 1)
source = source.replace('let rows=fs::read_to_string', 'let sliced=slice(&simplified,&regs,nq as usize,nb as usize);\n let rows=fs::read_to_string', 1)
source = source.replace('println!("ZERO_VALUE_VERIFIED', 'let(mut sliceq,mut sliceb)=(q.clone(),b.clone());run(&sliced,&mut sliceq,&mut sliceb,&mut stack);same_outputs(&sq,&sb,&sliceq,&sliceb,&regs);\n println!("ZERO_VALUE_VERIFIED', 1)
source = source.replace('[("full",&p),("static_simplified",&simplified)]', '[("full",&p),("static_simplified",&simplified),("output_slice",&sliced)]')
source = source.replace('assert_eq!(qq,sq);assert_eq!(bb,sb);', 'same_outputs(&qq,&bb,&sq,&sb,&regs);')
(tool / 'src/main.rs').write_text(source)
