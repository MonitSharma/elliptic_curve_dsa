#![allow(dead_code,unused_imports)]
include!("prefix.rs");
include!("fast_sim.rs");
include!("tri.rs");
use std::{fs,path::Path,io::BufWriter,time::Instant};
const DEFAULT_ZSTD_LEVEL:i32=3;
fn main(){abstract_tests();let args:Vec<_>=std::env::args().collect();let ops=load_ops(&args[1]).unwrap();let(nq,nb,_,regs)=analyze_ops(ops.iter());let p=Compact::compile(&ops);let rows=fs::read_to_string(&args[2]).unwrap();let(mut bad,mut good)=(Vec::new(),Vec::new());
 for row in rows.lines().skip(1){let f:Vec<_>=row.split('\t').collect();let v=|i|U256::from_str_radix(f[i],16).unwrap();let x=([v(4),v(5),v(6),v(7)],[v(8),v(9)],f[10]=="1");if x.2&&bad.len()<128{bad.push(x);}else if !x.2&&good.len()<128{good.push(x);}if bad.len()==128&&good.len()==128{break;}}
 let inputs:Vec<_>=bad.into_iter().chain(good).collect();let(mut certified,mut known,mut outputs)=(0,0u64,0u64);let start=Instant::now();
 for(batch,chunk)in inputs.chunks(64).enumerate(){let mut tri=TriSim::new(nq as usize,nb as usize);for(lane,(values,_,_))in chunk.iter().enumerate(){for(r,v)in regs[..4].iter().zip(values){tri.set(r,*v,lane);}}
 let q0=tri.q.iter().map(|x|x.v).collect::<Vec<_>>();let b0=tri.b.iter().map(|x|x.v).collect::<Vec<_>>();let t=Instant::now();tri.apply(&p);let elapsed=t.elapsed().as_secs_f64();
 let mut h=Shake256::default();h.update(b"rng-free-abstract-fixture-v1");h.update(&(batch as u64).to_le_bytes());let mut rng=h.finalize_xof();let mut real=Simulator::new(nq as usize,nb as usize,&mut rng);real.qubits.copy_from_slice(&q0);real.bits.copy_from_slice(&b0);real.apply_iter(ops.iter());
 for(i,(x,v))in tri.q.iter().zip(&real.qubits).enumerate(){assert!(x.contains(*v),"qubit containment batch={batch} wire={i}");}for(i,(x,v))in tri.b.iter().zip(&real.bits).enumerate(){assert!(x.contains(*v),"bit containment batch={batch} wire={i}");}
 let mut cert=0;let mut realbad=0;let mut bknown=0;for(lane,(_,expected,_))in chunk.iter().enumerate(){let mut wrong=false;let mut actual=false;for(reg,value)in regs[..2].iter().zip(expected){for(i,w)in reg.iter().enumerate(){let(x,v)=match w{QubitOrBit::Qubit(id)=>(tri.q[id.0 as usize],real.qubits[id.0 as usize]),QubitOrBit::Bit(id)=>(tri.b[id.0 as usize],real.bits[id.0 as usize])};let bit=1u64<<lane;let want=(value.bit(i)as u64)<<lane;wrong|=((x.v^want)&!x.u&bit)!=0;actual|=((v^want)&bit)!=0;bknown+=u64::from(x.u&bit==0);outputs+=1;}}if wrong{assert!(actual,"false certificate");cert+=1;}realbad+=usize::from(actual);}
 certified+=cert;known+=bknown;println!("TRI_BATCH batch={batch} inputs={} reference_wrong={realbad} certified={cert} known_output_bits={bknown} abstract_seconds={elapsed:.6} full_state_containment=true",chunk.len());}
 println!("TRI_DONE inputs={} certified={certified} known_output_bits={known} total_output_bits={outputs} wall_seconds={:.6} status=RESEARCH_ONLY",inputs.len(),start.elapsed().as_secs_f64());}
